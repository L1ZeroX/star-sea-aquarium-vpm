Shader "R19 Aquarium/Fish labels"
{
    Properties
    {
        [PerRendererData] _MainTex ("Font or white texture", 2D) = "white" {}
        [HideInInspector] _Observation ("Observation", Float) = -1
        [HideInInspector] _WatchingFish ("Observed fish", Float) = -1
        [HideInInspector] _ObservationAge ("Observation age", Float) = 0
        [HideInInspector] _CuriosityX ("Chest X", Float) = 0
        [HideInInspector] _FeedAge ("Feeding age", Float) = -1
        [HideInInspector] _FeedFishCount ("Fish count", Float) = 1
        [HideInInspector] _FeedFishMask ("Feeding lanes", Float) = -1
        [HideInInspector] _SwimA ("First fish", Float) = 0
        [HideInInspector] _SwimB ("Second fish", Float) = -1
        [HideInInspector] _SwimC ("Third fish", Float) = -1
        [HideInInspector] _Enchantment ("Resident enchantment", Float) = 0
        [HideInInspector] _Lane ("Label lane", Float) = 1
    }
    SubShader
    {
        Tags { "Queue"="Transparent+10" "RenderType"="Transparent" "IgnoreProjector"="True" "DisableBatching"="True" }
        Pass
        {
            Cull Off ZWrite Off ZTest LEqual Blend SrcAlpha OneMinusSrcAlpha
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma target 3.0
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            #include "Night lighting.cginc"
            #include "Fish motion.cginc"
            #include "Fish badges.cginc"
            struct Input { float4 vertex:POSITION; float4 color:COLOR; float2 uv:TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Out { float4 clip:SV_POSITION; float4 color:COLOR; float2 uv:TEXCOORD0; half isMote:TEXCOORD1; UNITY_VERTEX_OUTPUT_STEREO };
            sampler2D _MainTex;
            float4x4 _TankToWorld, _WorldToTank;
            float _Lane, _Enchantment;

            float3 FishAnchor(float lane, float species, float lift)
            {
                float3 p=0, center, heading;
                AquariumFishPose(lane,species,_Time.y,center,heading,p);
                center.y += lift;
                return mul(UNITY_MATRIX_V,mul(_TankToWorld,float4(center,1))).xyz;
            }
            // Leave a little vertical space when two projected nameplates cross.
            float Stagger(float3 a,float3 b,float scale)
            {
                float2 delta=a.xy-b.xy*(a.z/min(-.001,b.z));
                return .045*scale*(1-smoothstep(.085,.15,abs(delta.x)/scale))*
                    (1-smoothstep(.007,.046,abs(delta.y)/scale));
            }
            // Emit in the swimmer's frame, so parallax and occlusion match the tank in both eyes.
            void WaterParticle(float species, float seed, float2 uv, out float4 clip, out float opacity)
            {
                float t=_Time.y;
                float k=frac(seed*.618034+_Lane*.217), h=frac(seed*.414214+species*.131);
                float phase=6.283185*k;
                float speed=lerp(.37,.72,h);
                float age=frac(t*speed+k);
                float trail=.10+.58*age;
                float3 dummy=0,center,heading;
                AquariumFishPose(_Lane,species,t-trail,center,heading,dummy);
                float3 side=normalize(cross(heading,float3(0,1,0)));
                float sn=sin(phase+t*.81),cs=cos(phase+t*.81);
                float3 offset=float3(-.024-.047*age,.013*sn,(.018+.015*age)*cs);
                float2 size=float2(.013,.013);
                float angle=phase+saturate(age)*1.2;
                opacity=smoothstep(0,.12,age)*(1-smoothstep(.69,1,age));
                float effect=_Enchantment;
                if(effect<1.5) {
                    offset.y+=.018*age;size=float2(.006,.010)*(.83+.7*h);
                    opacity*=.40+.60*pow(abs(sin(t*2+phase)),4);
                } else if(effect<2.5) {
                    offset+=float3(-.015*age,.025*sn,.010*sin(phase+age*5));
                    size*=.9+.45*h;opacity*=.48+.5*pow(abs(cos(t*1.7+phase)),3);
                } else if(effect<3.5) {
                    offset=float3(.012-.041*age+sn*.006,-.009+.080*age,(k>.5?1:-1)*(.015+.010*cs));
                    size*=.45+.73*h+.34*age;angle=0;
                } else if(effect<4.5) {
                    offset+=float3(-.03*age,.008*sn,.010*cs);
                    size=float2(.045+.022*h,.010+.004*k);opacity*=.72;
                } else if(effect<5.5) {
                    offset=float3(.025-.115*age,.016+.011*sn,.014*cs);
                    size=float2(.026+.016*k,.013+.007*h);opacity*=.71;
                } else if(effect<6.5) {
                    float beat=floor((t+phase)*1.9);float pulse=frac((t+phase)*1.9);
                    offset=float3(-.026+.048*cos(phase+beat),.014*sin(phase+beat*2),.022*cs);
                    size=float2(.035+.029*h,.014+.009*k);
                    opacity=(1-smoothstep(.025,.38,pulse))*(.62+.38*abs(sin(beat+phase)));
                    angle=phase+beat*.61;
                } else if(effect<7.5) {
                    offset+=float3(-.018*age,.039-.050*age,.008*sn);
                    size=float2(.009+.005*h,.014+.007*k);angle=phase+t*(.7+k);
                } else {
                    offset+=float3(-.018*age,.029-.047*age,.012*sn);
                    size=float2(.010+.009*h,.007+.004*k)*(.82+.18*abs(cs));
                    angle=phase+t*(.75+h)+.48*sn;
                }
                float3 at=center+heading*offset.x+float3(0,offset.y,0)+side*offset.z;
                float3 view=mul(UNITY_MATRIX_V,mul(_TankToWorld,float4(at,1))).xyz;
                float scale=length(mul((float3x3)_TankToWorld,float3(0,1,0)));
                if(effect>3.5 && effect<5.5) {
                    float3 dir=mul((float3x3)UNITY_MATRIX_V,mul((float3x3)_TankToWorld,heading));
                    angle=atan2(dir.y,dir.x)+.12*sn;
                    size.x*=lerp(.45,1,saturate(length(dir.xy)/max(scale,.0001)));
                }
                float sa,ca;sincos(angle,sa,ca);float2 p=(uv-.5)*size;
                view.xy+=scale*float2(ca*p.x-sa*p.y,sa*p.x+ca*p.y);
                clip=mul(UNITY_MATRIX_P,float4(view,1));
            }

            half4 WaterLight(float2 uv,float seed)
            {
                float2 p=uv*2-1;
                float r=length(p), t=_Time.y, phase=seed*2.39996+_Lane*.91;
                float aa=max(.015,fwidth(r));
                float fade=1-smoothstep(.73,1,r);
                float3 light;float alpha;
                if(_Enchantment<1.5) {
                    float d=length(p*float2(1.5,.85));
                    float core=exp(-d*d*19);
                    light=lerp(float3(.86,.46,.12),float3(1.8,1.28,.65),core);
                    alpha=(core+.27*exp(-5*d*d))*fade;
                } else if(_Enchantment<2.5) {
                    float core=exp(-28*r*r);
                    light=lerp(float3(.22,.28,.88),float3(1.2,1.32,1.65),core);
                    alpha=(.49*exp(-4.4*r*r)+core)*fade;
                } else if(_Enchantment<3.5) {
                    float rim=1-smoothstep(.03,.12+aa,abs(r-.78));
                    float gleam=exp(-65*dot(p-float2(-.32,.46),p-float2(-.32,.46)));
                    float lower=exp(-17*dot(p-float2(.30,-.51),p-float2(.30,-.51)));
                    light=lerp(float3(.27,.64,.76),float3(1.45,1.63,1.66),saturate(gleam+rim*.42+lower*.4));
                    alpha=(.50*rim+.88*gleam+.36*lower+.065*r*r)*(1-smoothstep(.80,.94+aa,r));
                } else if(_Enchantment<4.5) {
                    float y=p.y-.36*sin(p.x*2.7+t*1.7+phase)-.12*sin(p.x*6+phase);
                    float fil=exp(-y*y*49), halo=exp(-y*y*7);
                    light=lerp(float3(.27,.60,.79),float3(1.02,1.25,1.37),fil);
                    alpha=(.58*fil+.23*halo)*(1-smoothstep(.36,1,abs(p.x)))*(1-smoothstep(.76,1,abs(p.y)));
                } else if(_Enchantment<5.5) {
                    float2 q=float2(p.x*2.4,p.y*1.4);
                    float a=sin(q.x*2.5+sin(q.y+t)+phase)+.74*cos(q.y*2-q.x+t*.86);
                    float b=sin(2*q.y+.6*cos(q.x-t)+phase)+.78*cos(1.6*q.x+t*.55);
                    float band=exp(-15*min(a*a,b*b));
                    light=lerp(float3(.74,.40,.09),float3(1.45,1.09,.50),band);alpha=(.10+.63*band)*fade;
                } else if(_Enchantment<6.5) {
                    float n=phase+floor((t+phase)*1.9)*1.13;
                    float y=.24*sin(p.x*7+n)+.11*sin(p.x*18-n)+.06*sin(p.x*35+n);
                    float dist=abs(p.y-y);
                    float branch=abs(p.y-(y+.95*(p.x+.16)));
                    dist=min(dist,branch+(.06+.55*(1-smoothstep(-.18,.01,p.x))+.55*smoothstep(.49,.75,p.x)));
                    float arc=exp(-dist*dist*125);
                    light=lerp(float3(.28,.38,.92),float3(1.52,1.59,1.8),arc);
                    alpha=(arc+.38*exp(-dist*dist*12))*(1-smoothstep(.55,1,abs(p.x)))*(1-smoothstep(.79,1,abs(p.y)));
                } else if(_Enchantment<7.5) {
                    float bend=.18*p.y;
                    float d=abs(p.x-bend)*1.38+abs(p.y)*.88;
                    float face=step(bend,p.x);float flash=.5+.5*sin(t*2.9+phase);
                    light=lerp(float3(.35,.66,.81),float3(1.14,1.44,1.55),face*.42+flash*.40);
                    alpha=(1-smoothstep(.78,.78+aa*2,d))*(.26+.26*face+.37*flash);
                } else {
                    float x=p.x+.16*(1-p.y*p.y);
                    float d=length(float2(x, p.y*.94))+.17*p.x*p.y;
                    float fold=exp(-33*abs(p.y+.18*sin(p.x*3+phase)));
                    light=lerp(float3(.63,.24,.31),float3(1.15,.66,.69),saturate(.42+.36*p.y+.30*fold));
                    alpha=(1-smoothstep(.68,.90+aa,d))*(.43+.22*fold+.19*uv.x);
                }
                return half4(light,saturate(alpha));
            }


            Out Vert(Input v)
            {
                Out o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_OUTPUT(Out,o); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                float scale=length(mul((float3x3)_TankToWorld,float3(0,1,0)));
                float species=_Lane<1.5?_SwimA:(_Lane<2.5?_SwimB:_SwimC);
                if (v.uv.y>=1.99)
                {
                    float seed=floor((v.uv.y-2.0)*.5);
                    float2 uv=float2(v.uv.x,v.uv.y-(2.0+seed*2.0));
                    float opacity;
                    WaterParticle(species,seed,uv,o.clip,opacity);
                    o.uv=uv;o.color=v.color;o.color.a*=opacity*step(.5,_Enchantment);
                    o.isMote=seed+1;return o;
                }
                float3 center=FishAnchor(_Lane,species,.064);
                float3 first=0;
                if (_Lane>1.5 && _SwimA>=0)
                {
                    first=FishAnchor(1,_SwimA,.064);
                    center.y+=Stagger(center,first,scale);
                }
                if (_Lane>2.5 && _SwimB>=0)
                {
                    float3 second=FishAnchor(2,_SwimB,.064);
                    if (_SwimA>=0) second.y+=Stagger(second,first,scale);
                    center.y+=Stagger(center,second,scale);
                }
                float3 rest=mul(_WorldToTank,mul(unity_ObjectToWorld,v.vertex)).xyz;
                center.xy+=float2(rest.x,rest.y-.25)*scale;
                o.clip=mul(UNITY_MATRIX_P,float4(center,1));o.color=v.color;o.uv=v.uv;
                return o;
            }
            half4 Frag(Out i):SV_Target
            {
                if(i.isMote>.5) {
                    half4 water=WaterLight(i.uv,i.isMote-1);
                    return half4(AquariumNightTint(water.rgb,.045),i.color.a*water.a);
                }
                if(i.uv.y <= -1.0) {
                    half4 badge = tex2D(_MainTex, AquariumBadgeUV(i.uv, _Lane * .51));
                    return half4(AquariumNightTint(badge.rgb,.16),badge.a*i.color.a);
                }
                return half4(AquariumNightTint(i.color.rgb,.16),i.color.a*tex2D(_MainTex,i.uv).a);
            }
            ENDCG
        }
    }
    Fallback Off
}

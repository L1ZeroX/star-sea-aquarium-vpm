Shader "R19 Aquarium/Edge glass"
{
    SubShader
    {
        Tags {"Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True"}
        Pass
        {
            Cull Off ZWrite Off Blend SrcAlpha OneMinusSrcAlpha
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            #include "Night lighting.cginc"
            struct Input {float4 vertex:POSITION; float3 n:NORMAL; UNITY_VERTEX_INPUT_INSTANCE_ID};
            struct Out {float4 clip:SV_POSITION; float3 world:TEXCOORD0; half3 n:TEXCOORD1; float3 localPos:TEXCOORD2; UNITY_VERTEX_OUTPUT_STEREO};
            Out Vert(Input v) {Out o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_OUTPUT(Out,o); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.clip=UnityObjectToClipPos(v.vertex); o.world=mul(unity_ObjectToWorld,v.vertex).xyz; o.n=UnityObjectToWorldNormal(v.n);o.localPos=v.vertex.xyz;return o;}
            half4 Frag(Out i):SV_Target {UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
                half fres=1-abs(dot(normalize(i.n),normalize(UnityWorldSpaceViewDir(i.world))));
                half lip=1-smoothstep(.001,.004,abs(i.localPos.y-.432));
                half top=step(.444,i.localPos.y);
                float ripple=sin(i.localPos.x*33+i.localPos.z*41+_Time.y*.65);
                half3 glass = half3(.14,.46,.49);
                half3 modes = AquariumLighting(glass,.10,half3(.08,.16,.48),.32,0);
                half band = exp2(-24*abs(i.localPos.y-.432)) * (1-smoothstep(.31,.44,abs(i.localPos.x)));
                half rear = smoothstep(-.16,.15,i.localPos.z);
                half reflection = band * (.32 + .80*rear) * AquariumDayWeight();
                half alpha = .017+.09*fres*fres+.08*lip+.032*top*(1+ripple);
                return half4(modes + half3(.025,.31,.75)*reflection, alpha + .095*reflection);}
            ENDCG
        }
    }
    Fallback Off
}

Shader "R19 Aquarium/Action frames"
{
    Properties
    {
        _Rail ("Rail enamel", Color) = (.51,.68,.75,1)
        _Clasp ("Corner metal", Color) = (.76,.89,.92,1)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Pass
        {
            Cull Off
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            #include "Night lighting.cginc"

            half4 _Rail, _Clasp;
            struct Input { float4 vertex:POSITION; float3 normal:NORMAL; half4 color:COLOR; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Out { float4 clip:SV_POSITION; half3 normal:TEXCOORD0; half2 enamel:TEXCOORD1; UNITY_VERTEX_OUTPUT_STEREO };

            Out Vert(Input v)
            {
                Out o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_OUTPUT(Out,o);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.clip = UnityObjectToClipPos(v.vertex);
                o.normal = v.normal;
                o.enamel = v.color.rg;
                return o;
            }

            half4 Frag(Out i):SV_Target
            {
                half diffuse = saturate(dot(normalize(i.normal), normalize(half3(-.45,.82,-.46))));
                half3 metal = lerp(_Rail.rgb, _Clasp.rgb, i.enamel.x);
                return half4(AquariumNightTint(metal * i.enamel.y * (.57 + .50 * diffuse), .16), 1);
            }
            ENDCG
        }
    }
    Fallback Off
}

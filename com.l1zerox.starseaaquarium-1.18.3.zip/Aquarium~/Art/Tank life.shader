Shader "R19 Aquarium/Tank life"
{
    Properties
    {
        [HideInInspector] _Observation ("Observation",Float)=-1
        [HideInInspector] _WatchingFish ("Observed species",Float)=-1
        [HideInInspector] _ObservationAge ("Observation age",Float)=0
        [HideInInspector] _CuriosityX ("Chest X",Float)=0
        [HideInInspector] _FoodRank ("Food upgrade", Float) = 0
        [HideInInspector] _FeedAge ("Seconds since food release", Float) = -1
        [HideInInspector] _FeedFishCount ("Fish at feeding time", Float) = 1
        [HideInInspector] _FeedFishMask ("Occupied feeding lanes", Float) = -1
        [HideInInspector] _SwimA ("Species in first lane", Float) = 0
        [HideInInspector] _SwimB ("Species in second lane", Float) = 1
        [HideInInspector] _SwimC ("Species in third lane", Float) = 2
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "DisableBatching"="True" "R19TubeCaster"="Wildlife" }
        CGINCLUDE
        #include "Wildlife geometry.cginc"
        #include "Tube lighting.cginc"
        #include "Night lighting.cginc"
        ENDCG
        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            Cull Off
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma target 3.0
            #pragma multi_compile_instancing
            float _FoodRank;
            struct Out {float4 clip:SV_POSITION; half3 color:COLOR; float3 p:TEXCOORD0; half3 n:TEXCOORD1; half kind:TEXCOORD2; float4 tube:TEXCOORD3; UNITY_VERTEX_OUTPUT_STEREO};


            Out Vert(Input v)
            {
                Out o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_OUTPUT(Out,o); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                AquariumGeometry(v);
                float3 p=v.vertex.xyz, n=v.normal;
                float kind=v.kind.x, species=kind<3.5 ? kind-1 : kind-10;
                bool isFish=IsSwimmer(kind);
                o.clip=UnityObjectToClipPos(float4(p,1));
                o.color=v.color.rgb;
                if(kind>8.5 && kind<9.5)
                {
                    half3 tint = lerp(half3(.99,.79,.48),half3(.52,.97,.92),saturate((_FoodRank-3)*.5));
                    o.color=lerp(o.color,tint*(.55+.45*max(o.color.r,o.color.g)),saturate(_FoodRank*.2));
                }
                #ifndef UNITY_COLORSPACE_GAMMA
                o.color=GammaToLinearSpace(o.color);
                #endif
                if(isFish && abs(species-_WatchingFish)<.25 && abs(_Observation-4)<.25)
                    o.color+=float3(.15,.07,.18)*smoothstep(.5,2,_ObservationAge)*(1-smoothstep(4,5.7,_ObservationAge));
                o.tube=TubeCoords(p,n);o.p=p;o.n=n;o.kind=isFish?1.0:kind;return o;
            }
            half4 Frag(Out i):SV_Target
            {
                half light=saturate(dot(normalize(i.n),normalize(float3(-.45,.82,-.46))));
                half3 color=i.color*(.53+.59*light);
                if(i.kind>.5 && i.kind<4.5)
                {
                    float ripple=.5+.5*sin(i.p.x*40+i.p.z*26+_Time.y*.65+1.5*sin(i.p.z*22+_Time.y*.44));
                    color*=.93+.15*ripple*ripple;
                }
                if(i.kind>6.5 && i.kind<7.5)
                {
                    float y=saturate(i.p.y/.45);
                    float bands=pow(.5+.5*sin(i.p.x*29+i.p.y*4+_Time.y*.25+1.1*sin(i.p.x*17)),5);
                    color=i.color*(.50+.85*y)+half3(.003,.020,.023)*bands*y;
                }
                if(i.kind>7.5 && i.kind<8.5)color=i.color*.82;
                if(i.kind>8.5)color=i.color*(.64+.63*light);
                half lamp = (i.kind>7.5 && i.kind<8.5) ? 1 : 0;
                half response = abs(i.kind-1)<.25 ? .94 : (abs(i.kind-4)<.25 ? .68 : .10);
                half3 lit = color*lerp(half3(1,1,1),TubeLight(i.tube),TubeSurface(i.kind,i.p));
                half3 modes = AquariumLighting(lit,lerp(.12,.028,lamp),i.color,response,lamp);
                half wall = abs(i.kind-7)<.25 ? 1 : 0;
                half wet = saturate(TubeSurface(i.kind,i.p) + lamp);
                half3 daylight = FluorescentDay(lit,i.color,i.p,wall,lamp,0);
                return half4(modes + (daylight-lit)*wet*AquariumDayWeight(),1);
            }
            ENDCG
        }

    }
    Fallback Off
}

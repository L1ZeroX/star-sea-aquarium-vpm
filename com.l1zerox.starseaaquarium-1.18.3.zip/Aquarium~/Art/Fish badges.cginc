#ifndef R19_FISH_BADGES_INCLUDED
#define R19_FISH_BADGES_INCLUDED

// The 16 frames on each atlas row use point sampling, like a pixel-art GIF.
float2 AquariumBadgeUV(float2 uv, float phase)
{
    float row = floor((-uv.y - 1.0) * .5);
    float localY = uv.y + 2.0 + 2.0 * row;
    float frame = floor(frac((_Time.y + phase) * .42) * 16.0);
    float2 pixel = (clamp(floor(float2(uv.x, localY) * 16.0), 0.0, 15.0) + .5) / 16.0;
    return (float2(frame, row) + pixel) / float2(16.0, 4.0);
}

#endif

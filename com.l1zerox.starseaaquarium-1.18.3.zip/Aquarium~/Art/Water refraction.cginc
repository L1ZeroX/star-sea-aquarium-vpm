#ifndef R19_AQUARIUM_REFRACTION
#define R19_AQUARIUM_REFRACTION

// Tank-local distances in metres. Waves refract the overhead strip toward the front.
float2 WaterRayOffset(float2 source, float depth, float time)
{
    float wave = sin(source.x*21.0 + source.y*19.0 + time*.88);
    float crossWave = sin(source.x*35.0 - source.y*12.0 - time*.56);
    return depth * float2(.29 + .10*wave + .044*crossWave, -.21 + .06*crossWave);
}

half SandCaustics(float3 p, float time)
{
    float depth = max(.427-p.y,0);
    float2 source = p.xz - WaterRayOffset(p.xz,depth,time);
    float2 phase = source*float2(59,74);
    phase += float2(1.1*sin(phase.y*.75 + time*.66), .86*sin(phase.x*.61 - time*.50));
    float folds = abs(sin(phase.x+time*.36) + .72*sin(phase.y-time*.41));
    half crest = 1.0 - smoothstep(.045,.32+min(.30,fwidth(folds)),folds);
    half footprint = (1-smoothstep(.29,.41,abs(source.x))) *
                     (1-smoothstep(.05,.23,abs(source.y-.073)));
    return crest*footprint;
}
#endif

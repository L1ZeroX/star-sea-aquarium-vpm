Shader "R19 Aquarium/Ornaments"
{
    Properties { [HideInInspector] _Age ("Chest activity",Float)=-1 }
    SubShader
    {
        Tags {"Queue"="Geometry" "RenderType"="Opaque" "DisableBatching"="True" "R19TubeCaster"="Ornament"}
        CGINCLUDE
        #include "Ornament geometry.cginc"
        #include "Tube lighting.cginc"
        #include "Night lighting.cginc"
        ENDCG
        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            Cull Off
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            struct view {float4 v:SV_POSITION; half3 c:COLOR; half3 n:TEXCOORD0; half glow:TEXCOORD1; float4 tube:TEXCOORD3; UNITY_VERTEX_OUTPUT_STEREO};
            view vert(Input a)
            {
                view o; UNITY_SETUP_INSTANCE_ID(a); UNITY_INITIALIZE_OUTPUT(view,o); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                AquariumGeometry(a);float3 p=a.vertex.xyz,n=a.normal;
                o.tube=TubeCoords(p,n);o.v=UnityObjectToClipPos(float4(p,1));o.n=n;o.glow=step(1.5,a.kind.x);o.c=a.color.rgb;
                #ifndef UNITY_COLORSPACE_GAMMA
                o.c=GammaToLinearSpace(o.c);
                #endif
                return o;
            }
            half4 frag(view i):SV_Target
            {
                float light=saturate(dot(normalize(i.n),normalize(float3(-.35,.8,-.5))));
                half3 lit = i.c*(.60+.57*light+.24*i.glow)*lerp(TubeLight(i.tube),half3(1,1,1),i.glow);
                half3 modes = AquariumLighting(lit,lerp(.12,.045,i.glow),i.c,lerp(.07,.95,i.glow),0);
                half trim = .66;
                #ifdef UNITY_COLORSPACE_GAMMA
                trim = LinearToGammaSpace(half3(trim,trim,trim)).r;
                #endif
                return half4(modes * lerp(1.0h,trim,AquariumDayWeight()),1);
            }
            ENDCG
        }

    }
    Fallback Off
}

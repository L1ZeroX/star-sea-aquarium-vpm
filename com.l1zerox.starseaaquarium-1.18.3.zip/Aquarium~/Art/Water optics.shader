Shader "R19 Aquarium/Water optics"
{
    SubShader
    {
        Tags { "Queue"="Transparent-12" "RenderType"="Transparent" "IgnoreProjector"="True" "DisableBatching"="True" }
        Pass
        {
            Cull Off ZWrite Off ZTest LEqual Blend One OneMinusSrcAlpha
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            #include "Water refraction.cginc"
            #include "Night lighting.cginc"

            struct Input { float4 vertex:POSITION; float3 parameters:NORMAL; half4 color:COLOR; float2 uv:TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varying { float4 clip:SV_POSITION; float2 uv:TEXCOORD0; half4 effect:TEXCOORD1; UNITY_VERTEX_OUTPUT_STEREO };

            Varying Vert(Input v)
            {
                Varying o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_OUTPUT(Varying,o);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                float time = _Time.y;
                float3 p = v.vertex.xyz;
                float3 eye = mul(unity_WorldToObject,float4(_WorldSpaceCameraPos,1)).xyz;
                half kind = v.color.r;
                half brightness = v.color.g;
                float age = 0;
                if (kind < .25)
                {
                    // A camera-facing slice through each soft beam follows its refracted path in 3D.
                    float depth = .427-p.y;
                    p.xz += WaterRayOffset(v.vertex.xz,depth,time);
                    float3 tangent = normalize(float3(.29,-1,-.21));
                    float3 side = cross(eye-p,tangent);
                    side *= rsqrt(max(dot(side,side),.00001));
                    p += side*v.uv.x*v.parameters.x*(.40+1.40*v.uv.y);
                    brightness *= .77+.23*sin(v.vertex.x*28.0 + time*.70);
                }
                else
                {
                    float seed = v.parameters.x;
                    float cycle = time*v.parameters.y + seed;
                    age = frac(cycle);
                    float wave = age*8.0 + seed*34.0;
                    float2 drift = float2(.007*sin(wave)+.004*sin(wave*1.61),.007*cos(wave*.81));
                    float3 center = v.vertex.xyz;
                    if(kind < .75)
                    {
                        center.y = lerp(center.y,.429,age);
                        center.xz += drift*age;
                        float radius = v.parameters.z*(.80+.25*age)*smoothstep(0,.045,age);
                        float3 view = normalize(eye-center);
                        float3 right = cross(float3(0,1,0),view);
                        if(dot(right,right)<.0001) right=float3(1,0,0);
                        right=normalize(right);
                        float3 up = cross(view,right);
                        p = center+radius*(v.uv.x*right+v.uv.y*up*(.94+.06*sin(wave)));
                        brightness *= 1-smoothstep(.985,1,age);
                    }
                    else
                    {
                        // A surface ring begins as the corresponding bubble completes its rise.
                        float endWave = 8.0+seed*34.0;
                        center.xz += float2(.007*sin(endWave)+.004*sin(endWave*1.61),.007*cos(endWave*.81));
                        center.y=.429;
                        p=center;
                        p.xz+=v.uv*(.003+age*.086);
                        brightness *= 1-smoothstep(0,.22,age);
                    }
                }
                o.clip=UnityObjectToClipPos(float4(p,1));
                o.uv=v.uv;
                o.effect=half4(kind,brightness,age,v.color.b);
                return o;
            }

            half4 Frag(Varying i):SV_Target
            {
                half day=AquariumDayWeight();
                half uv=saturate(_UdonR19AquariumUV);
                half3 tint=half3(.28,.69,.88)*day + half3(.21,.10,.56)*uv + half3(.030,.045,.052)*saturate(_UdonR19AquariumNight);
                if (i.effect.x < .25)
                {
                    float crossSection=exp2(-4.8*i.uv.x*i.uv.x)*(1-smoothstep(.76,1,abs(i.uv.x)));
                    float depth=i.uv.y;
                    float envelope=smoothstep(0,.072,depth)*(1-smoothstep(.57,1,depth));
                    half opacity=crossSection*envelope*i.effect.y*(.135+.025*i.effect.w);
                    return half4(tint*opacity,0);
                }
                float r=length(i.uv);
                float aa=max(.032,fwidth(r));
                float coverage=1-smoothstep(1-aa,1+aa,r);
                if(i.effect.x > .75)
                {
                    float rim=(1-smoothstep(aa,aa+.095,abs(r-.79)))*i.effect.y;
                    return half4(tint*.32*rim,0);
                }
                float fresnel=smoothstep(.53,.94,r);
                float glint=exp2(-20*dot(i.uv-float2(-.34,.54),i.uv-float2(-.34,.54)));
                float lower=exp2(-12*dot(i.uv-float2(.34,-.63),i.uv-float2(.34,-.63)));
                half alpha=coverage*i.effect.y*(.07+.24*fresnel);
                half3 reflected=tint*(.03+.62*fresnel+.29*lower)+
                    (day*half3(.95,1.03,1.10)+uv*half3(.40,.45,.84)+.04)*glint;
                return half4(reflected*coverage*i.effect.y,alpha);
            }
            ENDCG
        }
    }
    Fallback Off
}

Shader "R19 Aquarium/Habitat surfaces"
{
    SubShader
    {
        Tags { "Queue"="Geometry" "RenderType"="Opaque" "DisableBatching"="True" "R19TubeCaster"="Habitat" }
        CGINCLUDE
        #include "Habitat geometry.cginc"
        #include "Tube lighting.cginc"
        #include "Night lighting.cginc"
        #include "Water refraction.cginc"
        ENDCG
        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            Cull Off
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            struct Surface {float4 clip:SV_POSITION; half4 color:COLOR; float3 p:TEXCOORD0; half3 n:TEXCOORD1; half kind:TEXCOORD2; float4 tube:TEXCOORD3; UNITY_VERTEX_OUTPUT_STEREO};
            Surface Vert(Input v)
            {
                Surface o; UNITY_SETUP_INSTANCE_ID(v);UNITY_INITIALIZE_OUTPUT(Surface,o);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                AquariumGeometry(v);float3 p=v.vertex.xyz;
                o.tube=TubeCoords(p,v.normal);o.clip=UnityObjectToClipPos(float4(p,1));o.n=v.normal;o.p=p;o.kind=v.kind.x;o.color=v.color;
                #ifndef UNITY_COLORSPACE_GAMMA
                o.color.rgb=GammaToLinearSpace(o.color.rgb);
                #endif
                return o;
            }
            half4 Frag(Surface i):SV_Target
            {
                half d=saturate(dot(normalize(i.n),normalize(float3(-.45,.82,-.46))));
                half3 c=i.color.rgb*(.64+.56*d);
                half ripple=.5+.5*sin(i.p.x*31+i.p.z*25+_Time.y*.53+.85*sin(i.p.y*26-i.p.x*13+_Time.y*.36));
                if(i.kind<.5) c*=.97+.075*ripple*ripple;
                else if(i.kind<1.5) c=i.color.rgb*(.89+.12*ripple*ripple);
                else if(i.kind<2.5) c=i.color.rgb*(.89+.20*d+.07*ripple);
                else if(i.kind<3.5) c=i.color.rgb*(.80+.55*d+.09*ripple*ripple);
                else c=i.color.rgb*(.60+.56*d);
                // The painted backdrop and sand reflect the lamp more weakly than the reef.
                half response = lerp(.06,.87,smoothstep(.039,.083,i.p.y));
                if (abs(i.kind-1)<.25) response = .025;
                half3 lit = c*TubeLight(i.tube);
                half wall = abs(i.kind-1)<.25 ? 1 : 0;
                half sand = (1-smoothstep(.055,.13,i.p.y))*(1-wall);
                half3 daylight = FluorescentDay(lit,i.color.rgb,i.p,wall,0,sand);
                // Refracted ripples collect on upward-facing sand and reef surfaces.
                half receiver = (1-wall)*saturate(normalize(i.n).y)*lerp(.26,1.0,sand);
                daylight *= 1.0 + .34*receiver*SandCaustics(i.p,_Time.y);
                half3 modes = AquariumLighting(lit,.12,i.color.rgb,response,0);
                return half4(modes + (daylight-lit)*AquariumDayWeight(),1);
            }
            ENDCG
        }

    }
    Fallback Off
}

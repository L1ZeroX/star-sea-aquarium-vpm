// Coordinates in the tube camera's single, 1.02 x .51 m orthographic footprint.
float4x4 _UdonR19TubeView;
sampler2D _UdonR19TubeMap;
float _UdonR19TubeActive;

float4 TubeCoords(float3 p,float3 n)
{
    float3 world=mul(unity_ObjectToWorld,float4(p,1)).xyz;
    float3 v=mul(_UdonR19TubeView,float4(world,1)).xyz;
    float3 normal=mul((float3x3)_UdonR19TubeView,UnityObjectToWorldNormal(n));
    // Nearest point along the .625 m tube, in lamp view coordinates.
    float3 toLamp=float3(clamp(v.x,-.3125,.3125)-v.x,.013-v.y,-.242-v.z);
    float direct=saturate(dot(normal,normalize(toLamp+float3(0,0,.0001))));
    return float4(.5+v.xy/float2(1.02,.51),-v.z,direct);
}
// A finite strip reflected by the rear panel. Distances are in tank-local metres.
half RearReflectorWash(float3 p)
{
    float endDistance = max(abs(p.x) - .265, 0);
    float3 delta = float3(endDistance * 1.7, p.y - .424, (p.z - .151) * .85);
    return rcp(1.0 + 47.0 * dot(delta,delta));
}

half3 FluorescentDay(half3 lit, half3 pigment, float3 p, half backdrop, half lamp, half substrate)
{
    #ifdef UNITY_COLORSPACE_GAMMA
    lit = GammaToLinearSpace(lit);
    pigment = GammaToLinearSpace(pigment);
    #endif

    half wash = RearReflectorWash(p);
    half floorReturn = exp2(-11.0 * abs(p.y - .038)) * lerp(.50, 1.0, saturate((p.z+.16)/.32));
    // Retain contact shadows while wrapping light from the back wall and sand onto the fish.
    half3 diffuse = lit * half3(.53,.59,.69);
    diffuse += pigment * (half3(.19,.30,.45) * wash + half3(.18,.15,.115) * floorReturn + .14);
    half3 sand = lit * half3(.16,.43,.87) + pigment * half3(.055,.15,.23) * wash;
    half3 result = lerp(diffuse, sand, substrate * .88);

    half endFade = 1.0 - smoothstep(.26,.44,abs(p.x));
    half seam = exp2(-43.0 * abs(p.y - .424)) * endFade;
    // Only the upper reflector and lamp core reach HDR bloom levels.
    half3 reflected = diffuse * half3(.34,.50,.68) + half3(.006,.14,.43) * wash * wash;
    reflected += half3(.012,.039,.061) * floorReturn;
    reflected += half3(.065,.56,1.07) * seam;
    result = lerp(result, reflected, backdrop);
    result = lerp(result, half3(.97,1.60,2.1), lamp);
    result *= .58;
    #ifdef UNITY_COLORSPACE_GAMMA
    result = LinearToGammaSpace(result);
    #endif
    return result;
}

float TubeOcclusion(float2 uv,float depth,float bias)
{
    return smoothstep(bias,bias+.0035,depth-tex2D(_UdonR19TubeMap,uv).r);
}
half3 TubeLight(float4 q)
{
    if(_UdonR19TubeActive<.5 || any(q.xy<=0) || any(q.xy>=1)) return 1;
    float2 dx=ddx(q.xy),dy=ddy(q.xy);
    float det=dx.x*dy.y-dx.y*dy.x;
    float2 slope=clamp(float2(dy.y*ddx(q.z)-dx.y*ddy(q.z),dx.x*ddy(q.z)-dy.x*ddx(q.z))/
                       (abs(det)>.00000001?det:.00000001),-8.0,8.0);
    float delta=q.z-tex2D(_UdonR19TubeMap,q.xy).r;
    float softness=saturate((delta-.004)/.17);
    float2 radius=lerp(float2(.0032,.0037),float2(.014,.010),softness);
    const float2 sampleOffsets[8]={float2(.24,.26),float2(-.27,-.28),float2(-.69,.18),float2(.70,-.19),
        float2(.12,-.80),float2(-.13,.78),float2(.91,.52),float2(-.93,-.54)};
    // At grazing angles one depth texel can cover several millimetres of the receiving face.
    float bias=.0017+min(.009,.7*dot(abs(slope),float2(1.0/512.0,1.0/256.0)));
    float occlusion=0;
    [unroll]for(int i=0;i<8;i++)
    {
        float2 offset=sampleOffsets[i]*radius;
        occlusion+=TubeOcclusion(q.xy+offset,q.z+dot(slope,offset),bias);
    }
    occlusion*=.125;
    half3 lit=half3(.95,.97,.983)+q.w*half3(.18,.195,.20);
    half3 shadow=half3(.49,.56,.63);
    return lerp(lit,shadow,occlusion);
}

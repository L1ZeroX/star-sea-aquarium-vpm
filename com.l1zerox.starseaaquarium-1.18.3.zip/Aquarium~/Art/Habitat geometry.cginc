#include "UnityCG.cginc"
struct Input {float4 vertex:POSITION;float3 normal:NORMAL;half4 color:COLOR;float2 kind:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
half TubeSurface(float kind,float3 p) {return 1;}

void AquariumGeometry(inout Input v)
{
        float3 p=v.vertex.xyz;
        if(v.kind.x>3.5) {p.x+=.003*sin(_Time.y*1.24+v.vertex.y*37);p.y+=.005*sin(_Time.y*1.64+v.vertex.y*32);}
        v.vertex.xyz=p;
}

Shader "R19 Aquarium/Progress glow"
{
    Properties
    {
        [PerRendererData] _MainTex ("Graphic texture", 2D) = "white" {}
    }
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" }
        Pass
        {
            Cull Off ZWrite Off ZTest [unity_GUIZTestMode]
            Blend One OneMinusSrcAlpha
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"

            struct Input { float4 vertex:POSITION; float2 uv:TEXCOORD0; half4 color:COLOR; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Out { float4 clip:SV_POSITION; float2 uv:TEXCOORD0; half4 color:COLOR; UNITY_VERTEX_OUTPUT_STEREO };

            Out Vert(Input v)
            {
                Out o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_OUTPUT(Out,o);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.clip = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                o.color = v.color;
                return o;
            }

            half4 Frag(Out i):SV_Target
            {
                half distance = abs(i.uv.y * 2.0h - 1.0h);
                half core = 1.0h - smoothstep(.18h, .46h, distance);
                half glow = .69h * (1.0h - smoothstep(.16h, 1.0h, distance));
                half cap = smoothstep(.86h, 1.0h, i.uv.x);
                half3 emitter = lerp(i.color.rgb, half3(1,1,1), .18h + cap * .15h);
                // A soft shoulder is baked into the light profile. The bright core also feeds HDR bloom.
                half3 energy = (emitter * core * (1.14h + .15h * cap) + i.color.rgb * glow * (1.0h - core)) * i.color.a;
                return half4(energy, saturate(core + glow) * i.color.a);
            }
            ENDCG
        }
    }
    Fallback Off
}

Shader "R19 Aquarium/Fish badge display"
{
    Properties
    {
        [PerRendererData] _MainTex ("Badge frames", 2D) = "white" {}
    }
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" "CanUseSpriteAtlas"="False" }
        Pass
        {
            Cull Off ZWrite Off ZTest [unity_GUIZTestMode] Blend SrcAlpha OneMinusSrcAlpha
            CGPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"
            #include "Fish badges.cginc"

            sampler2D _MainTex;
            struct Input { float4 vertex:POSITION; float4 color:COLOR; float2 uv:TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Out { float4 clip:SV_POSITION; half4 color:COLOR; float2 uv:TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };

            Out Vert(Input v)
            {
                Out o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_OUTPUT(Out,o);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.clip = UnityObjectToClipPos(v.vertex);
                o.color = v.color;
                o.uv = v.uv;
                return o;
            }

            half4 Frag(Out i):SV_Target { return tex2D(_MainTex, AquariumBadgeUV(i.uv, 0)) * i.color; }
            ENDCG
        }
    }
    Fallback Off
}

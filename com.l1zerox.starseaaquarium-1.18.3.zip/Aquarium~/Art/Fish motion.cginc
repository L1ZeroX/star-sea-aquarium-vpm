#ifndef R19_FISH_MOTION_INCLUDED
#define R19_FISH_MOTION_INCLUDED
float _FeedAge, _FeedFishCount, _FeedFishMask;
float _Observation, _ObservationAge, _WatchingFish, _CuriosityX;
float _SwimA, _SwimB, _SwimC;

bool HasFood(float lane)
{
    if (_FeedFishMask < 0) return lane <= _FeedFishCount;
    float bits = floor(_FeedFishMask / exp2(lane - 1));
    return fmod(bits, 2.0) > 0.5;
}

float SwimLane(float species)
{
    if (abs(species - _SwimA) < 0.25) return 1;
    if (abs(species - _SwimB) < 0.25) return 2;
    if (abs(species - _SwimC) < 0.25) return 3;
    return 0;
}

// Cruise speed, vertical offset, and bob height in metres.
float3 SpeciesMotion(float species)
{
    if (species < 2.5) return float3(1,0,.021);
    if (species < 3.5) return float3(.76,-.045,.009); // Corydoras
    if (species < 4.5) return float3(1.10,.005,.029); // Clownfish
    if (species < 5.5) return float3(.72,.003,.012); // Boxfish
    if (species < 6.5) return float3(1.20,.015,.019); // Blue tang
    if (species < 7.5) return float3(.90,-.004,.016); // Moorish idol
    if (species < 8.5) return float3(.61,-.009,.012); // Lionfish
    if (species>23.5) return float3(.74,.012,.023); // River dragon
    if (species>22.5) return float3(.83,-.028,.012); // Sturgeon
    if (species>21.5) return float3(.69,.008,.016); // Discus
    if (species>20.5) return float3(1.24,.005,.014); // Sailfish
    if (species>19.5) return float3(.86,.013,.026); // Angelfish
    if (species>18.5) return float3(1.18,.024,.029); // Flying fish
    if (species>17.5) return float3(.94,-.041,.010); // Loach
    if (species>16.5) return float3(.92,.008,.021); // Butterflyfish
    if (species>15.5) return float3(.62,.018,.010); // Crown arowana
    if (species>14.5) return float3(.72,.004,.025); // Aurora manta
    if (species>13.5) return float3(1.27,-.008,.018); // Ember swordtail
    if (species>12.5) return float3(.83,.011,.031); // Moonveil
    if (species>11.5) return float3(1.13,.012,.027); // Cometfin
    if (species>10.5) return float3(.75,-.020,.015); // Lanternfish
    if (species>9.5) return float3(.88,.006,.017); // Honey gourami
    return float3(.84,.008,.012); // Koi
}

void IdleFish(float kind, float species, float time, out float3 center, out float3 heading)
{
    float3 motion=SpeciesMotion(species);
    float angle=time*motion.x*(kind<1.5?.34:(kind<2.5?.245:.30)) + (kind<1.5?.24:(kind<2.5?2.6:4.6));
    float sa,ca; sincos(angle,sa,ca);
    float depth=kind<1.5?.067:(kind<2.5?.045:.057);
    float height=(kind<1.5?.225:(kind<2.5?.29:.323))+motion.y;
    float radius=kind<1.5?.252:(kind<2.5?.20:.232);
    center=float3(radius*sa,height+motion.z*sin(2*angle+kind),-.026+depth*ca);
    heading=normalize(float3(radius*ca,.032*cos(2*angle+kind),-depth*sa));
}

float DropTime(float pellet)
{
    return floor(pellet*.5)*.14 + frac(pellet*.5)*.40;
}

float BiteTime(float kind, float second)
{
    return 2.55 + .58*(kind-1) + 1.45*second;
}

float3 PelletCenter(float pellet, float age)
{
    float kind=floor(pellet*.5)+1;
    float second=frac(pellet*.5)*2;
    float t=max(age-DropTime(pellet),0);
    float fall=saturate(t/.42);
    float wet=max(t-.42,0);
    float3 center;
    center.x=-.104+(kind-1)*.114 + (second-.5)*.029;
    center.z=(kind<1.5?-.045:(kind<2.5?.025:-.055)) + (second-.5)*.021;
    center.x+=lerp((.005-center.x)*.23,0,fall);
    center.y=lerp(.505,.432,fall*fall);
    // Water slows the fall; the second pellet of each pair sinks alongside the first.
    center.y-=.049*(1-exp2(-wet*.64));
    center.y+=.0024*sin(wet*8)*exp2(-wet*3);
    center.xz+=.0035*float2(sin(wet*1.6+pellet)-sin(pellet),sin(wet*1.3));
    return center;
}

float3 EatingHeading(float kind)
{
    if(kind<1.5) return normalize(float3(.90,.56,.11));
    if(kind<2.5) return normalize(float3(.49,.67,-.58));
    return normalize(float3(-.91,.48,.10));
}

float BiteReach(float age, float contact)
{
    return smoothstep(contact-.38,contact-.03,age)*(1-smoothstep(contact+.06,contact+.39,age));
}

float3 FeedingCenter(float kind, float age, float3 heading)
{
    float first=BiteTime(kind,0), second=BiteTime(kind,1);
    float i=(kind-1)*2;
    float between=smoothstep(first+.12,second-.40,age);
    float3 next=lerp(PelletCenter(i,age),PelletCenter(i+1,age),between);
    float reach=max(BiteReach(age,first),BiteReach(age,second));
    // The three meshes have their snout caps exactly 0.049 m ahead of their pivots.
    return next-heading*(.049+.028*(1-reach));
}

float3 TurnToward(float3 from, float3 to, float u)
{
    float2 a=normalize(from.xz), b=normalize(to.xz);
    float yaw=atan2(a.x*b.y-a.y*b.x,dot(a,b))*u;
    float sy,cy; sincos(yaw,sy,cy);
    float2 horizontal=float2(a.x*cy-a.y*sy,a.x*sy+a.y*cy);
    float vertical=lerp(from.y,to.y,u);
    horizontal*=sqrt(saturate(1-vertical*vertical));
    return float3(horizontal.x,vertical,horizontal.y);
}

void SwimBetween(float t, float3 a, float3 b, float3 ha, float3 hb,
                 float lane, out float3 center, out float3 heading)
{
    float3 c=a+.040*ha, d=b-.042*hb;
    c.z=lerp(c.z,lane,.27); d.z=lerp(d.z,lane,.27);
    float u=1-t;
    center=u*u*(u*a+3*t*c)+t*t*(3*u*d+t*b);
    // Each species takes a separate depth lane through the center of its route.
    center.z=lerp(center.z,lane,smoothstep(0,.39,t)*(1-smoothstep(.64,1,t)));
    // Rotate continuously even when the fish begins by facing away from the food.
    float3 travel=b-a;
    float2 across=travel.xz;
    if(dot(across,across)<.0001) across=ha.xz;
    across=normalize(across);
    float pitch=clamp(travel.y/max(length(travel),.001),-.62,.62);
    across*=sqrt(1-pitch*pitch);
    float3 route=float3(across.x,pitch,across.y);
    heading=t<.5?TurnToward(ha,route,smoothstep(0,.5,t)):TurnToward(route,hb,smoothstep(.5,1,t));
}

void FishFeedingPose(float kind, float species, float age, float time, out float3 center, out float3 heading)
{
    float react=.46+.12*(kind-1), arrival=BiteTime(kind,0)-.50;
    float departure=BiteTime(kind,1)+.36;
    const float finish=8.55;
    if(age<react || age>=finish)
    {
        IdleFish(kind,species,time,center,heading);
        return;
    }

    float3 eating=EatingHeading(kind);
    float lane=kind<1.5?-.082:(kind<2.5?.074:-.002);
    if(age<arrival)
    {
        float3 start,forward;
        IdleFish(kind,species,time-age+react,start,forward);
        SwimBetween((age-react)/(arrival-react),start,FeedingCenter(kind,arrival,eating),
                    forward,eating,lane,center,heading);
    }
    else if(age<=departure)
    {
        heading=eating;
        center=FeedingCenter(kind,age,heading);
    }
    else
    {
        float3 end,forward;
        IdleFish(kind,species,time-age+finish,end,forward);
        SwimBetween((age-departure)/(finish-departure),FeedingCenter(kind,departure,eating),end,
                    eating,forward,lane,center,heading);
    }
}

void Observe(float e, float age, inout float3 center, inout float3 direction, inout float3 p)
{
    float blend=smoothstep(0,1.45,age)*(1-smoothstep(4.5,6,age));
    float t=(age-1.35)*1.65;
    float sn,cs; sincos(t,sn,cs);
    float3 target, look;
    if (e<.5) // Neon tetra traces a figure eight between the plants.
    {
        target=float3(.125*sn,.226+.045*sin(2*t),-.099+.016*cs);
        look=float3(.125*cs,.09*cos(2*t),-.016*sn);
    }
    else if (e<1.5) // A clownfish circles the coral.
    {
        target=float3(-.17+.090*sn,.193+.038*cs,-.073+.035*cs);
        look=float3(.09*cs,-.038*sn,-.035*sn);
    }
    else if (e<2.5) // Corydoras roots through the sand in short pecks.
    {
        float peck=.5+.5*sin(3*t);
        target=float3(-.068+.030*t,.079+.015*peck,-.100);
        look=float3(.82,-.12-.55*(1-peck),.2);
    }
    else if (e<3.5) // Blue tang spirals up the thermal current.
    {
        target=float3(.105+.074*sn,.159+.023*clamp(t,0,5),-.086+.028*cs);
        look=float3(.074*cs,.024,-.028*sn);
    }
    else if (e<4.5) // Betta spreads its tail in the crystal's light.
    {
        target=float3(.02+.044*sn,.263+.019*cs,-.111);
        look=float3(.90,.13*cs,.27*sn);
        p.y*=1+.55*blend*saturate((-.010-p.x)/.05);
    }
    else if (e<5.5) // Gourami rises under an opening in the ice and drifts away.
    {
        target=float3(-.13+.032*sn,.335+.046*cs,-.075+.019*sn);
        look=float3(.032*cs,-.046*sn,.019*cs+.015);
    }
    else if (e<6.5) // Koi passes through the old observatory's brass ring.
    {
        target=float3(.045+.045*sn,.199+.015*cs,.060+.043*sin(t*.8));
        look=float3(.045*cs,-.015*sn,.0344*cos(t*.8));
    }
    else if (e<7.5) // Follow the lights beneath the mushroom caps.
    {
        target=float3(-.19+.063*sn,.158+.022*cs,.061+.025*cs);
        look=float3(.063*cs,-.022*sn,-.025*sn+.002);
    }
    else if (e<8.5) // Trace the low arc above the comet pool.
    {
        target=float3(.03+.105*sn,.253+.032*cs,.052+.018*sn);
        look=float3(.105*cs,-.032*sn,.018*cs+.002);
    }
    else if (e >= 9.5) // Eight late-game journal entries. Each route stays in front of its landmark.
    {
        float route = floor(e+.5)-10;
        float3 origin, horizontal, vertical;
        if (route<.5) { origin=float3(-.17,.173,.042); horizontal=float3(.092,0,0); vertical=float3(0,.063,.012); }
        else if (route<1.5) { origin=float3(-.12,.10,.024); horizontal=float3(.121,.011,0); vertical=float3(0,.015,.033); }
        else if (route<2.5) { origin=float3(.012,.208,.02); horizontal=float3(.131,.090,0); vertical=float3(0,.032,.033); }
        else if (route<3.5) { origin=float3(.091,.176,.031); horizontal=float3(.087,0,.010); vertical=float3(0,.024,.039); }
        else if (route<4.5) { origin=float3(0,.185,.025); horizontal=float3(.126,.022,0); vertical=float3(0,.066,.017); }
        else if (route<5.5) { origin=float3(-.016,.193,.064); horizontal=float3(.069,0,0); vertical=float3(0,.064,.012); }
        else if (route<6.5) { origin=float3(0,.149,.036); horizontal=float3(.146,.032,.014); vertical=float3(0,.046,.032); }
        else { origin=float3(.107,.163,.043); horizontal=float3(.062,0,.032); vertical=float3(0,.021,.049); }
        target=origin+horizontal*sn+vertical*cs;
        look=horizontal*cs-vertical*sn;
    }
    else
    {
        float side=_CuriosityX>.08?-1:1;
        target=float3(_CuriosityX+.064*side,.139+.008*cs,-.104);
        look=float3(-side,-.46,.05);
    }
    center=lerp(center,target,blend);
    direction=TurnToward(direction,normalize(look),blend);
}

void AquariumFishPose(float lane, float species, float time, out float3 center, out float3 heading, inout float3 p)
{
    FishFeedingPose(lane,species,HasFood(lane)?_FeedAge:-1,time,center,heading);
    if (_Observation>=0 && abs(species-_WatchingFish)<.25 && _FeedAge<0)
        Observe(_Observation,_ObservationAge,center,heading,p);
}

#endif

using UdonSharp;
using UnityEngine;
using VRC.Udon;

[UdonBehaviourSyncMode(BehaviourSyncMode.None)]
public class StarSeaAquariumButton : UdonSharpBehaviour
{
    public UdonBehaviour TargetUdonBehaviour;
    public string EventName;

    public override void Interact()
    {
        if (TargetUdonBehaviour != null && !string.IsNullOrEmpty(EventName))
            TargetUdonBehaviour.SendCustomEvent(EventName);
    }
}

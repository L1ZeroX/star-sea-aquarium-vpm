param(
    [string]$ProgramPath = (Join-Path $PSScriptRoot 'StarSea-Sync.exe'),
    [Parameter(Mandatory=$true)][ipaddress]$LocalIp
)
$ErrorActionPreference = 'Stop'
$application = (Resolve-Path -LiteralPath $ProgramPath).Path
if ([IO.Path]::GetFileName($application) -ne 'StarSea-Sync.exe') { throw 'Choose the StarSea-Sync executable.' }
$address = Get-NetIPAddress -AddressFamily IPv4 -IPAddress $LocalIp.IPAddressToString
if (@($address).Count -ne 1) { throw 'Select the IP shown on the PC tool.' }
$octets = $LocalIp.GetAddressBytes()
$isPrivate = ($octets[0] -eq 10) -or ($octets[0] -eq 192 -and $octets[1] -eq 168) -or ($octets[0] -eq 172 -and $octets[1] -ge 16 -and $octets[1] -le 31)
if (!$isPrivate) { throw 'Only private LAN addresses can be used.' }
$prefix = [int]$address.PrefixLength
if ($prefix -lt 8 -or ($octets[0] -eq 172 -and $prefix -lt 12) -or ($octets[0] -eq 192 -and $prefix -lt 16)) { throw 'Home subnet is too broad.' }
for ($i=0; $i -lt 4; $i++) {
    $remaining = [Math]::Min(8,[Math]::Max(0,$prefix - 8*$i))
    $octets[$i] = $octets[$i] -band ((255 -shl (8-$remaining)) -band 255)
}
$subnet = ($octets -join '.') + '/' + $prefix
$sha = [Security.Cryptography.SHA256]::Create()
try {
    $hash = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($application.ToLowerInvariant()))
    $suffix = [BitConverter]::ToString($hash,0,6).Replace('-','')
} finally { $sha.Dispose() }
$ruleName = 'StarSea.Sync.Home.' + $suffix + '.' + $address.IPAddress

$rule = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
if (!$rule) {
    New-NetFirewallRule -Name $ruleName -DisplayName 'Star Sea Sync - home LAN' -Direction Inbound -Action Allow -Enabled True -Profile Private,Public -Program $application -InterfaceAlias $address.InterfaceAlias -Protocol TCP -LocalPort 38451 -LocalAddress $address.IPAddress -RemoteAddress $subnet -EdgeTraversalPolicy Block | Out-Null
}
# Windows creates a program-wide block when a previous firewall prompt was dismissed.
# Keep that automatic rule blocking every other TCP port. Leave custom rules alone.
$automatic = Get-NetFirewallApplicationFilter -Program $application -ErrorAction SilentlyContinue | Get-NetFirewallRule | Where-Object {
    $_.Name -like 'TCP Query User*' -and $_.Direction -eq 'Inbound' -and $_.Action -eq 'Block' -and $_.Enabled -eq 'True'
}
foreach ($entry in $automatic) {
    $port = $entry | Get-NetFirewallPortFilter
    if ($port.Protocol -eq 'TCP' -and ($port.LocalPort -join ',') -eq 'Any') {
        $entry | Set-NetFirewallRule -Protocol TCP -LocalPort '1-38450','38452-65535' | Out-Null
    }
}
Write-Output "Allowed Star Sea Sync TCP 38451 from $subnet on $($address.InterfaceAlias)."

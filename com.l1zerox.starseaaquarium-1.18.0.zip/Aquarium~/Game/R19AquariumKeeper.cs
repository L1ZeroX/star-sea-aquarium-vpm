using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Persistence;
using VRC.SDKBase;

[UdonBehaviourSyncMode(BehaviourSyncMode.None)]
public class R19AquariumKeeper : UdonSharpBehaviour
{
    public Text statusText;
    public Text feedText;
    public Image[] xpSegments;
    public GameObject[] fish;

    public GameObject[] pages;
    public Text walletText, shellWallet, sandWallet;
    public Text stageText;
    public Text stageActionText;
    public Text shopText;
    public Text shopActionText;
    public Text fishInfoText;
    public Text fishActionText;
    public Text coinRateText;
    public RectTransform coinProgress, mealProgress;
    public RawImage fishPreview;
    public Image[] tabHighlights;
    public GameObject[] habitats;

    public Text journalTitle, journalNote, journalAction, decorTitle, decorNote, decorPlace, decorAction;
    public Text nameTitle, nameMessage;
    public RawImage journalStamp, namePortrait;
    public Text[] rosterTexts;
    public RawImage[] rosterPortraits;
    public TMPro.TMP_InputField nameInput;
    public GameObject nameCanvas;
    public GameObject[] ornaments;
    public Image[] collectionTabs;

    private string[] petNames = new string[SpeciesCount];
    private int[] entryFish = { 0, 4, 3, 6, 2, 10, 9, 11, 12, 17,18,19,20,21,22,23,24, 17, 18, 19, 20, 21, 22, 23, 24 };
    private string[] entryTitles = { "木漏れ日の八の字", "サンゴをひとめぐり", "砂に残るひげの跡", "熱水に乗って", "星色の扇", "氷の窓辺", "星環をくぐって", "胞子の灯を追って", "彗星と並んで", "珊瑚にかかる月", "砂底の瑠璃線", "風を切る胸びれ", "花霞のひと休み", "氷の下の帆", "結晶に重なる日輪", "遺跡の銀の列", "天の川を渡るひげ", "三日月の内側", "瑠璃の谷底", "流星を追う翼", "花びらのあいだ", "氷壁をぬけて", "陽輪の一巡", "銀の標を巡る", "竜宮の門くぐり" };
    private string[] entryHints = { "青いしまの魚が、水草の間で\n八の字を描くらしい。", "白い帯の魚が、サンゴの周りを\nくるりと回るらしい。", "沈船の砂に、小さなひげの跡。\n白黒の魚を探してみよう。", "青い体に黄色い尾の魚が\n熱水の上昇流を好むらしい。", "バラ色の尾を持つ魚が\n結晶の光に反応するらしい。", "蜂蜜色の魚が氷の隙間で\n水面をのぞくらしい。", "星模様の鯉が遺跡の環を\nくぐるのを見てみよう。", "灯りを帯びた魚が、きのこの下で\n光の粒を追うらしい。", "二股の尾を持つ魚が潮だまりで\n彗星と並んで泳ぐらしい。",
        "月模様の魚が珊瑚を巡る。", "瑠璃色のひげが沈船の砂を探る。", "大きな胸びれが彗星を追う。", "花色のひれがきのこの下で揺れる。", "氷の海で青い帆を探そう。", "結晶の前で金の円を探そう。", "銀の背びれが遺跡の環をくぐる。", "長いひげが潮だまりの星をなぞる。", "月輪の魚が、三日月の環をたどる。", "青いひげの魚が、洞窟の底を探る。", "飛ぶ魚が、流星の跡を駆け上がる。", "花色の魚が、開いた花を一周する。", "青い帆の魚が、二つの氷壁を抜ける。", "丸い金の魚が、神殿の円盤をなぞる。", "銀の背びれの魚が、航路の標を巡る。", "天の川の魚が、竜宮の門をくぐる。" };
    private string[] decorNames = { "苔むした流木", "泡の宝箱", "小さな月面基地" };
    private string[] decorDescriptions = { "枝の間に小さな水草が育つ。", "ふたが開くと、魚が泡を見に来る。", "青い窓がともる観測ドーム。" };
    private int[] decorCosts = { 25, 80, 180 };
    private string[] positionNames = { "左", "中央", "右" };
    private int discoveries, ownedDecor, decorLayout, journalEntry, decorItem, nameLane;
    private int decorPosition = 1;
    private int activity = -1;
    private float nextActivity, activityStart;
    private bool activityTickPending, lastWasEntry;
    private Material chestMaterial;


    public Text feederStatus, feederAction;
    private const int FeederPrice = 100;
    private const int FeederOff = 1;
    private const int FeederOn = 2;
    private int feederState;
    private long firstAutoFeed;
    private bool autoTickPending;


    public RectTransform[] swimTags;
    public Text[] swimNames;
    public Image[] swimTagBacks, swimTracks, swimFills;
    public RawImage[] swimRarityBadges;
    private Material[] tagMaterials = new Material[3];
    private const int BaseFishCap = 20;
    private const int OriginalFishCount = 11;
    private int[] growthQuarters = new int[SpeciesCount];
    private const int ExpeditionFishCount = 13;
    private const int LaneBits = 5;
    private const int LaneMask = (1 << LaneBits) - 1;
    private const string PageTipsKey = "r19.aquarium.seenTips";
    private const int ExpeditionTip = 1, EnchantTip = 2;
    private int seenPageTips;
    private float pageTipUntil;

    private const string SaveKey = "r19.aquarium.v23";
    private const string IceShellKey = "r19.aquarium.v22";
    private const string IceSandKey = "r19.aquarium.v21";
    private const string ExpeditionCargoKey = "r19.aquarium.v20";
    private const string VeteransKey = "r19.aquarium.v19";
    private const string FeedCapKey = "r19.aquarium.v18";
    private const string MealGrowthKey = "r19.aquarium.v17";
    private const string HabitatsKey = "r19.aquarium.v16";
    private const string Level100Key = "r19.aquarium.v15";
    private const string RareFishKey = "r19.aquarium.v14";
    private const int RareFishCount = 17;
    private const int SpeciesCount = 25;
    private const string ExpeditionKey = "r19.aquarium.v13";
    private const string HousingKey = "r19.aquarium.v12";
    private const string BankKey = "r19.aquarium.v11";
    private const string EnchantsKey = "r19.aquarium.v10";
    private const string RewardsKey = "r19.aquarium.v9";
    private const string AchievementsKey = "r19.aquarium.v8";
    private const string GrowthKey = "r19.aquarium.v7";
    private const string FeederKey = "r19.aquarium.v6";
    private const string CollectionKey = "r19.aquarium.v5";
    private const string PreviousKey = "r19.aquarium.v4";
    private const string FishKey = "r19.aquarium.v3";
    private const string EconomyKey = "r19.aquarium.v2";
    private const string LegacyKey = "r19.aquarium.v1";
    private const int CoinCap = 999999;
    // 138,600 is a common multiple of all the habitat coin intervals.
    private const int CoinPeriodBase = 138600;
    private const int LegacyCoinUnits = CoinPeriodBase * 100;
    private const int UnitsPerCoin = LegacyCoinUnits * 4;
    private const int UnitsPerXP = 1600;
    private const int BaseFeedCoins = 2;
    private const int StageCount = 17;
    private const int OriginalStageCount = 9;
    private const int PreviousEntryCount = 17;
    private const int ChestActivity = 25;
    private int[] entryStages = { 0,1,2,3,4,5,6,7,8, 1,2,8,7,5,4,6,8, 9, 10, 11, 12, 13, 14, 15, 16 };
    private Texture fieldNotesTexture;
    private const int MaxFoodRank = 20;
    private string[] stageNames = { "水草の小川", "珊瑚の浅瀬", "沈船の入り江", "深海の熱水域", "星晶の洞窟", "月虹の氷海", "星降る海底遺跡", "夜光きのこの森", "彗星の潮だまり", "月影の環礁", "瑠璃の鐘乳洞", "流星の岩礁", "花霞の海庭", "氷帆の海峡", "日輪の神殿", "銀河の航路", "天河の竜宮" };
    private string[] multipliers = { "1", "1.25", "1.5", "1.75", "2", "2.25", "2.5", "2.75", "3", "3.25", "3.5", "3.75", "4", "4.25", "4.5", "4.75", "5" };
    private int[] stageLevels = { 1, 2, 4, 7, 10, 13, 16, 18, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
    private int[] stagePrices = { 0, 20, 80, 200, 450, 720, 1100, 1600, 2500, 6500, 12500, 22000, 36000, 54000, 80000, 115000, 160000 };
    private int[] stageCoinIntervals = { 60, 55, 50, 45, 40, 35, 30, 25, 20, 18, 15, 14, 12, 11, 10, 9, 7 };
    private int[] foodPrices = { 15, 40, 90, 180, 360 };
    private string[] fishNames = { "ネオンテトラ", "ゴールデンエンゼル", "ローズベタ", "パンダコリドラス", "カクレクマノミ",
        "ミナミハコフグ", "ナンヨウハギ", "ツノダシ", "ミノカサゴ", "星錦鯉", "ハニーグラミー", "ランタンフィッシュ", "コメットフィン", "月虹ベールフィン", "紅蓮ソードテール", "極光マンタ", "星冠アロワナ",
        "月輪チョウチョウウオ", "瑠璃ドジョウ", "流星トビウオ", "花霞エンゼル", "氷帆カジキ", "日輪ディスカス", "銀河チョウザメ", "天河リュウギョ" };
    private int[] shopOrder = { 0,1,10,2,3,4,5,6,7,11,8,12,9, 13,14,15,16, 17,18,19,20,21,22,23,24 };
    private int[] fishLevels = { 1, 2, 5, 6, 8, 10, 12, 15, 18, 20, 3, 17, 19, 20, 20, 20, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
    private int[] fishPrices = { 0, 10, 60, 90, 150, 220, 320, 450, 650, 900, 30, 750, 1100, 3600, 7200, 14000, 26000, 39000, 54000, 72000, 96000, 128000, 170000, 235000, 320000 };
    private int[] fishBonuses = { 0, 5, 10, 15, 20, 25, 30, 35, 40, 50, 8, 42, 55, 62, 72, 85, 100, 112, 124, 137, 150, 164, 179, 194, 210 };
    private const int LaneCount = 3;
    private const int FeedBonus = 150;
    private const int FeedInterval = 60;
    private const long TicksPerSecond = 10000000L;
    private bool feedTickPending;
    private const int AwayLimit = 8 * 60 * 60;
    private const int CheckpointInterval = 300;
    private const int PlayerLevelCap = 100;
    private const int Level20XP = 1728000;
    private const int FirstNewLevelCost = 450000;
    private const int LevelCostStep = 15000;
    private const int ExtraLevels = PlayerLevelCap - 20;
    private const int MaxXP = Level20XP + ExtraLevels * FirstNewLevelCost + (ExtraLevels - 1) * ExtraLevels / 2 * LevelCostStep;
    private int[] levelXP = { 0, 300, 1200, 3600, 7200, 14400, 21600, 32400, 46800, 64800,
        86400, 129600, 194400, 280800, 388800, 518400, 691200, 950400, 1296000, Level20XP };

    private bool restoredEvent;
    private bool ready;
    private bool invalidSave;
    private int experience;
    private int coins;
    // Keep partial rewards in common units across all fish and stage multipliers.
    private int coinRemainder; // UnitsPerCoin units per coin.
    private int xpRemainder;   // UnitsPerXP units per XP.
    private int ownedMask = 1;
    private int currentStage;
    private int selectedStage;
    private int foodRank;
    private int ownedFishMask = 1;
    // Each five-bit lane stores the species index + 1. Empty lanes contain zero.
    private int packedSlots = 1;
    private int displayMask = 1;
    private int displayCount = 1;
    private int displayXPBonus, displayCoinBonus;
    private int veteranCount;
    // Owned fish keep this passive in reserve and on expeditions.
    private int VeteranPercent() { return 100 + 2 * veteranCount; }
    private string VeteranSummary()
    {
        return "熟練魚 " + veteranCount + "匹　収入 ×" + Hundredths(VeteranPercent()) + "　レア以上 +" + Hundredths(veteranCount * 20) + "pt";
    }
    private int visibleSlots = -1;
    private int selectedFish = 1;
    private int page;
    private bool dirty;
    private float nextTransaction;
    private BoxCollider feedCollider;
    private int awayGain;
    private long cursor;
    private long lastFeed;
    private long lastCheckpoint;
    private long returnBannerUntil;
    private long feedBannerUntil;
    private int feedAward;
    private const long MealScale = 1000000L;
    private long feedAnchor, storedMeals, storedXPUnits, storedCoinUnits, storedGrowthUnits;
    private int[] mealGrowthQuarters = new int[LaneCount];
    private int growthTagMask;
    private Material mealMaterial;
    private GameObject morsels;
    private float mealStart;
    private bool mealPlaying;
    private const float MealDuration = 9f;

    private long Now()
    {
        return Networking.GetNetworkDateTime().Ticks / TicksPerSecond;
    }

    private const string NightKey = "r19.aquarium.night";
    private const string LightModeKey = "r19.aquarium.lightMode";
    private const int Day = 0, Night = 1, Ultraviolet = 2;
    private const float LightFadeSeconds = .8f;
    [HideInInspector] public Text nightLabel;
    public RawImage nightSwitchIcon;
    public Texture2D uvSwitchTexture;
    public Image[] nightPanelShades;
    private Texture dayNightIcons;
    private int lightMode;
    private bool lightEditedBeforeRestore, lightFadePending;
    private float nightAmount, uvAmount, nightFadeFrom, uvFadeFrom, lightFadeStart;

    // Existing prefabs and interaction relays use this event name.
    public void ToggleAquariumNight()
    {
        lightMode = (lightMode + 1) % 3;
        if (restoredEvent) PlayerData.SetInt(LightModeKey, lightMode);
        else lightEditedBeforeRestore = true;
        UpdateLightIcon();
        lightFadeStart = Time.unscaledTime;
        nightFadeFrom = nightAmount;
        uvFadeFrom = uvAmount;
        if (!lightFadePending) FadeAquariumNight();
    }

    private void UpdateLightIcon()
    {
        if (nightSwitchIcon != null)
        {
            if (dayNightIcons == null) dayNightIcons = nightSwitchIcon.texture;
            bool offerUV = lightMode == Night && uvSwitchTexture != null;
            nightSwitchIcon.texture = offerUV ? uvSwitchTexture : dayNightIcons;
            nightSwitchIcon.uvRect = offerUV ? new Rect(0f, 0f, 1f, 1f)
                : new Rect(lightMode == Day ? 0f : .5f, 0f, .5f, 1f);
        }
        if (nightLabel != null)
            nightLabel.text = lightMode == Day ? "ナイト" : (lightMode == Night ? "UVライト" : "通常照明");
    }

    public void FadeAquariumNight()
    {
        float t = Mathf.Clamp01((Time.unscaledTime - lightFadeStart) / LightFadeSeconds);
        float ease = Mathf.SmoothStep(0f, 1f, t);
        ApplyLighting(Mathf.Lerp(nightFadeFrom, lightMode == Night ? 1f : 0f, ease),
                      Mathf.Lerp(uvFadeFrom, lightMode == Ultraviolet ? 1f : 0f, ease));
        lightFadePending = t < 1f;
        if (lightFadePending) SendCustomEventDelayedFrames(nameof(FadeAquariumNight), 1);
    }

    private void ApplyLighting(float night, float uv)
    {
        nightAmount = night;
        uvAmount = uv;
        VRCShader.SetGlobalFloat(VRCShader.PropertyToID("_UdonR19AquariumNight"), night);
        VRCShader.SetGlobalFloat(VRCShader.PropertyToID("_UdonR19AquariumUV"), uv);
        if (nightPanelShades == null) return;
        float opacity = .83f * night + .16f * uv;
        for (int i = 0; i < nightPanelShades.Length; i++)
        {
            Image shade = nightPanelShades[i];
            if (shade == null) continue;
            shade.color = new Color(0f, 0f, 0f, opacity);
            shade.enabled = opacity > 0f;
        }
    }

    public Camera tubeShadowCamera;
    public Shader tubeDepthShader;

    private void UpdateTubeShadows()
    {
        if (!Utilities.IsValid(tubeShadowCamera) || !Utilities.IsValid(tubeDepthShader)) return;
        VRCPlayerApi player = Networking.LocalPlayer;
        bool nearby = Utilities.IsValid(player) && (player.GetPosition() - transform.position).sqrMagnitude < 64f;
        if (tubeShadowCamera.enabled == nearby) return;
        if (nearby)
        {
            tubeShadowCamera.SetReplacementShader(tubeDepthShader, "R19TubeCaster");
            VRCShader.SetGlobalMatrix(VRCShader.PropertyToID("_UdonR19TubeView"), tubeShadowCamera.worldToCameraMatrix);
            VRCShader.SetGlobalTexture(VRCShader.PropertyToID("_UdonR19TubeMap"), tubeShadowCamera.targetTexture);
        }
        tubeShadowCamera.enabled = nearby;
        VRCShader.SetGlobalFloat(VRCShader.PropertyToID("_UdonR19TubeActive"), nearby ? 1f : 0f);
    }

    private void Start()
    {
        ApplyLighting(lightMode == Night ? 1f : 0f, lightMode == Ultraviolet ? 1f : 0f);
        UpdateLightIcon();
        UpdateTubeShadows();
        feedCollider = GetComponent<BoxCollider>();
        ApplyPages();
        if (!ready && !invalidSave) ShowLoading();
        SendCustomEventDelayedSeconds(nameof(RefreshTank), 5f);
    }

    private void ShowLoading()
    {
        if (statusText != null) statusText.text = "飼育データ\n読み込み中…";
        if (feedText != null) feedText.text = "えさやり\n準備中";
        ShowWallet(false);
        ApplySwimmers();
        SetBar(0, 1);
    }

    public override void OnPlayerRestored(VRCPlayerApi player)
    {
        if (!Utilities.IsValid(player) || !player.isLocal || restoredEvent) return;
        restoredEvent = true;
        if (PlayerData.HasKey(player, PageTipsKey))
            seenPageTips = PlayerData.GetInt(player, PageTipsKey);
        if (lightEditedBeforeRestore)
            PlayerData.SetInt(LightModeKey, lightMode);
        else
        {
            if (PlayerData.HasKey(player, LightModeKey))
                lightMode = Mathf.Clamp(PlayerData.GetInt(player, LightModeKey), Day, Ultraviolet);
            else if (PlayerData.HasKey(player, NightKey) && PlayerData.GetBool(player, NightKey))
                lightMode = Night;
            ApplyLighting(lightMode == Night ? 1f : 0f, lightMode == Ultraviolet ? 1f : 0f);
            UpdateLightIcon();
        }
        Restore();
    }

    private void Restore()
    {
        long now = Now();
        if (now <= 0L) return;
        VRCPlayerApi player = Networking.LocalPlayer;
        if (!Utilities.IsValid(player)) return;

        int version = 0;
        string key = SaveKey;
        if (PlayerData.HasKey(player, TransferSaveKey)) { version = 24; key = TransferSaveKey; }
        else if (PlayerData.HasKey(player, SaveKey)) version = 23;
        else if (PlayerData.HasKey(player, IceShellKey)) { version = 22; key = IceShellKey; }
        else if (PlayerData.HasKey(player, IceSandKey)) { version = 21; key = IceSandKey; }
        else if (PlayerData.HasKey(player, ExpeditionCargoKey)) { version = 20; key = ExpeditionCargoKey; }
        else if (PlayerData.HasKey(player, VeteransKey)) { version = 19; key = VeteransKey; }
        else if (PlayerData.HasKey(player, FeedCapKey)) { version = 18; key = FeedCapKey; }
        else if (PlayerData.HasKey(player, MealGrowthKey)) { version = 17; key = MealGrowthKey; }
        else if (PlayerData.HasKey(player, HabitatsKey)) { version = 16; key = HabitatsKey; }
        else if (PlayerData.HasKey(player, Level100Key)) { version = 15; key = Level100Key; }
        else if (PlayerData.HasKey(player, RareFishKey)) { version = 14; key = RareFishKey; }
        else if (PlayerData.HasKey(player, ExpeditionKey)) { version = 13; key = ExpeditionKey; }
        else if (PlayerData.HasKey(player, HousingKey)) { version = 12; key = HousingKey; }
        else if (PlayerData.HasKey(player, BankKey)) { version = 11; key = BankKey; }
        else if (PlayerData.HasKey(player, EnchantsKey)) { version = 10; key = EnchantsKey; }
        else if (PlayerData.HasKey(player, RewardsKey)) { version = 9; key = RewardsKey; }
        else if (PlayerData.HasKey(player, AchievementsKey)) { version = 8; key = AchievementsKey; }
        else if (PlayerData.HasKey(player, GrowthKey)) { version = 7; key = GrowthKey; }
        else if (PlayerData.HasKey(player, FeederKey)) { version = 6; key = FeederKey; }
        else if (PlayerData.HasKey(player, CollectionKey)) { version = 5; key = CollectionKey; }
        else if (PlayerData.HasKey(player, PreviousKey)) { version = 4; key = PreviousKey; }
        else if (PlayerData.HasKey(player, FishKey))
        {
            version = 3;
            key = FishKey;
        }
        else if (PlayerData.HasKey(player, EconomyKey))
        {
            version = 2;
            key = EconomyKey;
        }
        else if (PlayerData.HasKey(player, LegacyKey))
        {
            version = 1;
            key = LegacyKey;
        }
        if (version > 0)
        {
            string record;
            if (!PlayerData.TryGetString(player, key, out record) || !ReadRecord(record, version))
            {
                invalidSave = true;
                if (statusText != null) statusText.text = "飼育データを\n読み取れません";
                if (feedText != null) feedText.text = "えさやり\n保留中";
                ShowWallet(false);
                ApplySwimmers();
                SetBar(0, 1);
                return;
            }
        }
        else cursor = now;

        RecountDisplay();
        long snapshot = cursor;
        lastCheckpoint = snapshot;
        if (version < 11)
        {
            // A new tank gets one serving immediately. A returning tank keeps its last feeding time.
            feedAnchor = lastFeed > 0 ? lastFeed : snapshot;
            if (lastFeed == 0) StoreMeals(1, false);
            BankThrough(snapshot, false);
        }
        if (now > snapshot)
        {
            long elapsed = now - snapshot;
            if (elapsed > AwayLimit) elapsed = AwayLimit;
            int before = experience;
            CreditTime(elapsed, true);
            // Food keeps accumulating throughout an absence, including time beyond the passive growth window.
            BankThrough(now, true);
            cursor = now;
            if (elapsed >= 60L)
            {
                awayGain = experience - before;
                returnBannerUntil = now + 15L;
            }
        }
        ready = true;
        ApplyTankBody(activeTank);
        if (!Utilities.IsValid(tagMaterials[0])) InitSwimTags();
        selectedStage = currentStage;
        nextActivity = Time.time + 12f;
        ApplyDecorations();
        RefreshRoster();
        ApplyHabitat();
        ApplySwimmers();
        ApplyPages();
        // XP, coins, fractional carries and their common time cursor form one checkpoint.
        if (version != 23 || now > snapshot || paidAwards != awardBits) Save();
        if (feederState == FeederOn) StartFeeder(now);
        RefreshDisplay(now);
    }

    private bool ReadRecord(string record, int version)
    {
        if (string.IsNullOrEmpty(record)) return false;
        string[] fields = record.Split(new char[] { '|' });
        int savedSpeciesCount = version >= 15 ? SpeciesCount : version == 14 ? RareFishCount : version == 13 ? ExpeditionFishCount : version >= 8 ? OriginalFishCount : 10;
        if (version >= 5 && fields.Length != (version == 5 ? 24 : version == 6 ? 25 : version == 7 ? 35 : version == 8 ? 38 : version == 9 ? 39 : version == 10 ? 50 : version == 11 ? 54 : version == 12 ? 56 : version == 13 ? 69 : 63 + 3*(savedSpeciesCount-OriginalFishCount) + (version >= 24 ? 5 : version >= 23 ? 4 : version >= 20 ? 3 : version >= 17 ? 1 : 0))) return false;
        if (version >= 6 && (!int.TryParse(fields[version >= 8 ? 25 : 24], out feederState) || feederState < 0 || feederState > FeederOn)) return false;
        bool hasSlots = version >= 5 || (version >= 3 && fields.Length == 11);
        if (!hasSlots && (version == 4 || fields.Length != (version == 1 ? 3 : version == 2 ? 9 : 10))) return false;
        int xp;
        long snapshot;
        long fed;
        if (!int.TryParse(fields[0], out xp) || !long.TryParse(fields[1], out snapshot) ||
            !long.TryParse(fields[2], out fed)) return false;
        if (xp < 0 || xp > (version >= 15 ? MaxXP : Level20XP) || snapshot <= 0L || snapshot > 315537897599L ||
            fed < 0L || fed > snapshot) return false;
        // Older tanks granted these fish at the checkpoint's level. Award away XP afterwards.
        int savedFishMask = xp >= levelXP[4] ? 7 : xp >= levelXP[1] ? 3 : 1;
        if (version >= 3 && (!int.TryParse(fields[9], out savedFishMask) ||
            savedFishMask < 1 || savedFishMask >= (hasSlots ? (1 << savedSpeciesCount) : 8) || (savedFishMask & 1) == 0)) return false;
        int savedSlots = 1;
        if (hasSlots)
        {
            if (!int.TryParse(fields[10], out savedSlots)) return false;
            if (version < 14)
            {
                if (savedSlots <= 0 || savedSlots > 4095) return false;
                int previous = savedSlots;
                savedSlots = 0;
                for (int lane=0; lane<LaneCount; lane++)
                    savedSlots |= ((previous >> (4*lane)) & 15) << (LaneBits*lane);
            }
            if (!ValidLineup(savedSlots, savedFishMask)) return false;
        }
        else
        {
            if ((savedFishMask & 2) != 0) savedSlots |= 2 << LaneBits;
            if ((savedFishMask & 4) != 0) savedSlots |= 3 << (2*LaneBits);
        }
        if (version >= 2)
        {
            int savedCoins, seconds, quarters, owned, stage, rank;
            if (!int.TryParse(fields[3], out savedCoins) || !int.TryParse(fields[4], out seconds) ||
                !int.TryParse(fields[5], out quarters) || !int.TryParse(fields[6], out owned) ||
                !int.TryParse(fields[7], out stage) || !int.TryParse(fields[8], out rank)) return false;
            if (savedCoins < 0 || savedCoins > CoinCap || seconds < 0 || seconds >= (version >= 12 ? UnitsPerCoin : version >= 8 ? LegacyCoinUnits : version >= 4 ? 1980000 : hasSlots ? 6000 : 60) ||
                quarters < 0 || quarters >= (version >= 12 ? UnitsPerXP : hasSlots ? 400 : 4) || owned < 1 || owned >= (version >= 16 ? 1 << StageCount : version >= 13 ? 1 << OriginalStageCount : version >= 8 ? 128 : 32) ||
                (owned & 1) == 0 || stage < 0 || stage >= StageCount || (owned & (1 << stage)) == 0 ||
                rank < 0 || rank > (version >= 18 ? MaxFoodRank : foodPrices.Length)) return false;
            coins = savedCoins;
            coinRemainder = version >= 8 ? seconds : version >= 4 ? seconds * 7 : seconds * (hasSlots ? LegacyCoinUnits / 6000 : LegacyCoinUnits / 60);
            xpRemainder = hasSlots ? quarters : quarters * 100;
            if (version < 12) { coinRemainder *= 4; xpRemainder *= 4; }
            ownedMask = owned;
            currentStage = stage;
            foodRank = rank;
        }
        if (version >= 13 && !ReadVoyage(fields, savedFishMask, savedSlots, snapshot, savedSpeciesCount, version)) return false;
        if (version >= 5 && !ReadCollection(fields, version)) return false;
        if (version >= 7)
        {
            for (int i = 0; i < (version >= 8 ? OriginalFishCount : 10); i++)
            {
                int seconds;
                if (!int.TryParse(fields[(version >= 8 ? 26 : 25) + i], out seconds) || seconds < 0 || seconds > FishThreshold(FishCap(i)) / (version < 12 ? 4 : 1)
                    || (seconds > 0 && (savedFishMask & (1 << i)) == 0)) return false;
                growthQuarters[i] = version < 12 ? seconds * 4 : seconds;
            }
        }
        if (version >= 8 && (!int.TryParse(fields[37], out awardBits) || awardBits < 0 || awardBits >= 1 << awardGoals.Length)) return false;
        if (version >= 9 && (!int.TryParse(fields[38], out paidAwards) || paidAwards < 0 || (paidAwards & ~awardBits) != 0)) return false;
        if (version >= 10)
            for (int i = 0; i < OriginalFishCount; i++)
            {
                int effect;
                if (!int.TryParse(fields[39+i], out effect) || effect < 0 || effect >= enchantNames.Length
                    || (effect != 0 && (savedFishMask & (1 << i)) == 0)) return false;
                enchantments[i] = effect;
            }
        if (version >= 23 &&
            (!int.TryParse(fields[fields.Length - (version >= 24 ? 2 : 1)], out stockRank) || stockRank < 0 || stockRank > MaxStockRank)) return false;
        if (version >= 11)
        {
            if (!long.TryParse(fields[50], out feedAnchor) || feedAnchor <= 0 || feedAnchor > snapshot ||
                !long.TryParse(fields[51], out storedMeals) || storedMeals < 0 || storedMeals > 1 + feedAnchor / FeedInterval ||
                !long.TryParse(fields[52], out storedXPUnits) || !long.TryParse(fields[53], out storedCoinUnits)) return false;
            long weight = MealWeight(storedMeals) + OfflineMealBonus(storedMeals);
            if (version >= 17)
            {
                if (!long.TryParse(fields[63 + 3 * (savedSpeciesCount - OriginalFishCount)], out storedGrowthUnits) || storedGrowthUnits < 0 ||
                    storedGrowthUnits > weight * MealGrowthSeconds(foodRank)) return false;
            }
            else storedGrowthUnits = weight * MealGrowthSeconds(foodRank);
            long maxFactor = version >= 12 ? 12L : 1L;
            if (storedXPUnits < 0 || storedXPUnits > (version >= 19 ? 22500000L : version >= 18 ? 15000000L : version >= 16 ? 6000000L : version >= 15 ? 4000000L : version == 14 ? 2500000L : version >= 13 ? 2000000L : 1600000L) * weight * maxFactor ||
                storedCoinUnits < 0 || storedCoinUnits > (BaseFeedCoins + (version >= 18 ? MaxFoodRank : foodPrices.Length)) * weight * maxFactor * (version >= 19 ? 150 : 100) / 100) return false;
            if (version == 11) { storedXPUnits *= 4; storedCoinUnits *= 4; }
        }
        if (version >= 12 && (!int.TryParse(fields[54], out ownedTanks) || ownedTanks < 1 || ownedTanks >= (1 << tankNames.Length) ||
            (ownedTanks & 1) == 0 || !int.TryParse(fields[55], out activeTank) || activeTank < 0 || activeTank >= tankNames.Length ||
            (ownedTanks & (1 << activeTank)) == 0)) return false;
        if (version >= 24 && fields[fields.Length - 1] != "1") return false;
        transferImported = version >= 24;
        ownedFishMask = savedFishMask;
        packedSlots = savedSlots;
        experience = xp;
        cursor = snapshot;
        lastFeed = fed;
        return true;
    }

    private void Save()
    {
        // The updated balances and their receipt are part of one PlayerData value.
        UpdateAwards();
        PayAwardRewards();
        string record = BuildSaveRecord();
        if (transferImported) PlayerData.SetString(TransferSaveKey, record + "|1");
        else PlayerData.SetString(SaveKey, record);
        lastCheckpoint = cursor;
        dirty = false;
    }

    private string BuildSaveRecord()
    {
        string record = experience.ToString() + "|" + cursor.ToString() + "|" + lastFeed.ToString() +
            "|" + coins.ToString() + "|" + coinRemainder.ToString() + "|" + xpRemainder.ToString() +
            "|" + ownedMask.ToString() + "|" + currentStage.ToString() + "|" + foodRank.ToString() + "|" + ownedFishMask.ToString() + "|" + packedSlots.ToString();
        record += "|" + discoveries.ToString() + "|" + ownedDecor.ToString() + "|" + decorLayout.ToString();
        for (int i = 0; i < OriginalFishCount; i++) record += "|" + EncodeName(petNames[i]);
        record += "|" + feederState.ToString();
        for (int i = 0; i < OriginalFishCount; i++) record += "|" + growthQuarters[i].ToString();
        record += "|" + awardBits.ToString() + "|" + paidAwards.ToString();
        for (int i = 0; i < OriginalFishCount; i++) record += "|" + enchantments[i].ToString();
        record += "|" + feedAnchor.ToString() + "|" + storedMeals.ToString() + "|" + storedXPUnits.ToString() + "|" + storedCoinUnits.ToString();
        record += "|" + ownedTanks.ToString() + "|" + activeTank.ToString();
        record += "|" + tripFish + "|" + tripRoute + "|" + tripStart + "|" + shells + "|" + starSand + "|" + cap25 + "|" + cap30;
        for (int i=OriginalFishCount; i<fishNames.Length; i++)
            record += "|" + EncodeName(petNames[i]) + "|" + growthQuarters[i] + "|" + enchantments[i];
        return record + "|" + storedGrowthUnits + "|" + tripShells + "|" + tripSand + "|" + stockRank;
    }

    private void CreditXP(long baseAmount)
    {
        AddXPUnits(TankXPUnits(baseAmount));
    }

    private long TankXPUnits(long baseAmount)
    {
        return baseAmount * (4 + currentStage) * (100 + displayXPBonus) * tankQuarters[activeTank] * VeteranPercent() / 100;
    }

    private void AddXPUnits(long units)
    {
        if (experience >= MaxXP) return;
        units += xpRemainder;
        long whole = units / UnitsPerXP;
        int room = MaxXP - experience;
        experience += whole >= room ? room : (int)whole;
        xpRemainder = experience == MaxXP ? 0 : (int)(units - whole * UnitsPerXP);
        dirty = true;
    }

    private int FishThreshold(int level) { return 600 * level * (level - 1); }

    private int FishLevel(int id)
    {
        int level = 1;
        while (level < FishCap(id) && growthQuarters[id] >= FishThreshold(level + 1)) level++;
        return level;
    }

    private int FishBonus(int id) { return fishBonuses[id] + 2 * (FishLevel(id) - 1); }

    private void CreditTime(long elapsed, bool offline)
    {
        long at = cursor;
        // Price each slice at the bonus that was active during those seconds.
        while (elapsed > 0)
        {
            long slice = elapsed;
            bool growing = false;
            for (int lane = 0; lane < LaneCount; lane++)
            {
                int id = SpeciesAt(packedSlots, lane);
                if (id < 0) continue;
                int level = FishLevel(id);
                if (level == FishCap(id)) continue;
                growing = true;
                int remaining = FishThreshold(level + 1) - growthQuarters[id];
                int speed = tankQuarters[activeTank];
                int untilNext = (remaining + speed - 1) / speed;
                if (slice > untilNext) slice = untilNext;
            }
            at += slice;
            BankThrough(at, offline);
            CreditTankIncome(slice);
            if (!growing) return;
            for (int lane = 0; lane < LaneCount; lane++)
            {
                int id = SpeciesAt(packedSlots, lane);
                if (id >= 0) growthQuarters[id] = Mathf.Min(FishThreshold(FishCap(id)), growthQuarters[id] + (int)slice * tankQuarters[activeTank]);
            }
            dirty = true;
            RecountDisplay();
            elapsed -= slice;
        }
    }

    private void CreditTankIncome(long elapsed)
    {
        CreditXP(elapsed);
        AddCoinUnits(TankCoinUnits(elapsed));
    }

    private long TankCoinUnits(long elapsed)
    {
        int unitsPerSecond = (100 + displayCoinBonus) * (CoinPeriodBase / stageCoinIntervals[currentStage]);
        return elapsed * unitsPerSecond * tankQuarters[activeTank] * VeteranPercent() / 100;
    }

    private void AddCoinUnits(long units)
    {
        if (coins >= CoinCap) return;
        units += coinRemainder;
        long earned = units / UnitsPerCoin;
        int room = CoinCap - coins;
        coins += earned >= room ? room : (int)earned;
        coinRemainder = coins == CoinCap ? 0 : (int)(units - earned * UnitsPerCoin);
        dirty = true;
    }

    private void Advance(long now)
    {
        if (now <= cursor) return;
        CreditTime(now - cursor, false);
        cursor = now;
    }

    public void RefreshTank()
    {
        UpdateTubeShadows();
        if (!ready && restoredEvent && !invalidSave) Restore();
        if (ready)
        {
            long now = Now();
            Advance(now);
            int previousAwards = awardBits;
            UpdateAwards();
            if (previousAwards != awardBits || (dirty && cursor - lastCheckpoint >= CheckpointInterval)) Save();
            RefreshDisplay(now);
            AmbientActivity();
        }
        SendCustomEventDelayedSeconds(nameof(RefreshTank), 5f);
    }

    public override void Interact()
    {
        if (!ready || page != 0 || mealPlaying) return;
        Feed(Now());
    }

    private int MealGrowthSeconds(int rank) { return rank >= 5 ? 30 + 5 * (rank - 5) : rank >= 3 ? 15 : 0; }

    private int MealXPUnits(int rank)
    {
        return (int)TankXPUnits(FeedBonus + 30 * rank);
    }

    private int CoinsPerFeed() { return BaseFeedCoins + foodRank; }

    // Cumulative value in millionths of a full meal. Start at 100%, 75%, 60%, 50%.
    // The logarithmic tail lets long absences keep earning at a declining rate in constant time.
    private long MealWeight(long count)
    {
        if (count <= 0) return 0L;
        if (count == 1) return MealScale;
        if (count == 2) return 1750000L;
        if (count == 3) return 2350000L;
        return 2850000L + (long)(3000000.0 * System.Math.Log((count + 2.5) / 6.5));
    }

    // Restore part of the loss on meals two to four; apply the same percentage to
    // the declining value of later meals so long absences keep diminishing returns.
    private long OfflineMealBonus(long count)
    {
        if (stockRank == 0 || count <= 1) return 0;
        long first = System.Math.Min(4L, count);
        long baseWeight = MealWeight(first);
        long eligible = first * MealScale - baseWeight + MealWeight(count) - baseWeight;
        return eligible * stockRank / (2 * MaxStockRank);
    }

    private void StoreMeals(long count, bool offline)
    {
        long after = storedMeals + count;
        long weight = MealWeight(after) - MealWeight(storedMeals);
        if (offline) weight += OfflineMealBonus(after) - OfflineMealBonus(storedMeals);
        storedMeals = after;
        storedXPUnits += weight * MealXPUnits(foodRank);
        storedGrowthUnits += weight * MealGrowthSeconds(foodRank);
        storedCoinUnits += weight * CoinsPerFeed() * tankQuarters[activeTank] * VeteranPercent() / 100;
        dirty = true;
    }

    private void BankThrough(long end, bool offline)
    {
        if (end < feedAnchor + FeedInterval) return;
        long count = (end - feedAnchor) / FeedInterval;
        StoreMeals(count, offline);
        feedAnchor += count * FeedInterval;
    }

    private long BankedCoinUnits() { return storedCoinUnits * LegacyCoinUnits / MealScale; }

    private void Feed(long now)
    {
        if (now < cursor) return;
        Advance(now);
        if (storedMeals > 0)
        {
            int before = experience;
            AddXPUnits(storedXPUnits / MealScale);
            feedAward = experience - before;
            AddCoinUnits(BankedCoinUnits());
            // Commit the meal, including every diner's growth, in the same save.
            int quarters = (int)(storedGrowthUnits * 4 / MealScale);
            for (int lane = 0; lane < LaneCount; lane++)
            {
                int id = SpeciesAt(packedSlots, lane);
                int gain = 0;
                if (id >= 0)
                {
                    gain = Mathf.Min(quarters, FishThreshold(FishCap(id)) - growthQuarters[id]);
                    growthQuarters[id] += gain;
                }
                mealGrowthQuarters[lane] = gain;
            }
            RecountDisplay();
            storedGrowthUnits = 0;
            storedMeals = 0;
            storedXPUnits = 0;
            storedCoinUnits = 0;
            lastFeed = now;
            feedBannerUntil = now + 5L;
            Save();
            BeginMeal();
        }
        RefreshDisplay(now);
    }

    public void OpenFeeder() { OpenPage(7); }

    public void SetFeeder()
    {
        if (!ready || page != 7 || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        if (feederState == 0)
        {
            if (coins < FeederPrice) { RefreshDisplay(now); return; }
            coins -= FeederPrice;
        }
        feederState = feederState == FeederOn ? FeederOff : FeederOn;
        nextTransaction = Time.unscaledTime + .35f;
        Save();
        if (feederState == FeederOn) StartFeeder(now);
        RefreshDisplay(now);
    }

    private void StartFeeder(long now)
    {
        firstAutoFeed = now + FeedInterval;
        ScheduleFeeder(now);
    }

    private long AutoDue()
    {
        long due = storedMeals > 0 ? cursor : feedAnchor + FeedInterval;
        if (due < firstAutoFeed) due = firstAutoFeed;
        return due < cursor ? cursor : due;
    }

    private void ScheduleFeeder(long now)
    {
        if (autoTickPending || feederState != FeederOn) return;
        float wait = Mathf.Clamp((float)(AutoDue() - now), 1f, FeedInterval);
        autoTickPending = true;
        SendCustomEventDelayedSeconds(nameof(RunFeeder), wait);
    }

    public void RunFeeder()
    {
        autoTickPending = false;
        if (!ready || feederState != FeederOn) return;
        long now = Now();
        // Let observations and the current meal finish before dispensing.
        if (now >= AutoDue() && activity < 0 && !mealPlaying) Feed(now);
        ScheduleFeeder(now);
    }

    private void RefreshFeeder()
    {
        string state = feederState == FeederOn ? "稼働中" : feederState == FeederOff ? "停止中" : "未購入";
        feederStatus.text = "自動えさやり器　" + state + "\n滞在中は毎分給餌・留守中もストック";
        if (feederState == 0)
            feederAction.text = (coins < FeederPrice ? "コイン不足" : "購入する") + "\n" + FeederPrice.ToString() + " C";
        else feederAction.text = feederState == FeederOn ? "停止する" : "再開する";
    }

    private const int StockPage = 15;
    private const int MaxStockRank = 20;
    private int stockRank;
    public Text stockDetails, stockAction;

    public void OpenStock() { OpenPage(StockPage); }

    private int StockCoinCost(int next) { return 150 + 25 * next * next; }
    private int StockShellCost(int next) { return 2 + (next - 1) / 2; }
    private int StockSandCost(int next) { return 1 + (next - 1) / 4; }

    private bool CanUpgradeStock(int next)
    {
        return coins >= StockCoinCost(next) && shells >= StockShellCost(next) && starSand >= StockSandCost(next);
    }

    public void UpgradeStock()
    {
        if (!ready || page != StockPage || stockRank >= MaxStockRank || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        int next = stockRank + 1;
        if (CanUpgradeStock(next))
        {
            coins -= StockCoinCost(next);
            shells -= StockShellCost(next);
            starSand -= StockSandCost(next);
            stockRank = next;
            nextTransaction = Time.unscaledTime + .35f;
            Save();
        }
        RefreshDisplay(now);
    }

    private void RefreshStock()
    {
        bool capped = stockRank == MaxStockRank;
        int next = capped ? stockRank : stockRank + 1;
        string rank = capped ? stockRank + "/20　最大" : stockRank + " → " + next + "/20";
        string rate = Hundredths(stockRank * 250) + "%";
        if (!capped) rate += " → " + Hundredths(next * 250) + "%";
        stockDetails.text = "留守ストック強化　" + rank + "\n2〜4回目　減衰を " + rate + " 緩和\n5回目以降　報酬に同率を加算";
        stockAction.text = capped ? "強化完了" : (CanUpgradeStock(next) ? "強化する" : "素材不足") +
            "\n" + StockCoinCost(next) + " C\n貝殻 " + StockShellCost(next) + "　星砂 " + StockSandCost(next);
    }

    public void OpenHome() { OpenPage(0); }
    public void OpenStages() { OpenPage(1); }
    public void OpenShop() { OpenPage(2); }
    public void OpenFishShop() { OpenPage(3); }

    private void OpenPage(int next)
    {
        if (!ready) return;
        if (next == 1 && page != 1) selectedStage = currentStage;
        if (next == 3 && page != 3) selectedFish = NextUnownedFish();
        if (next == 10) selectedTank = activeTank;
        if (page == 10 || next == 10) ApplyTankBody(activeTank);
        if (next != page)
        {
            pageTipUntil = 0f;
            int tip = next == 11 ? ExpeditionTip : next == 9 ? EnchantTip : 0;
            if ((tip & ~seenPageTips) != 0)
            {
                seenPageTips |= tip;
                PlayerData.SetInt(PageTipsKey, seenPageTips);
                pageTipUntil = Time.unscaledTime + 12f;
            }
        }
        page = next;
        ApplyPages();
        long now = Now();
        Advance(now);
        RefreshDisplay(now);
    }

    private void ApplyPages()
    {
        if (feedCollider != null) feedCollider.enabled = page == 0;
        if (pages != null)
        {
            for (int i = 0; i < pages.Length; i++)
                if (pages[i] != null && pages[i].activeSelf != (i == page)) pages[i].SetActive(i == page);
        }
        if (nameCanvas != null) nameCanvas.SetActive(page == 6);
        if (transferCanvas != null) transferCanvas.SetActive(page == TransferPage && transferMode != 0);
        RefreshCabinetControls();
        if (tabHighlights != null)
        {
            for (int i = 0; i < tabHighlights.Length; i++)
                if (tabHighlights[i] != null)
                    tabHighlights[i].color = i == ((page == 3 || page == 7 || page == 9 || page == 10 || page == StockPage) ? 2 : page) ? new Color32(50, 107, 104, 255) : new Color32(32, 52, 69, 255);
        }
    }

    public void PreviousStage() { Browse(-1); }
    public void NextStage() { Browse(1); }

    private void Browse(int step)
    {
        if (!ready || page != 1) return;
        selectedStage = (selectedStage + step + StageCount) % StageCount;
        RefreshDisplay(Now());
    }

    public void BuyOrVisitStage()
    {
        if (!ready || page != 1 || selectedStage == currentStage || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        // Settle all elapsed time at the old stage's multiplier before switching.
        Advance(now);
        int bit = 1 << selectedStage;
        if ((ownedMask & bit) == 0)
        {
            int price = stagePrices[selectedStage];
            if (GetLevel() < stageLevels[selectedStage] || coins < price || !StageRouteOpen())
            {
                RefreshDisplay(now);
                return;
            }
            coins -= price;
            ownedMask |= bit;
        }
        StopActivity();
        nextActivity = Time.time + 10f;
        currentStage = selectedStage;
        nextTransaction = Time.unscaledTime + .30f;
        ApplyHabitat();
        Save();
        RefreshDisplay(now);
    }

    private void ApplyHabitat()
    {
        if (habitats == null) return;
        for (int i = 0; i < habitats.Length; i++)
            if (habitats[i] != null && habitats[i].activeSelf != (i == currentStage))
                habitats[i].SetActive(i == currentStage);
    }

    private int FoodCoinCost(int rank) { return rank < foodPrices.Length ? foodPrices[rank] : 0; }

    // After the five coin upgrades, the material cost rises every two ranks.
    private int FoodSandCost(int rank) { return rank < foodPrices.Length ? 0 : 1 + (rank - foodPrices.Length) / 2; }

    private bool CanPayFoodCost(int coinCost, int sandCost)
    {
        return coins >= coinCost && starSand >= sandCost && shells >= 2 * sandCost;
    }

    public void UpgradeFood()
    {
        if (!ready || page != 2 || foodRank >= MaxFoodRank || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        int coinCost = FoodCoinCost(foodRank);
        int sandCost = FoodSandCost(foodRank);
        if (CanPayFoodCost(coinCost, sandCost))
        {
            coins -= coinCost;
            shells -= 2 * sandCost;
            starSand -= sandCost;
            foodRank++;
            nextTransaction = Time.unscaledTime + .30f;
            Save();
        }
        RefreshDisplay(now);
    }

    public void PreviousFish() { BrowseFish(-1); }
    public void NextFish() { BrowseFish(1); }

    private void BrowseFish(int step)
    {
        if (!ready || page != 3) return;
        int index = 0;
        while (shopOrder[index] != selectedFish) index++;
        selectedFish = shopOrder[(index + step + shopOrder.Length) % shopOrder.Length];
        RefreshDisplay(Now());
    }

    public void BuyFish()
    {
        if (!ready || page != 3 || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        if (selectedFish == tripFish) { OpenExpedition(); return; }
        int bit = 1 << selectedFish;
        int lane = FindLane(selectedFish);
        int empty = FindLane(-1);
        if ((ownedFishMask & bit) == 0)
        {
            if (GetLevel() < fishLevels[selectedFish] || !FishRouteOpen(selectedFish) || coins < fishPrices[selectedFish])
            {
                RefreshDisplay(now);
                return;
            }
            coins -= fishPrices[selectedFish];
            ownedFishMask |= bit;
            if (empty >= 0) packedSlots |= (selectedFish + 1) << (empty * LaneBits);
        }
        else if (lane < 0 && empty < 0)
        {
            incomingShopFish = selectedFish;
            pickerOffset = 0;
            OpenPage(PickerPage);
            return;
        }
        else if (lane >= 0 && displayCount > 1)
            packedSlots &= ~(LaneMask << (lane * LaneBits));
        else if (lane < 0 && empty >= 0)
            packedSlots |= (selectedFish + 1) << (empty * LaneBits);
        else
        {
            RefreshDisplay(now);
            return;
        }
        FinishLineupChange(now);
    }

    private void FinishLineupChange(long now)
    {
        RecountDisplay();
        if (activity >= 0 && activity != ChestActivity && (displayMask & (1 << entryFish[activity])) == 0) StopActivity();
        if (activity == ChestActivity) StopActivity();
        RefreshRoster();
        // Freeze visual lanes until the diners finish the current meal.
        if (!mealPlaying) ApplySwimmers();
        nextTransaction = Time.unscaledTime + .30f;
        Save();
        RefreshDisplay(now);
    }

    private const int ManagementPage = 13;
    private const int PickerPage = 14;
    private int managedLane, pickerOffset;
    private int incomingShopFish = -1;
    private int[] pickerIds = new int[4];
    public Image[] laneRails;
    public Text[] laneDetails, pickerNames, pickerBonuses;
    public RawImage managePortrait;
    public RawImage[] pickerPortraits;
    public GameObject[] pickerCards;
    public GameObject manageTools, benchControl, pickerArrows, pickerEmpty;
    public Text manageTitle, manageState, manageChange, pickerTitle, pickerPageText, noReserves;

    public void OpenManagement() { OpenPage(ManagementPage); }
    public void ManageFirst() { ManageLane(0); }
    public void ManageSecond() { ManageLane(1); }
    public void ManageThird() { ManageLane(2); }

    private void ManageLane(int lane)
    {
        if (!ready) return;
        managedLane = lane;
        OpenManagement();
    }

    private void RefreshManagement()
    {
        int id = SpeciesAt(packedSlots, managedLane);
        string slot = "枠 " + (managedLane + 1) + "　";
        manageTitle.text = slot + (id < 0 ? "空き枠" : DisplayName(id));
        managePortrait.enabled = id >= 0;
        manageTools.SetActive(id >= 0);
        benchControl.SetActive(id >= 0 && displayCount > 1);
        manageChange.text = id < 0 ? "魚を入れる" : "入れ替え";
        if (id < 0)
        {
            manageState.text = "控えから泳がせる魚を選べます";
            return;
        }
        managePortrait.uvRect = PortraitRect(id);
        string species = string.IsNullOrEmpty(petNames[id]) ? "" : fishNames[id] + "　";
        manageState.text = species + FishLevelLabel(FishLevel(id)) + " / " + FishCap(id) + "\n" + Rates(id);
    }

    public void ManageName()
    {
        if (page != ManagementPage || SpeciesAt(packedSlots, managedLane) < 0) return;
        nameLane = managedLane;
        OpenNames();
    }
    public void ManageEnchant()
    {
        if (page != ManagementPage || SpeciesAt(packedSlots, managedLane) < 0) return;
        enchantLane = managedLane;
        OpenEnchant();
    }
    public void ManageCap()
    {
        if (page != ManagementPage) return;
        int id = SpeciesAt(packedSlots, managedLane);
        if (id < 0) return;
        capFish = id;
        OpenFishCaps();
    }

    public void BenchResident()
    {
        if (page == ManagementPage && displayCount > 1 && SpeciesAt(packedSlots, managedLane) >= 0)
            SetResident(managedLane, -1);
    }

    private int AvailableReserves()
    {
        int mask = ownedFishMask & ~displayMask;
        return tripFish < 0 ? mask : mask & ~(1 << tripFish);
    }

    private void SetResident(int lane, int id)
    {
        if (!ready || Time.unscaledTime < nextTransaction) return;
        if (id >= 0 && (AvailableReserves() & (1 << id)) == 0) return;
        int shift = lane * LaneBits;
        int lineup = (packedSlots & ~(LaneMask << shift)) | ((id + 1) << shift);
        if (lineup == packedSlots || !ValidLineup(lineup, ownedFishMask)) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        packedSlots = lineup;
        managedLane = lane;
        page = ManagementPage;
        ApplyPages();
        FinishLineupChange(now);
    }

    public void OpenReserves()
    {
        if (!ready || page != ManagementPage) return;
        incomingShopFish = -1;
        pickerOffset = 0;
        OpenPage(PickerPage);
    }
    public void LeavePicker()
    {
        if (page != PickerPage) return;
        if (incomingShopFish < 0) { OpenManagement(); return; }
        int id = incomingShopFish;
        OpenFishShop();
        selectedFish = id;
        RefreshFishShop(GetLevel());
    }
    public void PreviousReserves() { StepReserves(-1); }
    public void NextReserves() { StepReserves(1); }

    private void StepReserves(int direction)
    {
        if (page != PickerPage || incomingShopFish >= 0) return;
        int count = CountBits(AvailableReserves());
        int pagesOfFish = (count + pickerIds.Length - 1) / pickerIds.Length;
        if (pagesOfFish < 2) return;
        pickerOffset = (pickerOffset + direction + pagesOfFish) % pagesOfFish;
        RefreshPicker();
    }

    private void RefreshPicker()
    {
        bool fromShop = incomingShopFish >= 0;
        int reserves = AvailableReserves();
        int pageCount = (CountBits(reserves) + pickerIds.Length - 1) / pickerIds.Length;
        pickerTitle.text = fromShop ? DisplayName(incomingShopFish) + " と交代する魚" : "枠 " + (managedLane + 1) + " に迎える魚";
        pickerArrows.SetActive(!fromShop && pageCount > 1);
        pickerEmpty.SetActive(!fromShop && reserves == 0);
        if (pickerOffset >= pageCount) pickerOffset = 0;
        pickerPageText.text = (pickerOffset + 1) + " / " + pageCount;
        if (!fromShop && reserves == 0)
            noReserves.text = tripFish >= 0 ? "選べる控えはいません\n探索の魚は帰還後に選べます" : "控えの魚がいません\n魚屋で新しい魚を迎えられます";
        int count = 0;
        for (int i=0; i<pickerIds.Length; i++) pickerIds[i]=-1;
        if (fromShop)
        {
            for (int i=0; i<LaneCount; i++) pickerIds[i]=SpeciesAt(packedSlots,i);
        }
        else
        {
            for (int i=0; i<shopOrder.Length; i++)
            {
                int id=shopOrder[i];
                if ((reserves & (1<<id)) == 0) continue;
                int index=count++ - pickerOffset * pickerIds.Length;
                if (index>=0 && index<pickerIds.Length) pickerIds[index]=id;
            }
        }
        for (int i=0; i<pickerIds.Length; i++)
        {
            int id=pickerIds[i];
            pickerCards[i].SetActive(id>=0);
            if (id<0) continue;
            pickerPortraits[i].uvRect=PortraitRect(id);
            pickerNames[i].text=(fromShop ? "枠" + (i+1) + "　" : "") + DisplayName(id);
            pickerBonuses[i].text = FishLevelLabel(FishLevel(id)) + "　" + Rates(id);
        }
    }

    public void PickReserveOne() { PickResident(0); }
    public void PickReserveTwo() { PickResident(1); }
    public void PickReserveThree() { PickResident(2); }
    public void PickReserveFour() { PickResident(3); }
    private void PickResident(int index)
    {
        if (!ready || page != PickerPage || pickerIds[index] < 0) return;
        if (incomingShopFish >= 0) SetResident(index, incomingShopFish);
        else SetResident(managedLane, pickerIds[index]);
    }


    private int SpeciesAt(int slots, int lane)
    {
        return ((slots >> (lane * LaneBits)) & LaneMask) - 1;
    }

    private bool ValidLineup(int slots, int owned)
    {
        if (slots <= 0 || slots >= (1 << (LaneCount*LaneBits))) return false;
        int seen = 0;
        for (int i = 0; i < LaneCount; i++)
        {
            int species = SpeciesAt(slots, i);
            if (species < 0) continue;
            if (species >= fishNames.Length) return false;
            int bit = 1 << species;
            if ((owned & bit) == 0 || (seen & bit) != 0) return false;
            seen |= bit;
        }
        return true;
    }

    private int FindLane(int species)
    {
        for (int i = 0; i < LaneCount; i++)
            if (SpeciesAt(packedSlots, i) == species) return i;
        return -1;
    }

    private void RecountDisplay()
    {
        veteranCount = 0;
        int threshold = FishThreshold(20);
        for (int id = 0; id < SpeciesCount; id++)
            if ((ownedFishMask & (1 << id)) != 0 && growthQuarters[id] >= threshold) veteranCount++;
        displayMask = 0;
        displayCount = 0;
        displayXPBonus = 0;
        displayCoinBonus = 0;
        for (int i = 0; i < LaneCount; i++)
        {
            int species = SpeciesAt(packedSlots, i);
            if (species < 0) continue;
            displayMask |= 1 << species;
            displayCount++;
            displayXPBonus += XPBonus(species);
            displayCoinBonus += CoinBonus(species);
        }
    }

    private int PlayerThreshold(int level)
    {
        if (level <= levelXP.Length) return levelXP[level - 1];
        int extra = level - levelXP.Length;
        return Level20XP + extra * FirstNewLevelCost + (extra - 1) * extra / 2 * LevelCostStep;
    }

    private int GetLevel()
    {
        int low = 1, high = PlayerLevelCap;
        while (low < high)
        {
            int middle = (low + high + 1) / 2;
            if (experience >= PlayerThreshold(middle)) low = middle;
            else high = middle - 1;
        }
        return low;
    }

    private void ApplySwimmers()
    {
        if (fish == null || fish.Length == 0) return;
        if (!Utilities.IsValid(mealMaterial) && Utilities.IsValid(fish[0]))
        {
            Transform root = fish[0].transform;
            if (Utilities.IsValid(root) && Utilities.IsValid(root.parent))
            {
                Transform food = root.parent.Find("Feed morsels");
                if (Utilities.IsValid(food))
                {
                    MeshRenderer renderer = food.GetComponent<MeshRenderer>();
                    if (Utilities.IsValid(renderer))
                    {
                        morsels = food.gameObject;
                        mealMaterial = renderer.material;
                        for (int i = 0; i < fish.Length; i++)
                        {
                            if (!Utilities.IsValid(fish[i])) continue;
                            MeshRenderer swimmer = fish[i].GetComponent<MeshRenderer>();
                            if (Utilities.IsValid(swimmer)) swimmer.sharedMaterial = mealMaterial;
                        }
                        visibleSlots = -1;
                    }
                }
            }
        }
        if (visibleSlots == packedSlots) return;
        if (Utilities.IsValid(mealMaterial))
        {
            SetSwimFloat("_SwimA", SpeciesAt(packedSlots, 0));
            SetSwimFloat("_SwimB", SpeciesAt(packedSlots, 1));
            SetSwimFloat("_SwimC", SpeciesAt(packedSlots, 2));
        }
        for (int i = 0; i < fish.Length; i++)
        {
            bool visible = (displayMask & (1 << i)) != 0;
            if (Utilities.IsValid(fish[i]) && fish[i].activeSelf != visible) fish[i].SetActive(visible);
        }
        visibleSlots = packedSlots;
        RefreshSwimTags();
    }

    private void BeginMeal()
    {
        StopActivity();
        ApplySwimmers();
        if (!Utilities.IsValid(mealMaterial) || !Utilities.IsValid(morsels)) return;
        int dinerMask = 0;
        for (int i = 0; i < LaneCount; i++)
            if (SpeciesAt(packedSlots, i) >= 0) dinerMask |= 1 << i;
        SetSwimFloat("_FeedFishCount", displayCount);
        SetSwimFloat("_FeedFishMask", dinerMask);
        SetSwimFloat("_FeedAge", 0f);
        morsels.SetActive(true);
        mealMaterial.SetFloat("_FoodRank", foodRank);
        growthTagMask = 0;
        mealStart = Time.time;
        if (!mealPlaying)
        {
            mealPlaying = true;
            SendCustomEventDelayedFrames(nameof(AnimateMeal), 1);
        }
    }

    public void AnimateMeal()
    {
        if (!mealPlaying) return;
        float age = Time.time - mealStart;
        if (age >= MealDuration)
        {
            SetSwimFloat("_FeedAge", -1f);
            morsels.SetActive(false);
            mealPlaying = false;
            growthTagMask = 0;
            ApplySwimmers();
            RefreshSwimTags();
            return;
        }
        // Same first contact as BiteTime(kind, 0) in Fish motion.cginc.
        int mask = 0;
        for (int lane = 0; lane < LaneCount; lane++)
        {
            float sinceBite = age - (2.55f + .58f * lane);
            if (mealGrowthQuarters[lane] > 0 && sinceBite >= 0f && sinceBite < 2.5f) mask |= 1 << lane;
        }
        if (mask != growthTagMask)
        {
            growthTagMask = mask;
            RefreshSwimTags();
        }
        SetSwimFloat("_FeedAge", age);
        SendCustomEventDelayedFrames(nameof(AnimateMeal), 1);
    }

    private void ShowWallet(bool loaded)
    {
        if (walletText != null) walletText.text = loaded ? coins + " C" : "-- C";
        if (shellWallet != null) shellWallet.text = loaded ? shells + "個" : "--個";
        if (sandWallet != null) sandWallet.text = loaded ? starSand + "個" : "--個";
    }

    private void RefreshDisplay(long now)
    {
        int level = GetLevel();
        ShowWallet(true);
        if (page == 1) RefreshStageMenu(level);
        if (page == 2) RefreshShopMenu();
        if (page == 3) RefreshFishShop(level);
        if (page == 4) JournalPage();
        if (page == 5) DecorPage();
        if (page == 7) RefreshFeeder();
        if (page == StockPage) RefreshStock();
        if (page == 8) AwardPage();
        if (page == 9) EnchantPage();
        if (page == 10) TankPage();
        if (page == 11) TripPage(now);
        if (page == 12) CapPage();
        if (page == ManagementPage) RefreshManagement();
        if (page == PickerPage) RefreshPicker();
        RefreshExpeditionTab(now);
        RefreshResidentIncome();
        bool capped = level == PlayerLevelCap;
        int progress = experience - PlayerThreshold(level);
        int cost = capped ? 1 : PlayerThreshold(level + 1) - PlayerThreshold(level);
        SetBar(capped ? 1 : progress, cost);
        if (statusText != null)
        {
            string xpLine = capped ? "育成マスター" : BlueXP("XP " + progress + "/" + cost);
            int next = NextUnownedFish();
            string hint = "全種発見！";
            if ((ownedFishMask & (1 << next)) == 0)
                hint = level < fishLevels[next] ? "次の魚 Lv." + fishLevels[next].ToString() : "ショップに新しい魚！";
            if (ownedFishMask == 1)
            {
                int first = shopOrder[1];
                if (lastFeed == 0 && storedMeals > 0)
                    hint = "えさやりを押してみよう！";
                else if (level < fishLevels[first])
                    hint = "2匹目は Lv." + fishLevels[first] + "・" + fishPrices[first] + " C";
                else if (coins < fishPrices[first])
                    hint = "2匹目まで あと " + (fishPrices[first] - coins) + " C";
                else
                    hint = "お店 →「魚を買う」へ";
            }
            if (awayGain > 0 && now < returnBannerUntil) hint = "留守中 +" + awayGain.ToString() + " XP";
            if (now < rewardNoticeUntil) hint = rewardNotice;
            if (TripReturned(now)) hint = "探索隊が帰ってきた！";
            statusText.text = "Lv." + level.ToString() + "　" + displayCount.ToString() + "/3 匹\n" + xpLine + "\n" + hint;
        }
        RefreshSwimTags();
        RefreshFeedLabel();
    }

    public void RefreshFeedCountdown()
    {
        feedTickPending = false;
        RefreshFeedLabel();
    }

    private void RefreshFeedLabel()
    {
        if (!ready || page != 0 || feedText == null) return;

        long ticks = Networking.GetNetworkDateTime().Ticks;
        long now = ticks / TicksPerSecond;
        if (now >= feedAnchor + FeedInterval) Advance(now);
        long remaining = feedAnchor + FeedInterval - now;
        if (remaining < 1L) remaining = 1L;
        if (remaining > FeedInterval) remaining = FeedInterval;
        string label;
        if (storedMeals > 0)
        {
            string count = storedMeals > 9999 ? "9999回以上" : storedMeals.ToString() + "回分";
            label = "えさやり" + "\n" + count;
            if (coinRateText != null)
            {
                long xp = (storedXPUnits / MealScale + xpRemainder) / UnitsPerXP;
                long c = (BankedCoinUnits() + coinRemainder) / UnitsPerCoin;
                int showXP = Mathf.Min(MaxXP - experience, (int)xp);
                int showC = Mathf.Min(CoinCap - coins, (int)c);
                coinRateText.text = "ストック　" + BlueXP("+" + showXP + " XP") + "・+" + showC + " C";
            }
        }
        else
        {
            string heading = feederState == FeederOn ? "自動えさやり" : "えさやり";
            if (now >= lastFeed && now < feedBannerUntil)
                heading = feedAward > 0 ? BlueXP("+" + feedAward + " XP") : "ごはん！";
            label = heading + "\nあと " + remaining.ToString() + " 秒";
            ShowCoinRate();
        }
        RefreshRewardProgress(now, remaining);
        if (!feedTickPending)
        {
            float fraction = (float)(ticks - now * TicksPerSecond) / TicksPerSecond;
            feedTickPending = true;
            SendCustomEventDelayedSeconds(nameof(RefreshFeedCountdown), 1.01f - fraction);
        }
        if (feedText.text != label) feedText.text = label;
    }

    private void RefreshRewardProgress(long now, long remaining)
    {
        bool stockReady = storedMeals > 0;
        if (coinProgress != null)
        {
            GameObject track = coinProgress.parent.gameObject;
            if (track.activeSelf == stockReady) track.SetActive(!stockReady);
            if (!stockReady)
            {
                long pending = coinRemainder + TankCoinUnits(now > cursor ? now - cursor : 0L);
                long remainder = pending - (pending / UnitsPerCoin) * UnitsPerCoin;
                float fraction = coins >= CoinCap ? 1f : (float)remainder / UnitsPerCoin;
                coinProgress.anchorMax = new Vector2(fraction, 1f);
            }
        }
        if (mealProgress != null)
        {
            RectTransform track = (RectTransform)mealProgress.parent;
            if (!track.gameObject.activeSelf) track.gameObject.SetActive(true);
            track.anchoredPosition = new Vector2(track.anchoredPosition.x, stockReady ? -162f : -181f);
            mealProgress.anchorMax = new Vector2(stockReady ? 1f : 1f - (float)remaining / FeedInterval, 1f);
        }
    }

    private string BlueXP(string label) { return "<color=#8DDAFF>" + label + "</color>"; }

    private void ShowCoinRate()
    {
        if (coinRateText == null) return;
        int seconds = stageCoinIntervals[currentStage];
        string interval = seconds == 60 ? "1分" : seconds + "秒";
        int passiveCoins = TankHundredths(100 + displayCoinBonus);
        int passiveXP = (int)((TankXPUnits(seconds) * 100 + UnitsPerXP / 2) / UnitsPerXP);
        int feedCoins = (CoinsPerFeed() * tankQuarters[activeTank] * VeteranPercent() + 2) / 4;
        int feedXP = (int)(((long)MealXPUnits(foodRank) * 100 + UnitsPerXP / 2) / UnitsPerXP);
        coinRateText.text = interval + " " + Hundredths(passiveCoins) + " C・" + BlueXP(Hundredths(passiveXP) + " XP") +
            "\nえさ " + Hundredths(feedCoins) + " C・" + BlueXP(Hundredths(feedXP) + " XP");
    }

    private bool StageRouteOpen() { return selectedStage < 5 || (ownedMask & (1 << (selectedStage - 1))) != 0; }

    private void RefreshStageMenu(int level)
    {
        bool current = selectedStage == currentStage;
        bool owned = (ownedMask & (1 << selectedStage)) != 0;
        int needed = stageLevels[selectedStage];
        int price = stagePrices[selectedStage];
        if (stageText != null)
        {
            string details = "XP ×" + multipliers[selectedStage] + "　コイン " + stageCoinIntervals[selectedStage].ToString() + "秒/枚";
            stageText.text = stageNames[selectedStage] + "　Lv." + needed.ToString() + "\n" + details + "\n現在 " + stageNames[currentStage];
        }
        if (stageActionText != null)
        {
            if (current) stageActionText.text = "滞在中";
            else if (owned) stageActionText.text = "移動する\n無料";
            else
            {
                string action = !StageRouteOpen() ? "前の水槽から" : level < needed ? "Lv." + needed.ToString() + "から" : (coins < price ? "コイン不足" : "解放・移動");
                stageActionText.text = action + "\n" + price.ToString() + " C";
            }
        }
    }

    private int PreviewFeedCoins(int rank, int balance)
    {
        long units = (long)(BaseFeedCoins + rank) * tankQuarters[activeTank] * LegacyCoinUnits * VeteranPercent() / 100;
        return Mathf.Min(CoinCap - balance, (int)((units + coinRemainder) / UnitsPerCoin));
    }

    private void RefreshShopMenu()
    {
        bool capped = foodRank >= MaxFoodRank;
        int coinCost = FoodCoinCost(foodRank);
        int sandCost = FoodSandCost(foodRank);
        if (shopText != null)
        {
            int next = capped ? foodRank : foodRank + 1;
            string heading = "えさ強化 " + foodRank + (capped ? "/" + MaxFoodRank + "　最大" : "→" + next + "/" + MaxFoodRank);
            int xp = Mathf.Min(MaxXP - experience, (MealXPUnits(foodRank) + xpRemainder) / UnitsPerXP);
            int nextXP = Mathf.Min(MaxXP - experience, (MealXPUnits(next) + xpRemainder) / UnitsPerXP);
            int coin = PreviewFeedCoins(foodRank, coins);
            int afterPurchase = capped ? coins : Mathf.Max(0, coins - coinCost);
            int nextCoin = PreviewFeedCoins(next, afterPurchase);
            string rewards = "1回分　XP " + xp + (capped ? "" : "→" + nextXP) + "　C " + coin + (capped ? "" : "→" + nextCoin);
            string growth = "成長/匹　+" + MealGrowthSeconds(foodRank) + "秒" + (capped ? "" : "→+" + MealGrowthSeconds(next) + "秒");
            shopText.text = heading + "\n" + rewards + "\n" + growth;
        }
        if (shopActionText != null)
        {
            if (capped) shopActionText.text = "強化完了";
            else
            {
                string price = sandCost > 0 ? "貝殻" + (2 * sandCost) + " 星砂" + sandCost : coinCost + " C";
                string action = CanPayFoodCost(coinCost, sandCost) ? "強化する" : sandCost > 0 ? "素材不足" : "コイン不足";
                shopActionText.text = action + "\n" + price;
            }
        }
    }

    private int NextUnownedFish()
    {
        for (int i = 1; i < shopOrder.Length; i++)
            if ((ownedFishMask & (1 << shopOrder[i])) == 0) return shopOrder[i];
        return 0;
    }

    private int PreviousRareFish(int id) { return id == ExpeditionFishCount ? 9 : id - 1; }

    private bool FishRouteOpen(int id)
    {
        return id < ExpeditionFishCount || (ownedFishMask & (1 << PreviousRareFish(id))) != 0;
    }

    private void RefreshFishShop(int level)
    {
        int price = fishPrices[selectedFish];
        string priceText = price.ToString() + " C";
        int requiredLevel = fishLevels[selectedFish];
        bool owned = (ownedFishMask & (1 << selectedFish)) != 0;
        bool onDisplay = (displayMask & (1 << selectedFish)) != 0;
        if (fishPreview != null)
            fishPreview.uvRect = PortraitRect(selectedFish);
        if (fishInfoText != null)
        {
            string state = owned ? (onDisplay ? "展示中" : "所有済み") :
                "Lv." + requiredLevel.ToString() + "　<color=#FFE5A0>" + priceText + "</color>";
            if (selectedFish == tripFish) state = TripReturned(Now()) ? "帰還・お迎え待ち" : "探索中";
            fishInfoText.text = fishNames[selectedFish] + (owned ? " " + FishLevelLabel(FishLevel(selectedFish)) : "") + "\n" + state + "\n" + Rates(selectedFish);
        }
        if (fishActionText == null) return;
        if (selectedFish == tripFish) fishActionText.text = "探索隊を\n見る";
        else if (onDisplay) fishActionText.text = displayCount > 1 ? "展示から\n外す" : "展示中\n最後の1匹";
        else if (owned) fishActionText.text = displayCount < LaneCount ? "展示する" : "入れ替える\n枠を選ぶ";
        else if (level < requiredLevel) fishActionText.text = "Lv." + requiredLevel.ToString() + "から";
        else if (!FishRouteOpen(selectedFish)) fishActionText.text = "先に迎えよう\n" + fishNames[PreviousRareFish(selectedFish)];
        else if (coins < price) fishActionText.text = "コイン不足\n必要 " + priceText;
        else fishActionText.text = "購入する\n" + priceText;
    }


    private void InitSwimTags()
    {
        Transform frame = fish[0].transform;
        for (int i = 0; i < LaneCount; i++)
        {
            Material m = swimTags[i].GetComponent<MeshRenderer>().material;
            tagMaterials[i] = m;
            m.SetMatrix("_TankToWorld", frame.localToWorldMatrix);
            m.SetMatrix("_WorldToTank", frame.worldToLocalMatrix);
            m.SetFloat("_Lane", i + 1);
            swimNames[i].material = m;
            swimRates[i].material = m;
            for (int mote=0;mote<ParticlesPerFish;mote++) enchantMotes[i*ParticlesPerFish+mote].material=m;
            swimTagBacks[i].material = m;
            swimTracks[i].material = m;
            swimFills[i].material = m;
            if (swimRarityBadges != null) swimRarityBadges[i].material = m;
        }
        // Loading may already have initialized the fish material with the starter lineup.
        visibleSlots = -1;
    }

    private void SetSwimFloat(string key, float value)
    {
        mealMaterial.SetFloat(key, value);
        for (int i = 0; i < LaneCount; i++)
            if (Utilities.IsValid(tagMaterials[i])) tagMaterials[i].SetFloat(key, value);
    }

    private void RefreshSwimTags()
    {
        if (!ready || visibleSlots < 0) return;
        for (int lane = 0; lane < LaneCount; lane++)
        {
            int id = SpeciesAt(visibleSlots, lane);
            RectTransform plate = swimTags[lane];
            if (plate.gameObject.activeSelf != (id >= 0)) plate.gameObject.SetActive(id >= 0);
            if (id < 0) continue;
            int level = FishLevel(id);
            int effect = enchantments[id];
            int rarity = effectRarity[effect];
            bool showingGrowth = (growthTagMask & (1 << lane)) != 0;
            string fishName = RichFishName(id);
            int band = FishLevelBand(level);
            string caption = fishName + "  <color=" + fishLevelColors[band] + swimLevelAlpha[band] + ">Lv." + level + "</color>";
            if (effect != 0) caption += "  " + rarityNames[rarity];
            if (showingGrowth)
                caption = fishName + "  +" + Hundredths(mealGrowthQuarters[lane] * 25) + "秒";
            if (swimRarityBadges != null) SetFishBadge(swimRarityBadges[lane], effect == 0 ? -1 : rarity);
            Text name = swimNames[lane];
            Text stat = swimRates[lane];
            string rates = Rates(id);
            if (effect != shownEnchant[lane])
            {
                shownEnchant[lane] = effect;
                name.color = effect == 0 ? Color.white : RarityColor(rarity);
                tagMaterials[lane].SetFloat("_Enchantment",effect);
                for (int mote=0;mote<ParticlesPerFish;mote++) enchantMotes[lane*ParticlesPerFish+mote].enabled=effect!=0;
            }
            if (name.text != caption || stat.text != rates)
            {
                name.text = caption;
                stat.text = rates;
                float badgeSpace = swimRarityBadges == null ? 0f : 20f;
                float width = Mathf.Clamp(Mathf.Max(name.preferredWidth + badgeSpace,stat.preferredWidth) + 24f, 185f, 436f + badgeSpace);
                plate.sizeDelta = new Vector2(width, plate.sizeDelta.y);
            }
            float fraction = level == FishCap(id) ? 1f :
                (float)(growthQuarters[id] - FishThreshold(level)) / (FishThreshold(level + 1) - FishThreshold(level));
            swimFills[lane].rectTransform.anchorMax = new Vector2(fraction, 1f);
        }
    }


    private string DisplayName(int species)
    {
        return string.IsNullOrEmpty(petNames[species]) ? fishNames[species] : petNames[species];
    }

    private string RichFishName(int species)
    {
        // Prevent a nickname from opening a formatting tag in mixed-color labels.
        return DisplayName(species).Replace("<", "<\u200B");
    }

    private string FishLevelLabel(int level)
    {
        return "<color=" + fishLevelColors[FishLevelBand(level)] + ">Lv." + level + "</color>";
    }

    private string[] fishLevelColors = { "#F3F8FF", "#85F3B3", "#FFAD82", "#FF8CB2" };
    // Fish labels.shader decodes these four reserved vertex alpha values as level bands.
    private string[] swimLevelAlpha = { "D8", "DC", "E0", "E4" };

    private int FishLevelBand(int level) { return Mathf.Clamp(level / 10, 0, fishLevelColors.Length - 1); }

    private void SetFishBadge(RawImage badge, int row)
    {
        if (badge == null) return;
        badge.enabled = row >= 0;
        if (row < 0) return;
        // UV bands below zero reserve badge rows in the fish nameplate shader.
        Rect frame = new Rect(0f, -2f - 2f * row, 1f, 1f);
        if (badge.uvRect != frame) badge.uvRect = frame;
    }

    private bool ValidName(string value)
    {
        if (value.Length > 12) return false;
        for (int i = 0; i < value.Length; i++)
        {
            int c = value[i];
            if (c < 32 || (c >= 127 && c <= 159) || c == 0x2028 || c == 0x2029) return false;
            if (c >= 0xD800 && c <= 0xDFFF)
            {
                if (c > 0xDBFF || ++i >= value.Length || value[i] < 0xDC00 || value[i] > 0xDFFF) return false;
            }
        }
        return true;
    }

    public void OpenJournal() { journalEntry = currentStage < OriginalStageCount ? currentStage : PreviousEntryCount + currentStage - OriginalStageCount; OpenPage(4); }
    public void OpenDecor() { OpenPage(5); }
    public void OpenNames()
    {
        if (!ready) return;
        if (SpeciesAt(packedSlots, nameLane) < 0) StepLane(1);
        OpenPage(6);
        LoadNameDraft();
    }

    public GameObject transferCanvas;
    public TMPro.TMP_InputField transferInput;
    public Text transferMessage;
    public GameObject transferMenu, transferExport, transferImport;
    private int transferMode, previousTransferPage;

    private const int TransferPage = 16;
    private const int MaxTransferCodeLength = 4096;
    private const string FullTransferPrefix = "SEA2";
    private const string LegacyTransferPrefix = "SEA1";
    private const string TransferSaveKey = "r19.aquarium.v24";
    private const string TransferBackupKey = "r19.aquarium.transferBackup";
    private bool transferImported;
    private string approvedTransferCode;
    private string fullTransferRecord;
    private int fullTransferLight, fullTransferTips;
    private int transferCoins, transferFish, transferCap25, transferCap30;
    private string[] transferNames = new string[SpeciesCount];
    private int[] transferGrowth = new int[SpeciesCount];
    private int[] transferEnchantments = new int[SpeciesCount];

    public void OpenTransfer()
    {
        if (!ready || transferInput == null || transferMessage == null) return;
        if (page != TransferPage) previousTransferPage = page;
        transferMode = 0;
        OpenPage(TransferPage);
        RefreshTransferPanel();
        transferMessage.text = "進行状況をすべて移せます。\n引き継ぎ前のセーブは控えに残ります。";
    }

    public void CloseTransfer()
    {
        if (page != TransferPage) return;
        if (previousTransferPage == 6) OpenNames();
        else OpenPage(previousTransferPage);
    }

    public void OpenTransferExport()
    {
        if (!ready || page != TransferPage) return;
        VRCPlayerApi player = Networking.LocalPlayer;
        if (!Utilities.IsValid(player)) return;
        transferMode = 1;
        RefreshTransferPanel();
        long now = Now();
        if (now < cursor)
        {
            transferMessage.text = "時計を確認できませんでした。少し待ってからやり直してね。";
            return;
        }
        Advance(now);
        BankThrough(now, false);
        Save();
        transferInput.text = BuildFullTransferCode(player.displayName);
        transferMessage.text = "全データ Lv." + GetLevel() + "・魚 " + CountBits(ownedFishMask) + " 種・" + coins + " C\nコードを全選択してコピー";
    }

    public void OpenTransferImport()
    {
        if (!ready || page != TransferPage) return;
        transferMode = 2;
        RefreshTransferPanel();
        transferMessage.text = "別の水槽で発行したコードを貼り付けてね。";
    }

    public void OpenTransferBackup()
    {
        if (!ready || page != TransferPage) return;
        VRCPlayerApi player = Networking.LocalPlayer;
        if (!Utilities.IsValid(player)) return;
        string code;
        if (!PlayerData.TryGetString(player, TransferBackupKey, out code))
        {
            transferMessage.text = "引き継ぎ前の控えはまだありません。";
            return;
        }
        transferMode = 1;
        RefreshTransferPanel();
        transferInput.text = code;
        transferMessage.text = "前のセーブのコードです。\nコピーして「貼り付けて引き継ぐ」から戻せます。";
    }

    private void RefreshTransferPanel()
    {
        approvedTransferCode = "";
        fullTransferRecord = "";
        transferInput.text = "";
        transferMenu.SetActive(transferMode == 0);
        transferExport.SetActive(transferMode == 1);
        transferImport.SetActive(transferMode == 2);
        transferCanvas.SetActive(transferMode != 0);
    }

    private string BuildFullTransferCode(string accountName)
    {
        string payload = FullTransferPrefix + "|" + EncodeName(accountName) + "|" +
            lightMode + "|" + (seenPageTips & (ExpeditionTip | EnchantTip)) + "|" + BuildSaveRecord() + "|1";
        return payload + "|" + TransferChecksum(payload);
    }

    private string TransferChecksum(string payload)
    {
        int first = 1;
        int second = 0;
        for (int i = 0; i < payload.Length; i++)
        {
            first = (first + (int)payload[i]) % 65521;
            second = (second + first) % 65521;
        }
        return first.ToString() + "-" + second.ToString();
    }

    public void CheckTransfer()
    {
        if (!ready || transferMode != 2 || page != TransferPage) return;
        approvedTransferCode = "";
        fullTransferRecord = "";
        string code = transferInput.text.Trim();
        if (code.StartsWith(FullTransferPrefix + "|"))
        {
            CheckFullTransfer(code);
            return;
        }
        if (transferImported)
        {
            transferMessage.text = "旧形式の引き継ぎは済んでいます。\n新しい全データコードは使用できます。";
            return;
        }
        if (!ReadTransferCode(code))
        {
            transferMessage.text = "コードを確認してね。発行したときと同じ表示名が必要です。";
            return;
        }
        approvedTransferCode = code;
        int newFish = CountBits(transferFish & ~ownedFishMask);
        transferMessage.text = "魚 " + CountBits(transferFish) + " 種（新規 " + newFish + "）・残高 " + Mathf.Max(coins, transferCoins) + " C　「確定」で保存";
    }

    private void CheckFullTransfer(string code)
    {
        VRCPlayerApi player = Networking.LocalPlayer;
        int end = TransferPayloadEnd(code);
        if (!Utilities.IsValid(player) || end < 0)
        {
            transferMessage.text = "全データコードを最後まで貼り付けてね。";
            return;
        }
        string[] fields = code.Split(new char[] { '|' });
        if (fields.Length < 6 || fields[1] != EncodeName(player.displayName) ||
            !int.TryParse(fields[2], out fullTransferLight) || fullTransferLight < Day || fullTransferLight > Ultraviolet ||
            !int.TryParse(fields[3], out fullTransferTips) || (fullTransferTips & ~(ExpeditionTip | EnchantTip)) != 0)
        {
            transferMessage.text = "発行したときと同じ表示名で、全データコードを使ってね。";
            return;
        }
        int offset = fields[0].Length + fields[1].Length + fields[2].Length + fields[3].Length + 4;
        if (offset >= end) return;
        string record = code.Substring(offset, end - offset);

        // Reuse the save parser for preview and restore the live game immediately.
        // No PlayerData or visual state is changed until the player confirms.
        bool hadReceipt = transferImported;
        string current = BuildSaveRecord();
        bool valid = ReadRecord(record, 24) && cursor <= Now();
        int level = valid ? GetLevel() : 0;
        int owned = valid ? CountBits(ownedFishMask) : 0;
        int balance = coins;
        ReadRecord(hadReceipt ? current + "|1" : current, hadReceipt ? 24 : 23);
        if (!valid)
        {
            transferMessage.text = "セーブを読み取れません。引き継ぎ元でコードを発行し直してね。";
            return;
        }
        approvedTransferCode = code;
        fullTransferRecord = record;
        transferMessage.text = "全データ Lv." + level + "・魚 " + owned + " 種・" + balance + " C\n確定で置き換え。現在のセーブは控えに残します。";
    }

    private int TransferPayloadEnd(string code)
    {
        if (code.Length == 0 || code.Length > MaxTransferCodeLength) return -1;
        int end = code.LastIndexOf('|');
        return end > 0 && code.Substring(end + 1) == TransferChecksum(code.Substring(0, end)) ? end : -1;
    }

    private bool ReadTransferCode(string code)
    {
        if (TransferPayloadEnd(code) < 0) return false;
        string[] fields = code.Split(new char[] { '|' });
        VRCPlayerApi player = Networking.LocalPlayer;
        if (fields.Length < 7 || fields[0] != LegacyTransferPrefix || !Utilities.IsValid(player) ||
            fields[1] != EncodeName(player.displayName)) return false;
        if (!int.TryParse(fields[2], out transferCoins) || transferCoins < 0 || transferCoins > CoinCap ||
            !int.TryParse(fields[3], out transferFish) || transferFish < 1 || transferFish >= (1 << SpeciesCount) ||
            fields.Length != 7 + 3 * CountBits(transferFish) ||
            !int.TryParse(fields[4], out transferCap25) || (transferCap25 & ~transferFish) != 0 ||
            !int.TryParse(fields[5], out transferCap30) || (transferCap30 & ~transferCap25) != 0) return false;
        int offset = 6;
        for (int i = 0; i < SpeciesCount; i++)
        {
            int bit = 1 << i;
            if ((transferFish & bit) == 0) continue;
            string encodedName = fields[offset];
            string name = encodedName.Replace("%7C", "|").Replace("%25", "%");
            int fishCap = (transferCap30 & bit) != 0 ? 30 : (transferCap25 & bit) != 0 ? 25 : BaseFishCap;
            if (!ValidName(name) || EncodeName(name) != encodedName ||
                !int.TryParse(fields[offset + 1], out int growth) || growth < 0 || growth > FishThreshold(fishCap) ||
                !int.TryParse(fields[offset + 2], out int effect) || effect < 0 || effect >= enchantNames.Length) return false;
            transferNames[i] = name;
            transferGrowth[i] = growth;
            transferEnchantments[i] = effect;
            offset += 3;
        }
        return true;
    }

    public void ConfirmTransfer()
    {
        if (!ready || transferMode != 2 || page != TransferPage) return;
        if (string.IsNullOrEmpty(approvedTransferCode) || approvedTransferCode != transferInput.text.Trim())
        {
            transferMessage.text = "先に「内容を確認」を押してね。";
            return;
        }
        if (!string.IsNullOrEmpty(fullTransferRecord))
        {
            ConfirmFullTransfer();
            return;
        }
        if (transferImported) return;
        approvedTransferCode = "";
        long now = Now();
        if (now < cursor)
        {
            transferMessage.text = "時計を確認できませんでした。少し待ってからやり直してね。";
            return;
        }
        Advance(now);
        for (int i = 0; i < SpeciesCount; i++)
        {
            int bit = 1 << i;
            if ((transferFish & bit) == 0) continue;
            if (string.IsNullOrEmpty(petNames[i])) petNames[i] = transferNames[i];
            if (enchantments[i] == 0) enchantments[i] = transferEnchantments[i];
            growthQuarters[i] = Mathf.Max(growthQuarters[i], transferGrowth[i]);
        }
        ownedFishMask |= transferFish;
        cap25 |= transferCap25;
        cap30 |= transferCap30;
        if (transferCoins > coins)
        {
            coins = transferCoins;
            if (coins == CoinCap) coinRemainder = 0;
        }
        transferImported = true;
        RecountDisplay();
        Save();
        RefreshRoster();
        RefreshSwimTags();
        RefreshDisplay(now);
        transferInput.text = "";
        transferMessage.text = "引き継いだよ！　残高 " + coins + " C。魚は「3匹管理」で選べます。";
    }

    private void ConfirmFullTransfer()
    {
        VRCPlayerApi player = Networking.LocalPlayer;
        long now = Now();
        if (!Utilities.IsValid(player) || now < cursor) return;
        if (mealPlaying)
        {
            transferMessage.text = "魚が食べ終わってから、もう一度「確定」を押してね。";
            return;
        }
        Advance(now);
        BankThrough(now, false);
        Save();
        PlayerData.SetString(TransferBackupKey, BuildFullTransferCode(player.displayName));
        PlayerData.SetString(TransferSaveKey, fullTransferRecord);
        PlayerData.SetInt(LightModeKey, fullTransferLight);
        PlayerData.SetInt(PageTipsKey, fullTransferTips);
        lightMode = fullTransferLight;
        seenPageTips = fullTransferTips;
        ApplyLighting(lightMode == Night ? 1f : 0f, lightMode == Ultraviolet ? 1f : 0f);
        UpdateLightIcon();
        StopActivity();
        growthTagMask = 0;
        receiptUntil = 0L;
        returnBannerUntil = 0L;
        awayGain = 0;
        Restore();
        approvedTransferCode = "";
        fullTransferRecord = "";
        transferInput.text = "";
        transferMessage.text = "全データを引き継いだよ。\n戻すときは「引き継ぎ前のコード」を使えます。";
    }


    public void PreviousName() { if (page == 6) { StepLane(-1); LoadNameDraft(); } }
    public void NextName() { if (page == 6) { StepLane(1); LoadNameDraft(); } }

    private void StepLane(int step)
    {
        for (int i = 0; i < LaneCount; i++)
        {
            nameLane = (nameLane + LaneCount + step) % LaneCount;
            if (SpeciesAt(packedSlots, nameLane) >= 0) return;
        }
    }

    private void LoadNameDraft()
    {
        int id = SpeciesAt(packedSlots, nameLane);
        if (id < 0) return;
        nameInput.text = string.IsNullOrEmpty(petNames[id]) ? "" : petNames[id];
        nameMessage.text = "12文字まで・空欄で種名に戻す";
        nameTitle.text = "枠 " + (nameLane + 1) + "　" + fishNames[id];
        namePortrait.uvRect = PortraitRect(id);
    }

    private Rect PortraitRect(int species)
    {
        return new Rect((species % 5) * .2f, (4 - species / 5) * .2f, .2f, .2f);
    }

    public void SaveFishName()
    {
        if (!ready || page != 6) return;
        int id = SpeciesAt(packedSlots, nameLane);
        if (id < 0) return;
        string value = nameInput.text.Trim();
        if (!ValidName(value)) { nameMessage.text = "改行なし・12文字まで"; return; }
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        petNames[id] = value;
        Save();
        nameInput.text = value;
        nameMessage.text = "保存したよ　" + DisplayName(id);
        RefreshRoster();
        RefreshSwimTags();
    }

    private void RefreshRoster()
    {
        for (int i = 0; i < LaneCount; i++)
        {
            int id = SpeciesAt(packedSlots, i);
            if (rosterTexts[i] != null) rosterTexts[i].text = id >= 0 ? DisplayName(id) : "空き";
            if (rosterPortraits[i] == null) continue;
            rosterPortraits[i].enabled = id >= 0;
            if (id >= 0) rosterPortraits[i].uvRect = PortraitRect(id);
        }
    }

    public void PreviousEntry() { BrowseEntry(-1); }
    public void NextEntry() { BrowseEntry(1); }
    private void BrowseEntry(int step)
    {
        if (!ready || page != 4) return;
        journalEntry = (journalEntry + entryFish.Length + step) % entryFish.Length;
        JournalPage();
    }

    private void JournalPage()
    {
        int e = journalEntry;
        bool found = (discoveries & (1 << e)) != 0;
        int count = 0;
        for (int i = 0; i < entryFish.Length; i++) if ((discoveries & (1 << i)) != 0) count++;
        journalTitle.text = stageNames[entryStages[e]] + "　" + count + "/" + entryFish.Length;
        journalNote.text = found ? entryTitles[e] + "\n" + DisplayName(entryFish[e]) : entryHints[e];
        if (fieldNotesTexture == null) fieldNotesTexture = journalStamp.texture;
        bool portrait = e >= OriginalStageCount && found;
        journalStamp.texture = portrait ? fishPreview.texture : fieldNotesTexture;
        journalStamp.uvRect = portrait ? PortraitRect(entryFish[e]) : new Rect((float)(entryStages[e] % OriginalStageCount) / OriginalStageCount, found ? .5f : 0f, 1f / OriginalStageCount, .5f);
        if (activity == e) journalAction.text = "観察中…";
        else if (entryStages[e] != currentStage) journalAction.text = "この水槽で\n観察しよう";
        else if ((displayMask & (1 << entryFish[e])) == 0) journalAction.text = "魚を選ぼう";
        else if (mealPlaying) journalAction.text = "食事中…";
        else journalAction.text = found ? "もう一度\n観察する" : "観察する";
    }

    public void ObserveFish()
    {
        if (!ready || page != 4 || entryStages[journalEntry] != currentStage || mealPlaying || activity >= 0) return;
        if ((displayMask & (1 << entryFish[journalEntry])) != 0) StartActivity(journalEntry);
    }

    private bool NearTank()
    {
        VRCPlayerApi player = Networking.LocalPlayer;
        return Utilities.IsValid(player) && (player.GetPosition() - transform.position).sqrMagnitude <= 9f;
    }

    private void AmbientActivity()
    {
        if (Time.time < nextActivity || activity >= 0 || mealPlaying || !NearTank()) return;
        int entry = -1;
        for (int i = 0; i < entryFish.Length; i++)
        {
            if (entryStages[i] != currentStage || (displayMask & (1 << entryFish[i])) == 0) continue;
            entry = i;
            if ((discoveries & (1 << i)) == 0) break;
        }
        bool chest = DecorationPosition(1) >= 0;
        if (entry >= 0 && (!chest || !lastWasEntry || (discoveries & (1 << entry)) == 0)) StartActivity(entry);
        else if (chest) StartActivity(ChestActivity);
    }

    private void StartActivity(int eventId)
    {
        if (!Utilities.IsValid(mealMaterial) || mealPlaying || activity >= 0) return;
        int actor = -1;
        if (eventId != ChestActivity) actor = entryFish[eventId];
        else
        {
            int pos = DecorationPosition(1);
            if (pos < 0) return;
            SetSwimFloat("_CuriosityX", (pos - 1) * .23f);
            for (int i = 0; i < LaneCount && actor < 0; i++) actor = SpeciesAt(packedSlots, i);
            if (actor < 0) return;
        }
        activity = eventId;
        activityStart = Time.time;
        lastWasEntry = eventId != ChestActivity;
        // The shader reserves pose 9 for the bubble chest. New stage poses start at 10.
        int pose = eventId == ChestActivity ? OriginalStageCount : entryStages[eventId];
        if (eventId != ChestActivity && pose >= OriginalStageCount) pose++;
        SetSwimFloat("_Observation", pose);
        SetSwimFloat("_WatchingFish", actor);
        SetSwimFloat("_ObservationAge", 0f);
        if (page == 4) JournalPage();
        QueueActivityFrame();
    }

    private void QueueActivityFrame()
    {
        if (activityTickPending) return;
        activityTickPending = true;
        SendCustomEventDelayedFrames(nameof(AnimateObservation), 1);
    }

    public void AnimateObservation()
    {
        activityTickPending = false;
        if (activity < 0) return;
        float age = Time.time - activityStart;
        if (age >= 6f)
        {
            int e = activity;
            StopActivity();
            if (e != ChestActivity && currentStage == entryStages[e] && NearTank() && (discoveries & (1 << e)) == 0)
            {
                discoveries |= 1 << e;
                Advance(Now());
                Save();
            }
            if (page == 4) JournalPage();
            return;
        }
        SetSwimFloat("_ObservationAge", age);
        if (activity == ChestActivity && Utilities.IsValid(chestMaterial)) chestMaterial.SetFloat("_Age", age);
        QueueActivityFrame();
    }

    private void StopActivity()
    {
        if (activity < 0) return;
        activity = -1;
        nextActivity = Time.time + 32f;
        SetSwimFloat("_Observation", -1f);
        if (Utilities.IsValid(chestMaterial)) chestMaterial.SetFloat("_Age", -1f);
    }

    public void PreviousDecoration() { BrowseDecoration(-1); }
    public void NextDecoration() { BrowseDecoration(1); }
    private void BrowseDecoration(int step)
    {
        if (!ready || page != 5) return;
        decorItem = (decorItem + 3 + step) % 3;
        int pos = DecorationPosition(decorItem);
        if (pos >= 0) decorPosition = pos;
        DecorPage();
    }

    public void ChoosePosition()
    {
        if (!ready || page != 5) return;
        decorPosition = (decorPosition + 1) % 3;
        DecorPage();
    }

    private int DecorationAt(int layout, int position) { return ((layout >> (position * 2)) & 3) - 1; }
    private int DecorationPosition(int item)
    {
        for (int i = 0; i < 3; i++) if (DecorationAt(decorLayout, i) == item) return i;
        return -1;
    }

    private void DecorPage()
    {
        bool owned = (ownedDecor & (1 << decorItem)) != 0;
        int pos = DecorationPosition(decorItem);
        decorTitle.text = decorNames[decorItem] + (owned ? "　所有済み" : "　" + decorCosts[decorItem] + " C");
        decorNote.text = decorDescriptions[decorItem];
        decorPlace.text = "場所　" + positionNames[decorPosition];
        int existing = DecorationAt(decorLayout, decorPosition);
        string place = existing >= 0 ? "入れ替え" : "飾る";
        if (!owned) decorAction.text = (coins < decorCosts[decorItem] ? "コイン不足" : "購入・" + place) + "\n" + decorCosts[decorItem] + " C";
        else decorAction.text = pos == decorPosition ? "しまう" : place;
    }

    public void PlaceDecoration()
    {
        if (!ready || page != 5 || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        int bit = 1 << decorItem;
        if ((ownedDecor & bit) == 0)
        {
            if (coins < decorCosts[decorItem]) { RefreshDisplay(now); return; }
            coins -= decorCosts[decorItem];
            ownedDecor |= bit;
        }
        int oldPos = DecorationPosition(decorItem);
        if (oldPos >= 0) decorLayout &= ~(3 << (2 * oldPos));
        if (oldPos != decorPosition)
        {
            int shift = 2 * decorPosition;
            decorLayout = (decorLayout & ~(3 << shift)) | ((decorItem + 1) << shift);
        }
        if (activity == ChestActivity) StopActivity();
        ApplyDecorations();
        nextTransaction = Time.unscaledTime + .35f;
        Save();
        RefreshDisplay(now);
        if (decorItem == 1 && oldPos != decorPosition && !mealPlaying && activity < 0) StartActivity(ChestActivity);
    }

    private void ApplyDecorations()
    {
        for (int i = 0; i < 3; i++)
        {
            GameObject item = ornaments[i];
            int pos = DecorationPosition(i);
            if (pos >= 0) item.transform.localPosition = new Vector3((pos - 1) * .23f, .049f, -.105f);
            item.SetActive(pos >= 0);
        }
        if (!Utilities.IsValid(chestMaterial)) chestMaterial = ornaments[1].GetComponent<MeshRenderer>().material;
    }

    private bool ReadCollection(string[] fields, int version)
    {
        if (!int.TryParse(fields[11], out discoveries) || discoveries < 0 || discoveries >= (version >= 16 ? 1 << entryFish.Length : version >= 15 ? 1 << PreviousEntryCount : version >= 13 ? 1 << OriginalStageCount : version >= 8 ? 128 : 32) ||
            !int.TryParse(fields[12], out ownedDecor) || ownedDecor < 0 || ownedDecor > 7 ||
            !int.TryParse(fields[13], out decorLayout) || decorLayout < 0 || decorLayout > 63) return false;
        int seen = 0;
        for (int i = 0; i < 3; i++)
        {
            int item = DecorationAt(decorLayout, i);
            if (item < 0) continue;
            int bit = 1 << item;
            if ((seen & bit) != 0 || (ownedDecor & bit) == 0) return false;
            seen |= bit;
        }
        for (int i = 0; i < (version >= 8 ? OriginalFishCount : 10); i++)
        {
            string encoded = fields[14 + i];
            string name = encoded.Replace("%7C", "|").Replace("%25", "%");
            if (!ValidName(name) || EncodeName(name) != encoded) return false;
            petNames[i] = name;
        }
        return true;
    }
    private string EncodeName(string value)
    {
        return string.IsNullOrEmpty(value) ? "" : value.Replace("%", "%25").Replace("|", "%7C");
    }


    private string[] awardNames = { "最初のごはん", "小さな群れ", "蜂蜜色の出会い", "ひとり前の魚", "しぐさの発見", "自動給餌のある暮らし", "水槽の飾り屋", "月虹を渡って", "海底の天文台", "七つの観察記録" };
    private string[] awardHints = { "魚に初めてえさをあげる", "魚を3種類集める", "ハニーグラミーを迎える", "どれか1匹を魚Lv.3に育てる", "観察手帳にしぐさを1つ記録する", "自動給餌器を手に入れる", "飾りを3種類集める", "月虹の氷海を解放する", "星降る海底遺跡を解放する", "7ステージのしぐさをすべて記録する" };
    private int[] awardGoals = { 1,3,1,3,1,1,3,1,1,7 };
    private int[] awardCoins = { 5, 15, 10, 25, 10, 30, 50, 75, 100, 150 };
    private int[] awardXP = { 100, 250, 150, 500, 200, 450, 800, 1200, 1800, 3000 };
    private int awardBits, paidAwards, selectedAward;
    public Text awardReward;
    private string rewardNotice;
    private long rewardNoticeUntil;
    public Text awardTitle, awardHint, awardState;
    public RawImage awardIcon;
    public Image awardTab;

    private int CountBits(int bits)
    {
        int result = 0;
        while (bits != 0) { result += bits & 1; bits >>= 1; }
        return result;
    }

    private int AwardProgress(int id)
    {
        if (id == 0) return lastFeed > 0 ? 1 : 0;
        if (id == 1) return CountBits(ownedFishMask);
        if (id == 2) return (ownedFishMask >> 10) & 1;
        if (id == 3)
        {
            int highest = 1;
            for (int i = 0; i < growthQuarters.Length; i++) highest = Mathf.Max(highest, FishLevel(i));
            return highest;
        }
        if (id == 4 || id == 9) return CountBits(discoveries);
        if (id == 5) return feederState > 0 ? 1 : 0;
        if (id == 6) return CountBits(ownedDecor);
        return (ownedMask >> (id == 7 ? 5 : 6)) & 1;
    }

    private void UpdateAwards()
    {
        for (int i = 0; i < awardGoals.Length; i++)
        {
            int bit = 1 << i;
            if ((awardBits & bit) == 0 && AwardProgress(i) >= awardGoals[i]) awardBits |= bit;
        }
    }

    private void PayAwardRewards()
    {
        int pending = awardBits & ~paidAwards;
        if (pending == 0) return;
        int coinGain = 0;
        int xpGain = 0;
        for (int i = 0; i < awardGoals.Length; i++)
        {
            if ((pending & (1 << i)) == 0) continue;
            coinGain += awardCoins[i];
            xpGain += awardXP[i];
        }
        coinGain = Mathf.Min(coinGain, CoinCap - coins);
        xpGain = Mathf.Min(xpGain, MaxXP - experience);
        coins += coinGain;
        experience += xpGain;
        if (coins == CoinCap) coinRemainder = 0;
        if (experience == MaxXP) xpRemainder = 0;
        paidAwards |= pending;
        rewardNotice = "実績 +" + coinGain + " C・+" + xpGain + " XP";
        rewardNoticeUntil = Now() + 10L;
    }

    public Image expeditionTab;
    public Text tripFishText, tripRouteText, tripCargoText, tripAction, tripInventory;
    public Text capFishText, capLevels, capCost, capAction, capInventory;
    public RawImage tripPortrait, capPortrait;
    public GameObject tripFishArrows, tripRouteArrows;
    private int tripFish = -1, tripRoute = -1, chosenFish = -1, chosenRoute, capFish;
    private long tripStart;
    private int tripShells, tripSand;
    private int shells, starSand, cap25, cap30;
    private int[] routeStages = { 1, 2, 5 };
    private int[] routeMinutes = { 10, 30, 60 };
    private const int IceRoute = 2;
    private const int LegacyIceSand = 3;
    private const int IceShellBonusMultiplier = 2;
    private const int IceSandBonusMultiplier = 3;
    private int[] shellGifts = { 1, 2, 4 }, sandGifts = { 0, 1, 8 };
    private bool tripTickPending;
    private long receiptUntil;
    private string receipt;

    private bool ReadVoyage(string[] fields, int owned, int slots, long snapshot, int speciesCount, int version)
    {
        if (!int.TryParse(fields[56], out tripFish) || !int.TryParse(fields[57], out tripRoute) ||
            !long.TryParse(fields[58], out tripStart) || !int.TryParse(fields[59], out shells) ||
            !int.TryParse(fields[60], out starSand) || shells < 0 || starSand < 0 ||
            !int.TryParse(fields[61], out cap25) || !int.TryParse(fields[62], out cap30) ||
            (cap25 & ~owned) != 0 || (cap30 & ~cap25) != 0) return false;
        if (version >= 20 &&
            (!int.TryParse(fields[63 + 3 * (speciesCount - OriginalFishCount) + 1], out tripShells) || !int.TryParse(fields[63 + 3 * (speciesCount - OriginalFishCount) + 2], out tripSand))) return false;
        if (tripFish == -1)
        {
            if (tripRoute != -1 || tripStart != 0 || tripShells != 0 || tripSand != 0) return false;
        }
        else
        {
            if (tripFish < 0 || tripFish >= fishNames.Length || (owned & (1<<tripFish)) == 0 ||
                tripRoute < 0 || tripRoute >= routeStages.Length || tripStart <= 0 || tripStart > snapshot) return false;
            // Keep the cargo promised by older worlds for trips that were already underway.
            if (version < 20)
            {
                tripShells = tripRoute == IceRoute ? 0 : shellGifts[tripRoute];
                tripSand = tripRoute == IceRoute ? LegacyIceSand : sandGifts[tripRoute];
            }
            if (!ValidTripCargo(version) || !CargoFits(tripShells, tripSand)) return false;
            for (int lane=0; lane<LaneCount; lane++) if (SpeciesAt(slots,lane) == tripFish) return false;
        }
        for (int id=OriginalFishCount; id<speciesCount; id++)
        {
            int at=63+(id-OriginalFishCount)*3;
            string name=fields[at].Replace("%7C","|").Replace("%25","%");
            int growth, effect;
            if (!ValidName(name) || EncodeName(name)!=fields[at] || !int.TryParse(fields[at+1],out growth) ||
                growth<0 || growth>FishThreshold(FishCap(id)) ||
                !int.TryParse(fields[at+2],out effect) || effect<0 || effect>=enchantNames.Length ||
                ((owned & (1<<id))==0 && (name!="" || growth!=0 || effect!=0))) return false;
            growthQuarters[id]=growth;
            enchantments[id]=effect;
            petNames[id]=name;
        }
        return true;
    }

    private int FishCap(int id)
    {
        int bit = 1 << id;
        return (cap30 & bit) != 0 ? 30 : (cap25 & bit) != 0 ? 25 : BaseFishCap;
    }

    private int CycleSpecies(int id, int direction, int mask)
    {
        if (mask == 0) return -1;
        for (int n=0; n<fishNames.Length; n++)
        {
            id=(id+direction+fishNames.Length)%fishNames.Length;
            if ((mask & (1<<id)) != 0) return id;
        }
        return -1;
    }

    private int SpeciesCargoBonus(int fish)
    {
        int basis = fishBonuses[fish];
        if (basis >= 200) return 5;
        if (basis >= 100) return 4;
        if (basis >= 50) return 3;
        if (basis >= 25) return 2;
        return basis >= 10 ? 1 : 0;
    }

    private int TripYield(int fish, int baseCargo, int enchantAffinity, int bonusMultiplier)
    {
        if (baseCargo == 0) return 0;
        int enchantBonus = enchantAffinity == 0 ? 0 : (enchantAffinity >= 20 ? 2 : 1);
        int fishBonus = FishLevel(fish) / 10 + SpeciesCargoBonus(fish) + enchantBonus;
        return baseCargo + bonusMultiplier * fishBonus;
    }

    private int ShellYield(int fish, int route)
    {
        return TripYield(fish, shellGifts[route], enchantCoins[enchantments[fish]], route == IceRoute ? IceShellBonusMultiplier : 1);
    }

    private int SandYield(int fish, int route)
    {
        return TripYield(fish, sandGifts[route], enchantXP[enchantments[fish]], route == IceRoute ? IceSandBonusMultiplier : 1);
    }

    private bool ValidCargo(int baseCargo, int cargo, int bonusMultiplier)
    {
        if (baseCargo == 0) return cargo == 0;
        int maxBonus = FishCap(tripFish) / 10 + SpeciesCargoBonus(tripFish) + 2;
        return cargo >= baseCargo && cargo <= baseCargo + bonusMultiplier * maxBonus &&
            (cargo - baseCargo) % bonusMultiplier == 0;
    }

    private bool ValidTripCargo(int version)
    {
        if (tripRoute != IceRoute)
            return ValidCargo(shellGifts[tripRoute], tripShells, 1) && ValidCargo(sandGifts[tripRoute], tripSand, 1);

        bool validIceSand = version >= 21 && ValidCargo(sandGifts[IceRoute], tripSand, IceSandBonusMultiplier);
        // Trips without shells can keep either of the older ice rewards after migration.
        if (tripShells == 0) return validIceSand || ValidCargo(LegacyIceSand, tripSand, 1);
        return version >= 22 && validIceSand && ValidCargo(shellGifts[IceRoute], tripShells, IceShellBonusMultiplier);
    }

    private bool CargoFits(int shellCount, int sandCount)
    {
        return shells <= int.MaxValue - shellCount && starSand <= int.MaxValue - sandCount;
    }

    private long TripEnd() { return tripStart + routeMinutes[tripRoute]*60L; }
    private bool TripReturned(long now) { return tripFish >= 0 && now >= TripEnd(); }

    private string InventoryLine() { return "貝殻 " + shells + "　星砂 " + starSand; }
    private string GiftLine(int shellCount, int sandCount)
    {
        if (shellCount == 0) return "星砂 ×" + sandCount;
        if (sandCount == 0) return "貝殻 ×" + shellCount;
        return "貝殻 ×" + shellCount + "  星砂 ×" + sandCount;
    }

    public void OpenExpedition()
    {
        int spare = ownedFishMask & ~displayMask;
        if (chosenFish < 0 || (spare & (1<<chosenFish)) == 0) chosenFish=CycleSpecies(-1,1,spare);
        OpenPage(11);
    }

    public void PrevTripFish() { PickTripFish(-1); }
    public void NextTripFish() { PickTripFish(1); }
    private void PickTripFish(int step)
    {
        if (!ready || page!=11 || tripFish>=0) return;
        receiptUntil=0;
        chosenFish=CycleSpecies(chosenFish,step,ownedFishMask & ~displayMask);
        TripPage(Now());
    }
    public void PrevRoute() { PickRoute(-1); }
    public void NextRoute() { PickRoute(1); }
    private void PickRoute(int step)
    {
        if (!ready || page!=11 || tripFish>=0) return;
        receiptUntil=0;
        chosenRoute=(chosenRoute+step+routeStages.Length)%routeStages.Length;
        TripPage(Now());
    }

    public void TravelOrWelcome()
    {
        if (!ready || page!=11 || Time.unscaledTime<nextTransaction) return;
        long now=Now();
        if (now<cursor) return;
        if (tripFish<0)
        {
            if (chosenFish<0 || (ownedFishMask & ~displayMask & (1<<chosenFish))==0) { OpenFishShop(); return; }
            Advance(now);
            int shellCount=ShellYield(chosenFish,chosenRoute), sandCount=SandYield(chosenFish,chosenRoute);
            if (!CargoFits(shellCount,sandCount)) return;
            tripShells=shellCount; tripSand=sandCount;
            tripFish=chosenFish; tripRoute=chosenRoute; tripStart=now;
            receiptUntil=0;
        }
        else
        {
            if (!TripReturned(now)) return;
            Advance(now);
            shells+=tripShells; starSand+=tripSand;
            receipt=GiftLine(tripShells,tripSand)+" 獲得";
            tripShells=0; tripSand=0;
            receiptUntil=now+8;
            chosenFish=tripFish; chosenRoute=tripRoute;
            tripFish=-1; tripRoute=-1; tripStart=0;
        }
        nextTransaction=Time.unscaledTime+.55f;
        Save();
        RefreshDisplay(now);
    }

    public void TickExpedition()
    {
        tripTickPending=false;
        if (ready && page==11) TripPage(Now());
    }

    private void TripPage(long now)
    {
        bool away=tripFish>=0;
        int id=away?tripFish:chosenFish;
        int route=away?tripRoute:chosenRoute;
        int spare=ownedFishMask & ~displayMask;
        tripFishArrows.SetActive(!away && (spare & (spare-1))!=0);
        tripRouteArrows.SetActive(!away);
        tripPortrait.enabled=id>=0;
        if (id>=0) tripPortrait.uvRect=PortraitRect(id);
        tripFishText.text = id < 0 ? "控えの魚がいません" :
            RichFishName(id) + "　" + FishLevelLabel(FishLevel(id)) + "\n基礎 " + fishBonuses[id] + "%　" + enchantNames[enchantments[id]];
        tripRouteText.text=stageNames[routeStages[route]]+"　"+routeMinutes[route]+"分";
        tripInventory.text = Time.unscaledTime < pageTipUntil && !away && now >= receiptUntil
            ? "控えの魚は留守中も素材を探すよ" : "所持　" + InventoryLine();
        int shellCount=away?tripShells:id<0?0:ShellYield(id,route);
        int sandCount=away?tripSand:id<0?0:SandYield(id,route);
        tripCargoText.text=now<receiptUntil?receipt:GiftLine(shellCount,sandCount);
        if (!away)
        {
            tripAction.text=id<0?"魚屋へ":CargoFits(shellCount,sandCount)?"出発する":"所持数上限";
            if(id<0) tripCargoText.text=ownedFishMask==1?"魚屋で2匹目を迎えよう":"展示から1匹外そう";
        }
        else if (TripReturned(now)) tripAction.text="帰還！\n迎える";
        else
        {
            int sec=now<tripStart ? routeMinutes[route]*60 : (int)(TripEnd()-now);
            tripAction.text="探索中\n"+sec/60+":"+(sec%60<10?"0":"")+sec%60;
            if (!tripTickPending)
            {
                tripTickPending=true;
                SendCustomEventDelayedSeconds(nameof(TickExpedition),1f);
            }
        }
    }

    public void OpenFishCaps()
    {
        if (!ready) return;
        if (page==11 && (tripFish>=0 || chosenFish>=0)) capFish=tripFish>=0?tripFish:chosenFish;
        if ((ownedFishMask & (1<<capFish))==0) capFish=CycleSpecies(-1,1,ownedFishMask);
        OpenPage(12);
    }
    public void PrevCapFish() { PickCapFish(-1); }
    public void NextCapFish() { PickCapFish(1); }
    private void PickCapFish(int step)
    {
        if (!ready || page!=12) return;
        capFish=CycleSpecies(capFish,step,ownedFishMask);
        CapPage();
    }

    public void UnlockFishCap()
    {
        if (!ready || page!=12 || Time.unscaledTime<nextTransaction || (ownedFishMask & (1<<capFish))==0) return;
        long now=Now();
        int cap=FishCap(capFish);
        if (now<cursor || cap>=30) return;
        int needShell=cap==20?2:4, needSand=cap==20?1:3;
        if (shells<needShell || starSand<needSand) return;
        Advance(now);
        shells-=needShell; starSand-=needSand;
        if (cap==20) cap25 |= 1<<capFish; else cap30 |= 1<<capFish;
        nextTransaction=Time.unscaledTime+.55f;
        Save();
        RefreshDisplay(now);
    }

    private void CapPage()
    {
        int cap=FishCap(capFish);
        capFishText.text = RichFishName(capFish) + "　" + FishLevelLabel(FishLevel(capFish));
        capPortrait.uvRect=PortraitRect(capFish);
        capInventory.text="所持　"+InventoryLine();
        capLevels.text=cap==30?"上限 Lv.30":"上限 Lv."+cap+" → Lv."+(cap+5);
        int needShell=cap==20?2:4, needSand=cap==20?1:3;
        capCost.text=cap==30?"最終段階　熟練魚で収入＋2%":"必要　貝殻 "+needShell+"　星砂 "+needSand;
        capAction.text=cap==30?"解放済み":shells<needShell || starSand<needSand?"素材不足":"上限解放";
    }


    public GameObject[] tankBodies;
    public Color[] cabinetFinishes, cabinetInlays;
    public Image feedButtonSurface;
    public Image[] feedButtonEdges, cabinetTabRims;
    public MeshFilter feedButtonFrame;
    public Mesh[] feedButtonFrames;
    public Text tankTitle, tankStats, tankAction;
    public Text[] tankOdds;
    private string[] tankNames = { "星海の標準水槽", "翡翠の温室", "真鍮の潜航艇", "月白の天文台", "紫晶の聖堂", "紅玉の王冠", "金環の星宮" };
    private int[] tankPrices = { 0, 1200, 2800, 5500, 9500, 15500, 24000 };
    // Quarter units preserve fractional income and fish growth across saves and equipment changes.
    private int[] tankQuarters = { 4, 5, 6, 7, 8, 10, 12 };
    private int ownedTanks = 1;
    private int activeTank, selectedTank;
    private int shownCabinet;
    private string[] rarityNames = { "ノーマル", "レア", "エピック", "レジェンド" };
    private int[] effectRarity = { 0,1,1,0,2,2,3,3,0 };
    // Each row gives percentages for a fresh roll. Each rarity has two effects of equal weight.
    private int[] tankWeights = {
        56,30,12,2,   52,31,14,3,   46,32,17,5,   40,33,20,7,
        32,34,24,10,  24,34,28,14,  16,32,32,20
    };

    private Color RarityColor(int rarity)
    {
        if (rarity == 1) return new Color32(102,214,255,255);
        if (rarity == 2) return new Color32(220,164,255,255);
        if (rarity == 3) return new Color32(255,210,97,255);
        return new Color32(226,234,240,255);
    }

    // Basis points. Per veteran, move 0.20 percentage points out of normal.
    private int EnchantWeight(int tank, int rarity)
    {
        int shift = rarity == 0 ? -20 : rarity == 1 ? 10 : rarity == 2 ? 6 : 4;
        return tankWeights[tank * 4 + rarity] * 100 + shift * veteranCount;
    }

    private int DrawEnchant(int old)
    {
        int total = 20000;
        if (old != 0) total -= EnchantWeight(activeTank, effectRarity[old]);
        int ticket = Random.Range(0, total);
        for (int effect = 1; effect < effectRarity.Length; effect++)
        {
            if (effect == old) continue;
            ticket -= EnchantWeight(activeTank, effectRarity[effect]);
            if (ticket < 0) return effect;
        }
        return old;
    }

    private int TankHundredths(int amount) { return (amount * tankQuarters[activeTank] * VeteranPercent() + 200) / 400; }

    public void OpenTanks() { OpenPage(10); }
    public void PreviousTank() { BrowseTank(-1); }
    public void NextTank() { BrowseTank(1); }

    private void BrowseTank(int direction)
    {
        if (!ready || page != 10) return;
        selectedTank = (selectedTank + direction + tankNames.Length) % tankNames.Length;
        ApplyTankBody(selectedTank);
        TankPage();
    }

    private void ApplyTankBody(int id)
    {
        for (int i=0; i<tankBodies.Length; i++)
            if (tankBodies[i].activeSelf != (i+1 == id)) tankBodies[i].SetActive(i+1 == id);
        shownCabinet = id;
        RefreshCabinetControls();
    }

    private void RefreshCabinetControls()
    {
        bool themed = CabinetIsThemed();
        Color face = CabinetTabColor(false);
        Color accent = themed ? cabinetInlays[shownCabinet] : (Color)new Color32(229, 200, 121, 255);
        Color selected = CabinetTabColor(true);
        if (collectionTabs != null)
        {
            for (int i = 0; i < collectionTabs.Length; i++)
            {
                bool active = page == i + 4 || (i == 2 && (page == ManagementPage || page == PickerPage));
                collectionTabs[i].color = active ? selected : face;
            }
        }
        if (awardTab != null) awardTab.color = page == 8 ? selected : face;
        RefreshExpeditionTab(Now());

        if (cabinetTabRims != null)
            for (int i = 0; i < cabinetTabRims.Length; i++)
            {
                cabinetTabRims[i].enabled = themed;
                if (themed) cabinetTabRims[i].color = Color.Lerp(face, accent, .65f);
            }
        if (feedButtonSurface != null)
            feedButtonSurface.color = themed ? Color.Lerp(face, accent, .13f) : (Color)new Color32(53, 70, 74, 255);
        if (feedButtonFrame != null && feedButtonFrames != null && shownCabinet < feedButtonFrames.Length)
        {
            Mesh frame = feedButtonFrames[shownCabinet];
            if (feedButtonFrame.sharedMesh != frame) feedButtonFrame.sharedMesh = frame;
        }
        else if (feedButtonEdges != null)
        {
            for (int i = 0; i < feedButtonEdges.Length; i++)
            {
                Color edge = i < 2 ? accent : themed ? Color.Lerp(face, accent, .5f) : (Color)new Color32(119, 110, 87, 255);
                if (i == 4) edge = themed ? Color.Lerp(face, accent, .85f) : (Color)new Color32(154, 134, 95, 255);
                feedButtonEdges[i].color = edge;
            }
        }
        if (feedText != null)
            feedText.color = themed ? Color.Lerp(accent, Color.white, .56f) : (Color)new Color32(255, 227, 161, 255);
    }

    private bool CabinetIsThemed()
    {
        return shownCabinet > 0 && cabinetFinishes != null && cabinetInlays != null &&
               shownCabinet < cabinetFinishes.Length && shownCabinet < cabinetInlays.Length;
    }

    private Color CabinetTabColor(bool selected)
    {
        if (!CabinetIsThemed())
            return selected ? new Color32(50, 107, 104, 255) : new Color32(32, 52, 69, 255);
        Color face = cabinetFinishes[shownCabinet];
        return selected ? Color.Lerp(face, cabinetInlays[shownCabinet], .30f) : face;
    }

    private void RefreshExpeditionTab(long now)
    {
        if (expeditionTab == null) return;
        bool selected = page == 11 || page == 12;
        expeditionTab.color = !selected && TripReturned(now)
            ? (Color)new Color32(140, 101, 48, 255)
            : CabinetTabColor(selected);
    }

    public void EquipTank()
    {
        if (!ready || page != 10 || selectedTank == activeTank || Time.unscaledTime < nextTransaction) return;
        long now = Now();
        if (now < cursor) return;
        Advance(now);
        int bit = 1 << selectedTank;
        if ((ownedTanks & bit) == 0)
        {
            int cost = tankPrices[selectedTank];
            if (coins < cost) { TankPage(); return; }
            coins -= cost;
            ownedTanks |= bit;
        }
        activeTank = selectedTank;
        nextTransaction = Time.unscaledTime + .4f;
        ApplyTankBody(activeTank);
        Save();
        RefreshDisplay(now);
    }

    private void TankPage()
    {
        int id = selectedTank;
        bool owned = (ownedTanks & (1 << id)) != 0;
        tankTitle.text = tankNames[id];
        string rate = "×" + Hundredths(25 * tankQuarters[id]);
        tankStats.text = "水槽 ×" + Hundredths(25 * tankQuarters[id] * VeteranPercent() / 100) + "　成長 " + rate + "　熟練魚 " + veteranCount + "匹";
        tankAction.text = id == activeTank ? "使用中" : owned ? "切り替える" :
            (coins < tankPrices[id] ? "コイン不足" : "購入して使う") + "\n" + tankPrices[id] + " C";
        for (int i=0; i<4; i++)
        {
            tankOdds[i].text = rarityNames[i] + " " + Hundredths(EnchantWeight(id, i)) + "%";
            tankOdds[i].color = RarityColor(i);
        }
    }


    private const int EnchantPrice = 80;
    private int[] enchantments = new int[SpeciesCount];
    // Effect identity stays with the species when the tank or lineup changes.
    private string[] enchantNames = { "未付与", "金運", "星詠み", "真珠", "月光", "陽光", "雷鳴", "氷晶", "花舞" };
    private int[] enchantCoins = { 0,30,0,12,9,27,32,16,10 };
    private int[] enchantXP = { 0,0,30,12,27,9,16,32,14 };
    private int enchantLane;
    private int[] shownEnchant = { -1,-1,-1 };
    public Text[] swimRates, enchantResidents, residentIncome;
    public Image[] enchantTabs;
    private const int ParticlesPerFish = 8;
    public RawImage[] enchantMotes;
    public Text enchantTitle, enchantRate, enchantIncome, enchantAction;
    public RawImage enchantIcon, enchantRarityBadge;

    private int CoinBonus(int fishId) { return FishBonus(fishId) + enchantCoins[enchantments[fishId]]; }
    private int XPBonus(int fishId) { return FishBonus(fishId) + enchantXP[enchantments[fishId]]; }
    private string Rates(int id) { return "C +" + CoinBonus(id) + "%　XP +" + XPBonus(id) + "%"; }

    public void OpenEnchant()
    {
        if (!ready) return;
        if (SpeciesAt(packedSlots,enchantLane) < 0)
            for (int i=0;i<LaneCount;i++) if (SpeciesAt(packedSlots,i)>=0) { enchantLane=i; break; }
        OpenPage(9);
    }
    public void EnchantFirst() { SelectEnchantLane(0); }
    public void EnchantSecond() { SelectEnchantLane(1); }
    public void EnchantThird() { SelectEnchantLane(2); }
    private void SelectEnchantLane(int lane)
    {
        if (!ready || page != 9 || SpeciesAt(packedSlots,lane)<0) return;
        enchantLane=lane;
        EnchantPage();
    }
    public void RollEnchant()
    {
        if (!ready || page != 9 || Time.unscaledTime < nextTransaction) return;
        int id=SpeciesAt(packedSlots,enchantLane);
        long now=Now();
        if (id<0 || now<cursor) return;
        Advance(now);
        if (coins<EnchantPrice) { RefreshDisplay(now); return; }
        pageTipUntil = 0f;
        int old=enchantments[id];
        int value=DrawEnchant(old);
        coins-=EnchantPrice;
        enchantments[id]=value;
        RecountDisplay();
        nextTransaction=Time.unscaledTime+.65f;
        Save();
        RefreshDisplay(now);
    }

    private string Hundredths(int amount)
    {
        int whole=amount/100;
        int fraction=amount%100;
        if (fraction==0) return whole.ToString();
        if (fraction%10==0) return whole+"."+(fraction/10);
        return whole+(fraction<10?".0":".")+fraction;
    }

    private string FishIncome(int id, string separator)
    {
        return "+" + Hundredths(TankHundredths(CoinBonus(id))) + " C/" + stageCoinIntervals[currentStage] + "秒" + separator
            + "+" + Hundredths(TankHundredths(15 * (4 + currentStage) * XPBonus(id))) + " XP/分";
    }

    private void RefreshResidentIncome()
    {
        for (int i=0;i<LaneCount;i++)
        {
            int id=SpeciesAt(packedSlots,i);
            string caption = id < 0 ? "魚を選ぶ" : FishLevelLabel(FishLevel(id)) + "　" + enchantNames[enchantments[id]];
            if (laneDetails[i].text!=caption) laneDetails[i].text=caption;
            int effect=id<0?0:enchantments[id];
            laneDetails[i].color=effect==0?(Color)new Color32(168,201,203,255):RarityColor(effectRarity[effect]);
            bool active=(page==ManagementPage || (page==PickerPage && incomingShopFish<0)) && managedLane==i;
            laneRails[i].color=active?new Color32(111,229,195,255):new Color32(53,83,94,255);
            string line=id<0?"":FishIncome(id,"\n");
            if (residentIncome[i].text!=line) residentIncome[i].text=line;
        }
    }

    private void EnchantPage()
    {
        for (int i=0;i<LaneCount;i++)
        {
            int resident=SpeciesAt(packedSlots,i);
            enchantResidents[i].text=resident<0?"空き":DisplayName(resident);
            int residentEffect=resident<0?0:enchantments[resident];
            enchantResidents[i].color=residentEffect==0?Color.white:RarityColor(effectRarity[residentEffect]);
            enchantTabs[i].color=i==enchantLane?new Color32(50,107,104,255):new Color32(32,52,69,255);
        }
        int id=SpeciesAt(packedSlots,enchantLane);
        SetFishBadge(enchantRarityBadge, id < 0 || enchantments[id] == 0 ? -1 : effectRarity[enchantments[id]]);
        if (id<0) return;
        int value=enchantments[id];
        int rarity=effectRarity[value];
        enchantTitle.color=value==0?Color.white:RarityColor(rarity);
        enchantTitle.text = FishLevelLabel(FishLevel(id)) + "　" + enchantNames[value] + (value == 0 ? "" : "　" + rarityNames[rarity]);
        enchantRate.text=VeteranSummary();
        enchantIncome.text = Time.unscaledTime < pageTipUntil
            ? EnchantPrice + " Cで魚にランダム効果を1つ" : FishIncome(id,"　");
        enchantIcon.enabled=value!=0;
        if (value!=0) enchantIcon.uvRect=new Rect((value-1)/8f,0f,1f/8f,1f);
        enchantAction.text=(coins<EnchantPrice?"コイン不足":(value==0?"ランダム付与":"付け替える"))+"\n"+EnchantPrice+" C";
    }


    public void OpenAwards() { OpenPage(8); }
    public void PreviousAward() { BrowseAward(-1); }
    public void NextAward() { BrowseAward(1); }
    private void BrowseAward(int direction)
    {
        if (!ready || page != 8) return;
        selectedAward = (selectedAward + direction + awardGoals.Length) % awardGoals.Length;
        AwardPage();
    }
    private void AwardPage()
    {
        int id = selectedAward;
        bool unlocked = (awardBits & (1 << id)) != 0;
        awardTitle.text = awardNames[id];
        awardHint.text = awardHints[id];
        bool paid = (paidAwards & (1 << id)) != 0;
        awardReward.text = (paid ? "受取済　" : "報酬　") + "+" + awardCoins[id] + " C　+" + awardXP[id] + " XP";
        int goal = awardGoals[id];
        awardState.text = (unlocked ? "達成済み" : "進行 " + Mathf.Min(AwardProgress(id),goal) + "/" + goal)
            + "　　実績 " + CountBits(awardBits) + "/" + awardGoals.Length;
        awardIcon.uvRect = new Rect((id % 5) * .2f, id < 5 ? .5f : 0f, .2f, .5f);
        awardIcon.color = unlocked ? Color.white : (Color)new Color32(125,151,162,255);
    }


    private void SetBar(int value, int limit)
    {
        if (xpSegments == null) return;
        int filled = value * xpSegments.Length / limit;
        for (int i = 0; i < xpSegments.Length; i++)
        {
            if (xpSegments[i] == null) continue;
            Color32 color = i < filled ? new Color32(89, 216, 196, 255) : new Color32(37, 73, 87, 255);
            xpSegments[i].color = color;
        }
    }
}

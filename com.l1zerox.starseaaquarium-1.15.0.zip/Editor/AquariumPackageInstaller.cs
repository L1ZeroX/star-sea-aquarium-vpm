using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;
using UnityEngine;

namespace L1ZeroX.StarSeaAquarium
{
    [InitializeOnLoad]
    internal static class AquariumPackageInstaller
    {
        private const string PrefabGuid = "5ee12e7be272f54469480c0df11c0459";
        private const string DefaultAssetPath = "Assets/StarSeaAquarium";
        private const string SessionKey = "com.l1zerox.starseaaquarium.appliedVersion";
        private static readonly Regex GuidLine = new Regex(@"(?m)^guid: ([0-9a-f]{32})\r?$");

        static AquariumPackageInstaller()
        {
            EditorApplication.delayCall += Apply;
            UnityEditor.PackageManager.Events.registeredPackages += _ => EditorApplication.delayCall += Apply;
        }

        [MenuItem("Tools/星海水槽/VCCパッケージを適用")]
        private static void Reapply()
        {
            SessionState.EraseString(SessionKey);
            Apply();
        }

        private static void Apply()
        {
            if (EditorApplication.isCompiling || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                if (!EditorApplication.isPlaying)
                    EditorApplication.delayCall += Apply;
                return;
            }

            var package = PackageInfo.FindForAssembly(typeof(AquariumPackageInstaller).Assembly);
            if (package == null || SessionState.GetString(SessionKey, "") == package.version)
                return;

            try
            {
                Synchronize(package.resolvedPath);
                SessionState.SetString(SessionKey, package.version);
                Debug.Log($"[星海水槽] VCC版 {package.version} を適用しました。");
            }
            catch (Exception e)
            {
                Debug.LogError($"[星海水槽] VCCパッケージを適用できませんでした。{e.Message}");
            }
        }

        private static void Synchronize(string packagePath)
        {
            var previousPrefab = AssetDatabase.GUIDToAssetPath(PrefabGuid);
            var assetPath = string.IsNullOrEmpty(previousPrefab) ? DefaultAssetPath : Path.GetDirectoryName(previousPrefab);
            if (string.IsNullOrEmpty(assetPath) || !assetPath.Replace('\\', '/').StartsWith("Assets/", StringComparison.Ordinal))
                throw new InvalidOperationException("水槽のPrefabをAssetsフォルダ内に置いてください。");

            var source = Path.Combine(packagePath, "Aquarium~");
            var destination = Path.GetFullPath(assetPath);
            var contents = Directory.GetFiles(source, "*", SearchOption.AllDirectories);
            var changed = contents.Select(file =>
            {
                string relativePath = file.Substring(source.Length + 1);
                string target = Path.Combine(destination, relativePath);
                if (file.EndsWith(".meta", StringComparison.Ordinal))
                    ValidateGuid(file, target);
                var data = File.ReadAllBytes(file);
                return (target, data);
            }).Where(entry => !File.Exists(entry.target) ||
                              !File.ReadAllBytes(entry.target).SequenceEqual(entry.data)).ToArray();

            if (changed.Length == 0)
                return;

            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (var entry in changed)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(entry.target));
                    string temporary = entry.target + ".starsea-update.tmp";
                    try
                    {
                        File.WriteAllBytes(temporary, entry.data);
                        if (File.Exists(entry.target))
                            File.Replace(temporary, entry.target, null);
                        else
                            File.Move(temporary, entry.target);
                    }
                    finally
                    {
                        if (File.Exists(temporary))
                            File.Delete(temporary);
                    }
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            AssetDatabase.Refresh();
        }

        private static void ValidateGuid(string sourceMeta, string targetMeta)
        {
            // Existing package assets keep their original GUIDs. A conflicting
            // asset in the destination must be resolved before updating any file.
            string expected = GuidLine.Match(File.ReadAllText(sourceMeta)).Groups[1].Value;
            if (expected.Length == 0)
                throw new InvalidDataException($"アセットのGUIDがありません ({sourceMeta})。");

            if (File.Exists(targetMeta) && GuidLine.Match(File.ReadAllText(targetMeta)).Groups[1].Value != expected)
                throw new InvalidDataException($"別のアセットが同じ場所にあります ({targetMeta})。");

            var registered = AssetDatabase.GUIDToAssetPath(expected);
            if (!string.IsNullOrEmpty(registered) && !string.Equals(Path.GetFullPath(registered + ".meta"),
                    Path.GetFullPath(targetMeta), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"水槽に含まれるアセットが別の場所にあります ({registered})。");

            string target = targetMeta.Substring(0, targetMeta.Length - ".meta".Length);
            if (!File.Exists(targetMeta) && (File.Exists(target) || Directory.Exists(target)))
                throw new InvalidDataException($"既存アセットのmetaファイルを確認してください ({target})。");
        }
    }
}

Shader "Hidden/R19 Aquarium/Tube depth"
{
    Properties {
        [HideInInspector] _Observation ("Observation",Float)=-1
        [HideInInspector] _WatchingFish ("Observed species",Float)=-1
        [HideInInspector] _ObservationAge ("Observation age",Float)=0
        [HideInInspector] _CuriosityX ("Chest X",Float)=0
        [HideInInspector] _FeedAge ("Seconds since food release", Float) = -1
        [HideInInspector] _FeedFishCount ("Fish at feeding time", Float) = 1
        [HideInInspector] _FeedFishMask ("Occupied feeding lanes", Float) = -1
        [HideInInspector] _SwimA ("Species in first lane", Float) = 0
        [HideInInspector] _SwimB ("Species in second lane", Float) = 1
        [HideInInspector] _SwimC ("Species in third lane", Float) = 2
            [HideInInspector] _Age ("Chest activity",Float)=-1
    }
    SubShader
    {
        Tags { "R19TubeCaster"="Wildlife" "DisableBatching"="True" }
        Pass
        {
            Cull Off ZWrite On ZTest LEqual
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex TubeCastVert
            #pragma fragment TubeCastFrag
            #include "Wildlife geometry.cginc"
            #define TUBE_Wildlife
            #include "Tube depth.cginc"
            ENDCG
        }
    }
    SubShader
    {
        Tags { "R19TubeCaster"="Habitat" "DisableBatching"="True" }
        Pass
        {
            Cull Off ZWrite On ZTest LEqual
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex TubeCastVert
            #pragma fragment TubeCastFrag
            #include "Habitat geometry.cginc"
            #define TUBE_Habitat
            #include "Tube depth.cginc"
            ENDCG
        }
    }
    SubShader
    {
        Tags { "R19TubeCaster"="Ornament" "DisableBatching"="True" }
        Pass
        {
            Cull Off ZWrite On ZTest LEqual
            CGPROGRAM
            #pragma target 3.0
            #pragma vertex TubeCastVert
            #pragma fragment TubeCastFrag
            #include "Ornament geometry.cginc"
            #define TUBE_Ornament
            #include "Tube depth.cginc"
            ENDCG
        }
    }
    Fallback Off
}

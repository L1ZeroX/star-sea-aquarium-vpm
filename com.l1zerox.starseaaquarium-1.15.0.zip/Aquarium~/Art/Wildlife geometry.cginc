#include "UnityCG.cginc"
struct Input {float4 vertex:POSITION;float3 normal:NORMAL;half4 color:COLOR;float2 kind:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
#include "Fish motion.cginc"
bool IsSwimmer(float kind) {return (kind>.5 && kind<3.5) || (kind>12.5 && kind<34.5);}
half TubeSurface(float kind,float3 p)
{
    // Only the wet enclosure, fauna and substrate receive the tube's direct light.
    return step(.009,p.y)*(1-step(7.5,kind)*step(kind,8.5));
}

void AquariumGeometry(inout Input v)
{
        float kind=v.kind.x;
        float3 p=v.vertex.xyz;
        float3 n=v.normal;
        bool isFish = IsSwimmer(kind);
        float species=kind<3.5 ? kind-1 : kind-10;
        if(isFish)
        {
            float3 center,heading;
            float lane=SwimLane(species);
            if (lane<.5) lane=1;
            AquariumFishPose(lane,species,_Time.y,center,heading,p);
            float3 side=normalize(cross(heading,float3(0,1,0)));
            float3 up=cross(side,heading);
            float tail=saturate((.018-p.x)/.096);
            float wag=(.008+.003*lane);
            if (species>4.5 && species<5.5) wag*=.56;
            if (species>7.5 && species<8.5) wag*=.70;
            p.z += tail*tail*wag*sin(_Time.y*(6.4+lane*.8)*SpeciesMotion(species).x+p.x*25+species);
            if (abs(species-15)<.25)
            {
                float wing=saturate((abs(p.z)-.010)/.057);
                p.y+=wing*wing*.019*sin(_Time.y*2.7+wing*1.4);
            }
            p=center+heading*p.x+up*p.y+side*p.z;
            n=heading*n.x+up*n.y+side*n.z;
        }
        else if(kind>8.5 && kind<9.5)
        {
            float pellet=floor(v.kind.y+.5);
            float owner=floor(pellet*.5)+1;
            float bite=BiteTime(owner,frac(pellet*.5)*2);
            if(_FeedAge<DropTime(pellet) || _FeedAge>=bite || !HasFood(owner))
                p=0; // Collapse every triangle of an unreleased or eaten pellet.
            else
            {
                float size=1-smoothstep(bite-.06,bite,_FeedAge);
                p=PelletCenter(pellet,_FeedAge)+p*size;
            }
        }
        v.vertex.xyz=p;v.normal=n;
}

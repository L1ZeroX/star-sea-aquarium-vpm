#ifndef R19_AQUARIUM_NIGHT_INCLUDED
#define R19_AQUARIUM_NIGHT_INCLUDED
float _UdonR19AquariumNight;
float _UdonR19AquariumUV;

half AquariumDayWeight()
{
    return saturate(1.0h - _UdonR19AquariumNight - _UdonR19AquariumUV);
}

// retained is the fraction of authored linear light left on each type of surface.
half3 AquariumNightTint(half3 authored, half retained)
{
    half3 dim = retained * half3(1.0, .90, .78);
    #ifdef UNITY_COLORSPACE_GAMMA
    dim = LinearToGammaSpace(dim);
    #endif
    return authored * lerp(half3(1,1,1),dim,saturate(_UdonR19AquariumNight));
}

// Mix complete lighting states so a crossfade between night and UV never flashes daylight.
half3 AquariumLighting(half3 lit, half retained, half3 pigment, half response, half tube)
{
    half3 base = AquariumNightTint(lit, retained);
    UNITY_BRANCH if (_UdonR19AquariumUV <= 0.0h) return base;
    #ifdef UNITY_COLORSPACE_GAMMA
    pigment = GammaToLinearSpace(pigment);
    #endif
    half value = max(max(pigment.r, pigment.g), pigment.b);
    half chroma = value - min(min(pigment.r, pigment.g), pigment.b);
    half activity = response * (chroma * .95h + value * .16h);
    half warm = saturate((pigment.r - pigment.b) / max(.04h, value) + .30h);
    half3 fluorescence = lerp(half3(.045,.89,.95), half3(1.0,.13,.56), warm);
    half3 violet = half3(.105,.043,.36);
    half3 uv = violet * (.028h + value * .43h) + fluorescence * activity;
    // Keep the form of fins and the tube shadows visible beneath the fluorescence.
    half3 surface = lit;
    #ifdef UNITY_COLORSPACE_GAMMA
    surface = GammaToLinearSpace(lit);
    #endif
    half litValue = max(surface.r,max(surface.g,surface.b));
    half shading = clamp(litValue / max(.015h,value),.28h,1.12h);
    uv = uv * (.14h + .86h*shading) + surface * half3(.065,.034,.13);
    uv += tube * half3(.36,.12,.91);
    #ifdef UNITY_COLORSPACE_GAMMA
    uv = LinearToGammaSpace(uv);
    #endif
    return max(0, base + saturate(_UdonR19AquariumUV) * (uv - lit));
}
#endif

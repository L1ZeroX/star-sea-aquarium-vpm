struct TubeDepthVertex { float4 pos:SV_POSITION;float depth:TEXCOORD0;float cast:TEXCOORD1; };
TubeDepthVertex TubeCastVert(Input v)
{
    AquariumGeometry(v);
    TubeDepthVertex o;
    o.pos=UnityObjectToClipPos(v.vertex);
    o.depth=-UnityObjectToViewPos(v.vertex.xyz).z;
    o.cast=1;
    #ifdef TUBE_Wildlife
    // The tube sits under its opaque hood. Its own housing and the back wall cannot block it.
    if(abs(v.kind.x-7)<.25 || abs(v.kind.x-8)<.25) o.cast=-1;
    if(v.kind.x<.5) o.cast=.432-v.vertex.y;
    #endif
    #ifdef TUBE_Ornament
    // Decorative crowns rise above the fluorescent fixture. The tube emits beneath them.
    o.cast=min(o.cast,.436-v.vertex.y);
    if(v.kind.x>=1.5)o.cast=-1;
    #endif
    return o;
}
float4 TubeCastFrag(TubeDepthVertex i):SV_Target {clip(i.cast);return i.depth.xxxx;}

#include "UnityCG.cginc"
struct Input {float4 vertex:POSITION;float3 normal:NORMAL;half4 color:COLOR;float2 kind:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
float _Age;
half TubeSurface(float kind,float3 p) {return 1-step(1.5,kind);}

void AquariumGeometry(inout Input v)
{
        float3 p=v.vertex.xyz, n=v.normal;
        float open=smoothstep(.3,1.5,_Age)*(1-smoothstep(4.25,5.6,_Age));
        if(v.kind.x>.5 && v.kind.x<1.5)
        {
            float s,c; sincos(open*1.12,s,c);
            float2 arm=p.yz-float2(.040,.026);
            p.yz=float2(c*arm.x-s*arm.y,s*arm.x+c*arm.y)+float2(.040,.026);
            n.yz=float2(c*n.y-s*n.z,s*n.y+c*n.z);
        }
        if(v.kind.x>1.5 && v.kind.x<2.5)
        {
            if(open<.12) p=0;
            else
            {
                float u=frac(_Age*.55+v.kind.y);
                p.y+=u*.125;
                p.x+=.005*sin(12*u+5*v.kind.y);
            }
        }
        v.vertex.xyz=p;v.normal=n;
}
